# MT5 Connector - Setup & Distribution Guide

## For Developers

### Prerequisites
- Python 3.8+
- Node.js + npm
- TRADIFY server running locally

### Setup Steps

#### 1. Install Connector Dependencies
```bash
pip install requests
```

#### 2. Test Connector Locally
```bash
# Run the GUI
python tradify_mt5_connector.py

# Or use the launcher script
run-connector.bat
```

#### 3. Build Standalone Executable
```bash
# Install PyInstaller
pip install PyInstaller

# Run build script
python build_connector.py
```

This creates `public/downloads/tradify-connector.exe` (~80MB standalone executable, no Python required)

#### 4. Verify Setup

**Frontend:**
```bash
cd client
npm install
npm run dev
# Visit http://localhost:3000
```

**Backend:**
```bash
cd server
npm install
npm run dev
# Server runs on port 3002
```

**Check these endpoints:**
- `GET http://localhost:3002/api/health` → Should return 200 OK
- `GET http://localhost:3002/downloads/tradify-connector.exe` → Should download exe file

### Testing Checklist

- [ ] Modal shows token with copy button
- [ ] Copy button works (test by clicking)
- [ ] Download button triggers file download
- [ ] Connector launches from `run-connector.bat`
- [ ] Connector registers with valid token
- [ ] Account data syncs correctly
- [ ] Trades sync correctly
- [ ] Logs display all operations

### Building for Distribution

```bash
# 1. Ensure everything is tested
python tradify_mt5_connector.py  # Test GUI

# 2. Build executable
python build_connector.py

# 3. Verify exe works on clean Windows
#    (Test on VM if possible)

# 4. File is ready at:
public/downloads/tradify-connector.exe

# 5. Upload to your server for distribution
#    (Or include in release package)
```

## For End Users

### System Requirements
- Windows 10 or later (64-bit)
- 100MB free disk space
- Internet connection
- MetaTrader 5 terminal (optional, for live trading)

### Installation

**Option A: Using Launcher Script (Developers Only)**
1. Download `run-connector.bat`
2. Ensure Python 3.8+ is installed on system
3. Double-click `run-connector.bat`

**Option B: Using Standalone Executable (Recommended for Users)**
1. Download `tradify-connector.exe` from TRADIFY website
2. Double-click to run (no Python installation needed!)
3. Application starts automatically

### First Run

1. **Generate Token in TRADIFY App:**
   - Log in at http://localhost:3000 (or your TRADIFY URL)
   - Click "MT5 Connection" on dashboard
   - Enter MT5 account number
   - Select broker
   - Click "Generate Connection Token"
   - Click copy button next to token

2. **Register Connector:**
   - Connector app opens with 4 tabs
   - Go to "Registration" tab
   - Paste token into "One-Time Token" field
   - Click "Register"
   - Wait for "Registration successful!" message

3. **Sync Account Data:**
   - Go to "Account Sync" tab
   - Enter MT5 Account Number
   - Enter Account Balance (USD)
   - Enter Equity (USD)
   - Click "Sync Account"
   - Check "Logs" tab for confirmation

4. **Sync Trades:**
   - Go to "Trades Sync" tab
   - Paste your MT5 trades as JSON (one trade per entry, or array)
   - Click "Sync Trades"
   - Check "Logs" tab for confirmation

5. **Verify in TRADIFY:**
   - Return to TRADIFY app
   - Go to Dashboard > MT5 Connection
   - Click "Refresh" to see connection
   - Click "Refresh Trades" to load synced trades

### Configuration File

After first registration, the connector saves config to:
```
~/.tradify_connector.json
```

This stores:
- Connection ID (for automatic connection next time)
- Last token usage timestamp
- API URL

You can manually reset by deleting this file.

## File Reference

### Source Files (For Development)
```
tradify_mt5_connector.py      - Main connector application
run-connector.bat              - Windows launcher script
build_connector.py             - Build script for exe
```

### Documentation Files
```
CONNECTOR_QUICK_START.md       - 2-minute user guide
MT5_CONNECTOR_USER_GUIDE.md    - Comprehensive guide
MT5_CONNECTOR_WORKFLOW.md      - Visual workflow diagrams
MT5_CONNECTOR_SETUP.md         - This file (setup guide)
```

### Distribution Files
```
public/downloads/tradify-connector.exe  - Standalone executable
```

## Troubleshooting

### "Python not found" (Script Mode)
```
❌ Problem: run-connector.bat shows "Python not found"
✅ Solution: 
   1. Download Python from https://www.python.org
   2. Run installer with "Add Python to PATH" checked
   3. Restart computer
   4. Try again
```

### "requests module not found"
```
❌ Problem: Connector crashes on startup
✅ Solution:
   1. Open Command Prompt
   2. Run: pip install requests
   3. Try connector again
   
Note: run-connector.bat auto-installs this, so only needed
if running tradify_mt5_connector.py directly
```

### "Connection refused" (API URL)
```
❌ Problem: "Connection failed - API unreachable"
✅ Solution:
   1. Verify TRADIFY server is running (npm run dev)
   2. Check API URL is correct (default: http://localhost:3000/api/mt5)
   3. Test URL in browser: http://localhost:3000/api/health
   4. If remote server: check firewall and internet connection
```

### "Invalid token"
```
❌ Problem: Registration fails - "Invalid token"
✅ Solution:
   1. Ensure token is copied exactly from TRADIFY app
   2. Tokens expire in ~15 minutes - generate new one
   3. Don't accidentally add spaces before/after token
   4. Token is case-sensitive
```

### "Trades sync fails"
```
❌ Problem: Trades tab shows error when syncing
✅ Solution:
   1. Check JSON format is valid (use https://jsonlint.com)
   2. Ensure all required trade fields present
   3. Make sure account was synced first
   4. Check "Logs" tab for detailed error message
```

### "Connector won't start"
```
❌ Problem: Exe fails to launch or crashes immediately
✅ Solution for .bat script:
   1. Open Command Prompt
   2. Navigate to TRADIFY folder: cd "path\to\TRADIFY"
   3. Run manually: python tradify_mt5_connector.py
   4. Screenshot error message
   5. Contact support with screenshot

✅ Solution for .exe:
   1. Try run-connector.bat first (script mode)
   2. If script works: rebuild exe with python build_connector.py
   3. If script fails: check Python installation
```

## Advanced Usage

### CLI Mode
```bash
python tradify_mt5_connector.py --cli YOUR_TOKEN http://localhost:3000/api/mt5
```

Automatically registers and syncs with default data.

### Config File Manual Edit
Edit `~/.tradify_connector.json`:
```json
{
  "connection_id": "conn_abc123xyz",
  "token_used": "2026-01-22T14:30:00",
  "last_sync": "2026-01-22T14:35:00"
}
```

Delete entire file to reset (clear saved connection).

### Running Multiple Instances
Each connector instance is independent. You can:
- Run connector for different accounts
- Keep multiple windows open
- Each maintains separate config file with different connection IDs

## Building for Different Platforms

### Windows (Current)
- Build with: `python build_connector.py`
- Output: `tradify-connector.exe`
- Size: ~80MB
- Runtime: No dependencies needed

### macOS (Future)
```bash
# Same Python code, just add --icon parameter
pyinstaller tradify_mt5_connector.py --onefile --windowed \
  --icon tradify_icon.icns -n tradify-connector
```

### Linux (Future)
```bash
# Same Python code, different build parameters
pyinstaller tradify_mt5_connector.py --onefile \
  -n tradify-connector
```

## Deployment Options

### Option 1: Direct Download
- Host exe on TRADIFY server
- Users download from `/downloads/tradify-connector.exe`
- Link in app UI (already implemented!)

### Option 2: GitHub Releases
- Upload exe to GitHub releases
- Users download from release page
- Share release URL in app

### Option 3: Installer
- Create MSI installer with WiX
- Users run installer first time
- Then connector is in Program Files

### Option 4: Auto-Update
- Version check in connector
- Auto-download newer version
- Seamless updates

## Version Management

Update version in these files:

**tradify_mt5_connector.py:**
```python
# Line ~9
"""Version 1.0.0 - January 2026"""
```

**Batch script - optional:**
```batch
REM Version 1.0.0
```

**Quick Start - update:**
```markdown
**Version 1.0 | TRADIFY © 2026**
```

## Release Checklist

- [ ] All tests pass (local and remote)
- [ ] Exe built and tested on clean Windows
- [ ] Documentation updated
- [ ] Version numbers consistent
- [ ] Security review complete
- [ ] Token flow tested end-to-end
- [ ] Copy button works reliably
- [ ] Download link points to correct file
- [ ] Support docs ready
- [ ] Release notes prepared

## Support Resources

### For Users:
- Quick Start: `CONNECTOR_QUICK_START.md`
- Full Guide: `MT5_CONNECTOR_USER_GUIDE.md`
- FAQ: See "Troubleshooting" section above

### For Developers:
- Workflow: `MT5_CONNECTOR_WORKFLOW.md`
- Implementation: `MT5_CONNECTOR_IMPLEMENTATION.md`
- Source: `tradify_mt5_connector.py`

### Contact:
- Email: support@tradify.app
- Issues: GitHub repository
- Chat: Discord community channel

---
**Last Updated:** January 22, 2026  
**Version:** 1.0.0  
**Status:** ✅ Ready for Distribution
