# Traders Hub - Quick Start Guide

## Starting the Platform

```bash
cd TRADIFY
npm run dev
```

The dashboard will be available at: **http://localhost:3000**

## User Workflow

### For Signal Providers

1. **Login/Signup**
   - Create your account with email and trading capital

2. **Navigate to Traders Hub**
   - Click "Traders Hub" tab in the sidebar

3. **Select Provider Role**
   - Choose "Become a Signal Provider"
   - Click to continue

4. **Review & Accept Terms**
   - Read the Terms of Service
   - Confirm understanding of:
     - Signal accuracy disclaimer
     - No financial advice
     - Prohibited activities
     - Communication rules
     - Account suspension policies
   - Accept terms with checkbox
   - Click "Accept Terms & Continue"

5. **Provider Dashboard**
   - View your provider metrics
   - Manage your trading information:
     - Provider name
     - Bio/description
     - Markets traded (Forex, Crypto, etc.)
     - Trading style (Intraday, Swing, Scalping)
     - Communication platforms (Telegram, WhatsApp, Discord)
     - Monthly/yearly pricing
   - Track subscribers
   - View complaints/disputes

### For Signal Receivers

1. **Login/Signup**
   - Create your account

2. **Navigate to Traders Hub**
   - Click "Traders Hub" tab in the sidebar

3. **Select Receiver Role**
   - Choose "Start Receiving Signals"
   - Click to continue

4. **Acknowledge Risks**
   - Read the risk disclosure:
     - Trading risk warning
     - Unverified performance notice
     - External platform communication
     - Financial advice disclaimer
     - Age 18+ confirmation
   - Check the acknowledgment box
   - Click "I Understand the Risks & Continue"

5. **Receiver Dashboard**
   - Browse available signal providers
   - Filter by:
     - Markets (Forex, Crypto, Stocks)
     - Trading style
     - Win rate
   - Click on a provider to see:
     - Full profile and trading history
     - Communication platforms
     - Subscriber count
     - Performance metrics
     - Reviews from other receivers
   - Subscribe to providers you trust
   - Manage your subscriptions

## API Endpoints (For Integration)

### Role Management
```
POST   /api/traders-hub/select-role
GET    /api/traders-hub/user-role/:userId
POST   /api/traders-hub/accept-terms
POST   /api/traders-hub/acknowledge-risk
```

### Provider Management
```
POST   /api/traders-hub/provider-profile
GET    /api/traders-hub/provider-profile/:userId
GET    /api/traders-hub/providers          (with filters)
GET    /api/traders-hub/provider/:providerId
```

### Subscriptions
```
POST   /api/traders-hub/subscribe
POST   /api/traders-hub/unsubscribe
GET    /api/traders-hub/my-subscriptions/:receiverId
GET    /api/traders-hub/my-subscribers/:providerId
```

### Disputes
```
POST   /api/traders-hub/report-provider
GET    /api/traders-hub/disputes/:providerId
```

## Key Rules

### For Providers
- ✅ Share your trading signals
- ✅ Set your own pricing (Free/Subscription/One-time)
- ✅ Communicate via external platforms only
- ✅ Report honest performance metrics
- ❌ No guaranteed returns
- ❌ No misleading claims
- ❌ No direct fund handling
- ❌ No financial advice

### For Receivers
- ✅ Follow multiple providers
- ✅ Receive signals via Telegram, WhatsApp, or Discord
- ✅ Research providers thoroughly
- ✅ Manage your own risk
- ❌ No refunds for losses
- ❌ Signals are not financial advice
- ❌ You are responsible for your trades
- ❌ Past performance ≠ future results

## Communication Setup

When you subscribe to a provider, you'll connect via:

**Telegram** - @providername or telegram link  
**WhatsApp** - WhatsApp link/number  
**Discord** - Discord server invite  
**Custom** - Provider's custom platform  

The provider will send you signals directly on these platforms. We don't store chat history - all communication is direct between you and the provider.

## Reporting Issues

If a provider:
- Provides false performance data
- Makes false guarantee claims
- Engages in abusive behavior
- Makes misleading claims

Click "Report Provider" and we'll investigate within 7 days.

## Account Status

Providers can be:
- **Unverified** - New providers, no verification yet
- **Identity Verified** - Provider's identity confirmed
- **Performance Audited** - Performance independently verified
- **Suspended** - Temporary suspension for violations
- **Banned** - Permanent removal

## Pricing Models

Providers can choose:
- **Free** - Test signals
- **Monthly Subscription** - Regular access ($X/month)
- **Yearly Subscription** - Best value ($X/year)
- **One-time** - Single purchase
- **Commission-based** - Share of profits (if applicable)

## Troubleshooting

### Can't see the Traders Hub tab?
- Make sure you're logged in
- Refresh the page

### Can't select a role?
- Complete your profile first
- Make sure you have trading capital set

### Can't subscribe to a provider?
- Acknowledge the risk warnings
- Make sure your account is active
- Check you're using a valid email

### Can't report a provider?
- Provide specific details
- Include dates and evidence
- Our team reviews in 7 days

## Support

For issues:
1. Check this guide
2. Review error messages
3. Verify your information is complete
4. Contact support team

## Legal Notices

⚠️ **This platform is for educational purposes only**

- Not financial advice
- Not investment recommendations
- Not a brokerage
- No fund custody
- No trade execution
- All trading at your own risk

**Remember:** Past performance does not guarantee future results. Trade responsibly.

