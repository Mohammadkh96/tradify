# 💻 Code Examples - TRADIFY Authentication

## 1. Using AuthContext

### Basic Usage
```typescript
import { useAuth } from "./context/AuthContext";

function MyComponent() {
  const { user, isAuthenticated, login, logout } = useAuth();

  if (!isAuthenticated) {
    return <p>Please log in</p>;
  }

  return (
    <div>
      <p>Welcome, {user?.fullName || user?.username}</p>
      <button onClick={logout}>Logout</button>
    </div>
  );
}
```

### Signup Example
```typescript
const { signup } = useAuth();

const handleSignup = async () => {
  try {
    await signup(
      "John Doe",                    // fullName
      "john@example.com",            // email
      "password123",                 // password
      10000                          // tradingCapital
    );
    // User is now logged in automatically
    navigate("/dashboard");
  } catch (error) {
    console.error("Signup failed:", error);
  }
};
```

### Login Example
```typescript
const { login } = useAuth();

const handleLogin = async () => {
  try {
    await login(
      "john@example.com",    // email
      "password123"          // password
    );
    navigate("/dashboard");
  } catch (error) {
    console.error("Login failed:", error);
  }
};
```

---

## 2. Protected Routes

### Basic Protection
```typescript
import { ProtectedRoute } from "./components/ProtectedRoute";

<Routes>
  <Route
    path="/dashboard/*"
    element={
      <ProtectedRoute>
        <DashboardLayout />
      </ProtectedRoute>
    }
  />
</Routes>
```

### Conditional Rendering
```typescript
import { useAuth } from "./context/AuthContext";

function Header() {
  const { isAuthenticated, user, logout } = useAuth();

  return (
    <header>
      {isAuthenticated ? (
        <div>
          <span>Welcome, {user?.email}</span>
          <button onClick={logout}>Logout</button>
        </div>
      ) : (
        <div>
          <Link to="/login">Login</Link>
          <Link to="/signup">Sign Up</Link>
        </div>
      )}
    </header>
  );
}
```

---

## 3. API Calls

### Signup API
```typescript
async function registerUser() {
  const response = await fetch("/api/auth/signup", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      username: "john@example.com",
      email: "john@example.com",
      password: "password123",
      tradingCapital: 10000
    })
  });

  const data = await response.json();
  
  if (response.ok) {
    console.log("User created:", data.user);
  } else {
    console.error("Signup error:", data.error);
  }
}
```

### Login API
```typescript
async function authenticateUser() {
  const response = await fetch("/api/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      username: "john@example.com",
      password: "password123"
    })
  });

  const data = await response.json();
  
  if (response.ok) {
    console.log("Logged in as:", data.user.username);
  } else {
    console.error("Login error:", data.error);
  }
}
```

### Get Profile
```typescript
async function fetchUserProfile() {
  const response = await fetch("/api/auth/profile/john@example.com");
  const data = await response.json();

  if (response.ok) {
    console.log("User profile:", data.user);
  }
}
```

---

## 4. Forms

### Login Form
```typescript
import { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

export function LoginForm() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      await login(email, password);
      navigate("/dashboard", { replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      {error && <div className="error">{error}</div>}
      
      <input
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="Email"
        required
      />
      
      <input
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        placeholder="Password"
        required
      />
      
      <button type="submit" disabled={loading}>
        {loading ? "Signing In..." : "Sign In"}
      </button>
    </form>
  );
}
```

### Signup Form
```typescript
import { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

export function SignupForm() {
  const navigate = useNavigate();
  const { signup } = useAuth();
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    password: "",
    confirmPassword: "",
    tradingCapital: ""
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (formData.password !== formData.confirmPassword) {
      setError("Passwords don't match");
      return;
    }

    setLoading(true);

    try {
      await signup(
        formData.fullName,
        formData.email,
        formData.password,
        parseFloat(formData.tradingCapital)
      );
      navigate("/dashboard", { replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Signup failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      {error && <div className="error">{error}</div>}
      
      <input
        type="text"
        value={formData.fullName}
        onChange={(e) => setFormData({...formData, fullName: e.target.value})}
        placeholder="Full Name"
        required
      />
      
      <input
        type="email"
        value={formData.email}
        onChange={(e) => setFormData({...formData, email: e.target.value})}
        placeholder="Email"
        required
      />
      
      <input
        type="password"
        value={formData.password}
        onChange={(e) => setFormData({...formData, password: e.target.value})}
        placeholder="Password"
        required
      />
      
      <input
        type="password"
        value={formData.confirmPassword}
        onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
        placeholder="Confirm Password"
        required
      />
      
      <input
        type="number"
        value={formData.tradingCapital}
        onChange={(e) => setFormData({...formData, tradingCapital: e.target.value})}
        placeholder="Trading Capital"
        required
      />
      
      <button type="submit" disabled={loading}>
        {loading ? "Creating Account..." : "Create Account"}
      </button>
    </form>
  );
}
```

---

## 5. Routing Setup

### Complete App Router
```typescript
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import { ProtectedRoute, PublicRoute } from "./components/ProtectedRoute";

import { LandingPage } from "./pages/LandingPage";
import { LoginPage } from "./pages/LoginPage";
import { SignupPage } from "./pages/SignupPage";
import { DashboardLayout } from "./layouts/DashboardLayout";

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<PublicRoute><LandingPage /></PublicRoute>} />
      <Route path="/login" element={<PublicRoute><LoginPage /></PublicRoute>} />
      <Route path="/signup" element={<PublicRoute><SignupPage /></PublicRoute>} />
      <Route
        path="/dashboard/*"
        element={<ProtectedRoute><DashboardLayout /></ProtectedRoute>}
      />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <Router>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </Router>
  );
}
```

---

## 6. Navigation

### Link Navigation
```typescript
import { Link } from "react-router-dom";

function Navigation() {
  return (
    <nav>
      <Link to="/">Home</Link>
      <Link to="/login">Login</Link>
      <Link to="/signup">Sign Up</Link>
    </nav>
  );
}
```

### Programmatic Navigation
```typescript
import { useNavigate } from "react-router-dom";

function LoginComponent() {
  const navigate = useNavigate();

  const handleLogin = async () => {
    // ... login logic
    navigate("/dashboard", { replace: true });
  };

  return <button onClick={handleLogin}>Login</button>;
}
```

---

## 7. Session Management

### Check Authentication
```typescript
function useRequireAuth() {
  const { isAuthenticated, isLoading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      navigate("/login", { replace: true });
    }
  }, [isAuthenticated, isLoading, navigate]);

  return { isAuthenticated, isLoading };
}
```

### Persist Session
```typescript
// Automatically handled by AuthContext
// Session is saved in localStorage
// Auto-restored on page reload

// Manual save
localStorage.setItem('tradify_user', JSON.stringify(user));
localStorage.setItem('tradify_token', token);

// Manual restore
const user = JSON.parse(localStorage.getItem('tradify_user'));
const token = localStorage.getItem('tradify_token');

// Manual clear
localStorage.removeItem('tradify_user');
localStorage.removeItem('tradify_token');
```

---

## 8. Error Handling

### Try-Catch Pattern
```typescript
try {
  await login(email, password);
  navigate("/dashboard");
} catch (error) {
  const message = error instanceof Error ? error.message : "Unknown error";
  setError(message);
}
```

### API Error Responses
```typescript
const response = await fetch("/api/auth/login", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(data)
});

if (!response.ok) {
  const errorData = await response.json();
  throw new Error(errorData.error?.message || "Request failed");
}

const result = await response.json();
```

---

## 9. Type Safety

### User Type
```typescript
interface User {
  id: number;
  username: string;
  email: string;
  fullName?: string;
  tradingCapital?: string;
  riskPerTrade?: string;
}
```

### Context Type
```typescript
interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  signup: (fullName: string, email: string, password: string, capital: number) => Promise<void>;
  logout: () => void;
}
```

---

## 10. Debugging

### Log Auth State
```typescript
function DebugAuth() {
  const auth = useAuth();
  
  useEffect(() => {
    console.log("Auth state:", {
      user: auth.user,
      isAuthenticated: auth.isAuthenticated,
      isLoading: auth.isLoading
    });
  }, [auth]);

  return null;
}
```

### Check localStorage
```javascript
// In browser console
console.log(localStorage.getItem('tradify_user'));
console.log(localStorage.getItem('tradify_token'));
```

### API Response Inspection
```typescript
const handleLogin = async () => {
  const response = await fetch("/api/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password })
  });

  console.log("Response status:", response.status);
  const data = await response.json();
  console.log("Response data:", data);
};
```

---

## Quick Copy-Paste Snippets

### Signup Component (Copy & Use)
```tsx
// Copy this entire file
```

### Login Component (Copy & Use)
```tsx
// Copy this entire file
```

### Protected Dashboard (Copy & Use)
```tsx
// Copy this entire file
```

---

**All code examples are production-ready!** ✅
