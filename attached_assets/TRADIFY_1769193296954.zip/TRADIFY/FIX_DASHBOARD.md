# Fix: Dashboard Not Showing

## What Was Fixed

✅ **Updated all hardcoded API URLs** from `localhost:3001` to use relative URLs (`/api/...`)
- The Vite proxy automatically forwards `/api` requests to `localhost:3002`

## Files Updated

- `client/src/api/hooks.ts`
- `client/src/components/AccountSnapshot.tsx`
- `client/src/components/DisciplineBanner.tsx`
- `client/src/components/RuleComplianceIndicator.tsx`
- `client/src/components/RiskExposureMonitor.tsx`
- `client/src/components/OpenTradesOverview.tsx`
- `client/src/components/MT5ConnectionModal.tsx`
- `client/src/components/MT5ConnectionStatus.tsx`

## Next Steps

### 1. Make Sure Servers Are Running

**Start the dev server:**
```powershell
npm.cmd run dev
```

**Or double-click:** `start-dev.bat`

### 2. Wait for Both Servers to Start

You should see:
- ✅ Backend: `🚀 TRADIFY Server running on http://localhost:3002`
- ✅ Frontend: `➜  Local:   http://localhost:3000/`

### 3. Hard Refresh Your Browser

After servers are running:
1. Open http://localhost:3000
2. Press `Ctrl + Shift + R` (Windows) or `Cmd + Shift + R` (Mac) to hard refresh
3. This clears cached JavaScript that might have old URLs

### 4. Check Browser Console

Press `F12` to open Developer Tools and check:
- **Console tab** - Look for any errors (red text)
- **Network tab** - Check if API requests are going to `/api/...` (not localhost:3001)

### 5. Verify Backend is Working

Test the backend directly:
- Open: http://localhost:3002/api/health
- Should show: `{"status":"ok","timestamp":"...","version":"1.0.0","mode":"read-only"}`

## Common Issues

### "ERR_CONNECTION_REFUSED"
→ Servers aren't running. Start them with `npm.cmd run dev`

### Blank Page / White Screen
→ Check browser console (F12) for JavaScript errors
→ Hard refresh: `Ctrl + Shift + R`

### API Errors in Console
→ Make sure backend is running on port 3002
→ Check that Vite proxy is working (requests should go to `/api/...`)

### Dashboard Shows But No Data
→ This is normal if you haven't created any trades yet
→ The dashboard will show default/empty state

## Still Not Working?

1. **Stop all servers** (close terminal windows)
2. **Restart servers:**
   ```powershell
   npm.cmd run dev
   ```
3. **Wait 15 seconds** for full startup
4. **Hard refresh browser:** `Ctrl + Shift + R`
5. **Check browser console** for errors

---

**The dashboard should now work!** 🎉
