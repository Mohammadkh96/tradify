# MT5 Bridge Setup

The MT5 Bridge connects your live MetaTrader 5 terminal to TRADIFY.

## Requirements

1. **MetaTrader 5 installed** on your laptop
2. **Python 3.8+** installed
3. **MT5 Terminal running** with your account logged in

## Installation

### 1. Install Python MetaTrader5 Package

```bash
pip install MetaTrader5 flask flask-cors
```

### 2. Start the MT5 Bridge

```bash
python mt5_bridge.py
```

You should see:
```
Starting MT5 Bridge on http://localhost:5001
```

### 3. Connect in TRADIFY

1. Open TRADIFY at **http://localhost:8080**
2. Click **"Connect MT5"** button
3. Enter your MT5 credentials:
   - **Account**: Your MT5 account number
   - **Password**: Your MT5 password
   - **Server**: Your broker's server (e.g., `MetaQuotes-Demo`)

### 4. Auto-Sync

Once connected, TRADIFY will:
- ✓ Auto-refresh account balance
- ✓ Auto-load open trades
- ✓ Auto-calculate risk exposure
- ✓ Track rule compliance

## How It Works

The bridge:
1. Connects to your running MT5 terminal
2. Reads live account data (balance, equity, margin)
3. Pulls open positions in real-time
4. Exposes data via REST API on port 5001
5. TRADIFY app fetches from this API

## Troubleshooting

**"Connection refused on port 5001"**
- Make sure `python mt5_bridge.py` is running
- Check: `ps aux | grep mt5_bridge.py`

**"MT5 login failed"**
- Ensure MT5 terminal is open and logged in
- Verify account number and password
- Check broker server name in MT5

**"No open trades showing"**
- Ensure you have open positions in MT5
- Data refreshes every 2 seconds
- Check browser developer console for errors

## Stop the Bridge

```bash
pkill -f mt5_bridge.py
```

## Architecture

```
MetaTrader 5 Terminal
        ↓
   MT5 Bridge (Python)
        ↓
   REST API (port 5001)
        ↓
   TRADIFY App (port 8080)
        ↓
   Your Browser
```

## Real-Time Updates

Data syncs every 2 seconds automatically. Click "Refresh" in TRADIFY to force an immediate update.
