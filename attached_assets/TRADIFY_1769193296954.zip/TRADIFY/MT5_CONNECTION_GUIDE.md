# MT5 Connection Guide

## Official Connection Method

TRADIFY uses **one single, official connection method** to ensure reliability and simplicity.

### Requirements

- MetaTrader 5 installed on your Windows computer
- Active MT5 account (live or demo)
- TRADIFY project downloaded to your computer

### Connection Steps

#### 1. Start Setup in TRADIFY Dashboard

- Open TRADIFY at `http://localhost:3000`
- Navigate to **Settings → MT5 Connections**
- Click **"Start Setup"**

#### 2. Enter Your MT5 Account Details

- Enter your MT5 account number
- Select your broker from the dropdown
- Click **"Continue"**

Your unique connection token will be generated.

#### 3. Launch the Connector

- **Copy your connection token** (displayed on screen)
- Open your TRADIFY folder on your computer
- **Double-click:** `START_MT5_CONNECTOR.bat`
- A green window will appear

#### 4. Connect

- **Paste your token** in the connector window
- Make sure MT5 is open and logged in
- Click **"Start Connection"**
- Status will show **"Connected ✓"**

### What Happens After Connection

- Your trades sync automatically to TRADIFY dashboard
- Account balance, equity, and margin update every 30 seconds
- Open positions sync every 60 seconds
- Connection status visible in both connector and dashboard

### Troubleshooting

#### Connector Won't Start

**Solution:** Make sure MT5 is installed and running, and you're logged into your MT5 account.

#### Connection Says "Offline"

**Solution:** The connector must be running for sync to work. Double-click `START_MT5_CONNECTOR.bat` again.

#### Token Expired

**Solution:** Tokens expire after 15 minutes. Start a new setup in the dashboard to generate a fresh token.

### Technical Details

- **Method:** Official MetaTrader 5 Python API
- **Security:** Bank-grade encryption, local execution only
- **Permissions:** Read-only access (no trading permissions)
- **Data:** Syncs account info and trades only

### Support

For issues or questions:
1. Check this guide
2. Review connector logs (displayed in the connector window)
3. Restart both MT5 and the connector
4. If still stuck, contact support with your error message

---

**Version:** 1.0.0  
**Last Updated:** January 2026  
**Official Method:** Python Connector via START_MT5_CONNECTOR.bat
