# TRADIFY MT5 Connector Build Instructions

## Building the Connector

The connector is built from `tradify_connector.py` using PyInstaller.

### Quick Build (Windows)

```powershell
# From repository root
pwsh -File tools/build-connector.ps1
```

Output: `dist/tradify-connector.exe`

### Manual Build

```bash
# Install PyInstaller
pip install pyinstaller

# Build
pyinstaller --noconsole --onefile --name tradify-connector tradify_connector.py
```

## Hosting the Connector

### Option 1: Static Hosting (Recommended for Production)

1. Upload `dist/tradify-connector.exe` to your CDN or static hosting:
   - AWS S3 + CloudFront
   - Cloudflare R2
   - Azure Blob Storage
   - GitHub Releases

2. Set environment variable:
   ```env
   VITE_CONNECTOR_DOWNLOAD_URL=https://your-cdn.com/tradify-connector.exe
   ```

### Option 2: Serve from Backend (Development)

1. Copy `dist/tradify-connector.exe` to `server/public/downloads/`

2. Add static file serving in `server/src/index.ts`:
   ```typescript
   app.use('/downloads', express.static(path.join(__dirname, '../public/downloads')));
   ```

3. Connector will be available at: `http://localhost:3002/downloads/tradify-connector.exe`

### Option 3: Local Development (Current Setup)

The download button uses:
- `VITE_CONNECTOR_DOWNLOAD_URL` environment variable (if set)
- Fallback: `/downloads/tradify-connector.exe`

For local testing without building:
1. The button will attempt to download from `/downloads/tradify-connector.exe`
2. You can place a built exe there, or it will 404 (user sees browser download error)

## Signing the Executable (Production)

For production, sign the executable to avoid Windows SmartScreen warnings:

```powershell
# Using signtool (Windows SDK required)
signtool sign /f your-certificate.pfx /p password /t http://timestamp.digicert.com dist/tradify-connector.exe
```

Or use:
- Azure Code Signing
- DigiCert
- SSL.com Code Signing

## Versioning

Update version in:
- `tradify_connector.py` (add `__version__ = "1.0.0"`)
- `client/src/pages/MT5ConnectionsSettingsPage.tsx` (download section)
- Release notes

## Testing the Download

1. Build the connector: `pwsh -File tools/build-connector.ps1`
2. Copy to `server/public/downloads/tradify-connector.exe`
3. Start dev server: `npm run dev`
4. Navigate to MT5 Settings
5. Click "Download Now"
6. Verify download starts

## Security Checklist

- [ ] Executable is signed with valid code signing certificate
- [ ] HTTPS only for downloads (no HTTP)
- [ ] Checksum/hash published for verification
- [ ] Version number matches release
- [ ] No hardcoded credentials or tokens
- [ ] Source code available for review (GitHub)
