# TRADIFY Quick Start Guide

## ⚡ 5-Minute Setup

### Step 1: Install Dependencies
```bash
cd TRADIFY
npm install
```

### Step 2: Start Development Servers
```bash
npm run dev
```

This starts:
- **Frontend**: http://localhost:5173 (React + Vite)
- **Backend**: http://localhost:3001 (Express API)

### Step 3: Open in Browser
Navigate to **http://localhost:5173** and start trading!

---

## 🚀 First Trade

1. Click **New Entry** tab
2. Fill in any asset (e.g., "EURUSD")
3. Select **LONG** and **BULLISH**
4. Select **RETEST**
5. Enter prices (e.g., Entry: 1.0900, SL: 1.0880, TP: 1.0930)
6. Toggle all 3 checklist items (Zone, OB/FVG, Liquidity)
7. Watch the HUD turn **GREEN** ✓
8. Click **Create Trade**
9. View your trade in **Journal** tab

---

## 📊 Dashboard Features

- **Win Rate**: Percentage of winning trades
- **Profit Factor**: Ratio of wins to losses
- **Avg R:R**: Average risk/reward ratio
- **Total P&L**: Cumulative profit/loss
- **Compliant**: % of rule-compliant trades

---

## 🔴 HUD Violations (When Things Turn Red)

The HUD will show violations if:
- **GR-02**: Direction misaligned with HTF Bias
- **GR-03**: Zone checkbox not toggled
- **GR-05**: OB/FVG retest not toggled
- **GR-08**: Reversal entry without liquidity sweep

---

## 🛠 Production Build

```bash
npm run build
npm start
```

---

## 💾 Database (Optional)

To persist data to PostgreSQL:

1. Install PostgreSQL (v14+)
2. Create database:
   ```sql
   CREATE DATABASE tradify_db;
   ```
3. Update `server/.env.local` with credentials
4. Run `npm run dev`

Without a database, the app runs in demo mode (memory storage).

---

## 📚 Tabs Explained

| Tab | Purpose |
|-----|---------|
| **Dashboard** | Performance metrics and charts |
| **Journal** | View all past trades |
| **New Entry** | Create trades with real-time validation |
| **Knowledge** | Learn the 4 Global Hard Rules |
| **Risk Calc** | Calculate position size |

---

## 🎨 Customization

### Change Colors
Edit `client/tailwind.config.js`:
```js
colors: {
  emerald: { 500: "#10b981" }, // Bullish color
  rose: { 500: "#f43f5e" },    // Bearish color
}
```

### Change Rules
Edit `shared/src/index.ts` in the `GlobalHardRules` object.

---

## 🔗 API Examples

### Get All Trades
```bash
curl http://localhost:3001/api/trades
```

### Validate Trade
```bash
curl -X POST http://localhost:3001/api/trades/validate \
  -H "Content-Type: application/json" \
  -d '{
    "asset": "EURUSD",
    "direction": "LONG",
    "htfBias": "BULLISH",
    "entryType": "RETEST",
    "entryPrice": 1.0900,
    "stopLoss": 1.0880,
    "takeProfit": 1.0930,
    "hasValidZone": true,
    "hasObFvgRetest": true,
    "hasLiquiditySweep": false
  }'
```

---

## ❓ Troubleshooting

**Port 5173/3001 already in use?**
```bash
# Change port in vite.config.ts or server .env
```

**Database connection error?**
- Check PostgreSQL is running
- Verify credentials in `server/.env.local`
- Or run without DB in demo mode

**Build errors?**
```bash
rm -rf node_modules
npm install
npm run dev
```

---

## 📞 Quick Reference

- **Documentation**: See [README.md](./README.md)
- **Rules**: Check Knowledge Base in-app
- **API**: http://localhost:3001/api/health (health check)

---

**Happy Trading! Follow the rules. Let TRADIFY enforce your methodology.** 🚀
