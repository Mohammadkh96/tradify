# TRADIFY Troubleshooting Guide

## PowerShell Execution Policy Error

### Problem
```
npm : File C:\Program Files\nodejs\npm.ps1 cannot be loaded because running scripts is disabled on this system.
```

### Solutions

#### Option 1: Use npm.cmd (Recommended)
```powershell
npm.cmd run dev
```

#### Option 2: Use Batch File
```cmd
start-dev.bat
```

#### Option 3: Use PowerShell Script
```powershell
.\start-dev.ps1
```

#### Option 4: Change Execution Policy (Requires Admin)
```powershell
# Run PowerShell as Administrator, then:
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

#### Option 5: Use Command Prompt Instead
Open `cmd.exe` instead of PowerShell and run:
```cmd
npm run dev
```

## Port Already in Use

### Problem
```
Error: listen EADDRINUSE: address already in use :::3000
```

### Solution
1. Find the process using the port:
```powershell
netstat -ano | findstr :3000
```

2. Kill the process (replace PID with actual process ID):
```powershell
taskkill /PID <PID> /F
```

Or change the port in `client/vite.config.ts`:
```typescript
server: {
  port: 3001, // Change to different port
}
```

## Database Connection Failed

### Problem
```
✗ Database connection failed
```

### Solution
The app runs in **demo mode** without a database. To use PostgreSQL:

1. Install PostgreSQL
2. Create database:
```sql
CREATE DATABASE tradify_db;
```

3. Create `server/.env.local`:
```env
DB_HOST=localhost
DB_PORT=5432
DB_NAME=tradify_db
DB_USER=postgres
DB_PASSWORD=your_password
```

## MT5 Not Detected

### Problem
```
MT5 EA not detected
```

### Solution
1. Ensure `TradifyBridge.ex5` is running in MT5
2. Check file path: `GET http://localhost:3002/api/mt5/status`
3. Verify file exists at the path shown in the response
4. Check MT5 EA permissions (Tools → Options → Expert Advisors)

## Module Not Found Errors

### Problem
```
Error: Cannot find module '...'
```

### Solution
```bash
# Reinstall dependencies
npm install

# If using workspaces, install in each workspace:
cd client && npm install
cd ../server && npm install
cd ../shared && npm install
```

## TypeScript Compilation Errors

### Problem
```
Type errors in TypeScript files
```

### Solution
1. Check `tsconfig.json` in each workspace
2. Ensure all dependencies are installed
3. Rebuild shared package:
```bash
cd shared && npm run build
```

## Hot Reload Not Working

### Problem
Changes not reflecting in browser

### Solution
1. Check browser console for errors
2. Hard refresh: `Ctrl+Shift+R` (Windows) or `Cmd+Shift+R` (Mac)
3. Clear browser cache
4. Restart dev server

## Rule Engine Not Loading Rules

### Problem
```
Failed to load rules from ...
```

### Solution
1. Verify `server/src/market_knowledge/rules.json` exists
2. Check JSON syntax is valid
3. Ensure file permissions allow reading
4. Check server logs for detailed error

## Common Issues Summary

| Issue | Quick Fix |
|-------|-----------|
| PowerShell execution policy | Use `npm.cmd run dev` |
| Port in use | Change port or kill process |
| Database error | App runs in demo mode without DB |
| MT5 not detected | Check EA is running in MT5 |
| Module not found | Run `npm install` |
| Type errors | Rebuild shared package |

## Getting Help

1. Check server logs for detailed error messages
2. Verify all prerequisites are installed
3. Check `QUICK_START.md` for setup instructions
4. Review `REFACTORING_COMPLETE.md` for architecture details

---

**Remember**: The app runs in demo mode without a database. Most features work without PostgreSQL!
