# Chart Image Analysis - Technical Implementation Guide

## Quick Start: Building the Deterministic Analyzer

### Architecture Overview

```
User Upload (PNG/JPG)
    ↓
┌─────────────────────────────────────┐
│   Backend: ChartAnalyzer (Python)   │
│                                     │
│  1. Image preprocessing             │
│  2. Candlestick detection           │
│  3. Support/Resistance zones        │
│  4. Volume profile                  │
│  5. Zone classification             │
│  6. Entry candidate suggestions     │
└─────────────────────────────────────┘
    ↓
  Results JSON
    ↓
┌─────────────────────────────────────┐
│   Frontend: Display & Validate      │
│                                     │
│  1. Show overlay on image           │
│  2. User confirms detected elements │
│  3. Pre-fill form with results      │
│  4. Link to knowledge base          │
└─────────────────────────────────────┘
```

---

## Implementation: Step-by-Step

### STEP 1: Set Up Python Backend Module

**File:** `server/src/chart_analyzer.py`

```python
"""
Chart Image Analysis Module
Non-AI, deterministic approach using computer vision
"""

import cv2
import numpy as np
from typing import Dict, List, Tuple, Optional
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ChartImage:
    """Represents and analyzes a chart screenshot"""
    
    def __init__(self, image_path: str):
        """
        Initialize with chart image
        
        Args:
            image_path: Path to chart image file
        """
        self.image = cv2.imread(image_path)
        if self.image is None:
            raise ValueError(f"Could not load image: {image_path}")
        
        self.height, self.width = self.image.shape[:2]
        self.hsv = cv2.cvtColor(self.image, cv2.COLOR_BGR2HSV)
        self.gray = cv2.cvtColor(self.image, cv2.COLOR_BGR2GRAY)
        
        logger.info(f"Loaded image: {self.width}x{self.height}")
    
    def get_metadata(self) -> Dict:
        """Extract basic image metadata"""
        return {
            'width': self.width,
            'height': self.height,
            'color_space': 'BGR',
            'file_size_estimate': self.image.size,
        }
    
    def detect_candlesticks(self) -> Dict:
        """
        Detect candlestick bodies and wicks
        
        Logic:
        1. Convert to HSV and look for color ranges (green/red)
        2. Create masks for bull (green) and bear (red) candles
        3. Find contours (candlestick bodies)
        4. Detect wicks (thin vertical lines)
        5. Pair bodies with wicks
        
        Returns:
            Dictionary with detected candlesticks
        """
        
        # Define color ranges for candlesticks
        # Green (bull) candles in HSV
        lower_green = np.array([35, 40, 40])
        upper_green = np.array([85, 255, 255])
        green_mask = cv2.inRange(self.hsv, lower_green, upper_green)
        
        # Red (bear) candles in HSV
        lower_red1 = np.array([0, 100, 100])
        upper_red1 = np.array([10, 255, 255])
        lower_red2 = np.array([170, 100, 100])
        upper_red2 = np.array([180, 255, 255])
        red_mask = cv2.inRange(self.hsv, lower_red1, upper_red1)
        red_mask += cv2.inRange(self.hsv, lower_red2, upper_red2)
        
        # Combine masks
        candle_mask = green_mask | red_mask
        
        # Morphological operations to clean up
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
        candle_mask = cv2.morphologyEx(candle_mask, cv2.MORPH_CLOSE, kernel)
        candle_mask = cv2.morphologyEx(candle_mask, cv2.MORPH_OPEN, kernel)
        
        # Find contours (candlestick bodies)
        contours, _ = cv2.findContours(candle_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        candlesticks = []
        for contour in contours:
            # Get bounding rectangle
            x, y, w, h = cv2.boundingRect(contour)
            
            # Filter by aspect ratio (candlestick bodies are typically tall)
            if h > w * 1.5 and w > 5 and h > 10:
                # Determine color (green or red)
                color = 'green' if cv2.countNonZero(green_mask[y:y+h, x:x+w]) > 0 else 'red'
                
                candlesticks.append({
                    'x': int(x),
                    'y': int(y),
                    'width': int(w),
                    'height': int(h),
                    'color': color,
                    'area': int(w * h),
                    'aspect_ratio': h / w if w > 0 else 0,
                })
        
        # Sort by x position (left to right)
        candlesticks.sort(key=lambda c: c['x'])
        
        logger.info(f"Detected {len(candlesticks)} candlesticks")
        
        return {
            'count': len(candlesticks),
            'candlesticks': candlesticks,
            'confidence': min(1.0, len(candlesticks) / 50) if len(candlesticks) > 0 else 0.0,
        }
    
    def detect_horizontal_lines(self) -> List[Dict]:
        """
        Detect horizontal lines (S/R levels, support/resistance)
        
        Logic:
        1. Edge detection (Canny)
        2. Hough line detection (horizontal lines only)
        3. Group nearby lines into zones
        
        Returns:
            List of detected horizontal lines/zones
        """
        
        # Edge detection
        edges = cv2.Canny(self.gray, 50, 150)
        
        # Probabilistic Hough line detection
        lines = cv2.HoughLinesP(edges, 1, np.pi/180, 30, minLineLength=50, maxLineGap=10)
        
        horizontal_lines = []
        if lines is not None:
            for line in lines:
                x1, y1, x2, y2 = line[0]
                
                # Check if line is approximately horizontal (y values similar)
                if abs(y2 - y1) < 5:  # Threshold for horizontal
                    horizontal_lines.append({
                        'x1': int(x1),
                        'y1': int(y1),
                        'x2': int(x2),
                        'y2': int(y2),
                        'length': int(abs(x2 - x1)),
                        'y_position': int((y1 + y2) / 2),
                    })
        
        # Cluster nearby lines into zones
        zones = self._cluster_horizontal_lines(horizontal_lines)
        
        logger.info(f"Detected {len(zones)} potential S/R zones")
        
        return zones
    
    def _cluster_horizontal_lines(self, lines: List[Dict], threshold: int = 15) -> List[Dict]:
        """
        Cluster nearby horizontal lines into zones
        
        Args:
            lines: List of detected horizontal lines
            threshold: Y-distance threshold for clustering
        
        Returns:
            List of clustered zones
        """
        if not lines:
            return []
        
        # Sort by y position
        sorted_lines = sorted(lines, key=lambda l: l['y_position'])
        
        zones = []
        current_zone = [sorted_lines[0]]
        
        for line in sorted_lines[1:]:
            if abs(line['y_position'] - current_zone[0]['y_position']) < threshold:
                current_zone.append(line)
            else:
                zones.append(self._create_zone_from_lines(current_zone))
                current_zone = [line]
        
        zones.append(self._create_zone_from_lines(current_zone))
        
        return zones
    
    def _create_zone_from_lines(self, lines: List[Dict]) -> Dict:
        """Create a zone from clustered lines"""
        y_positions = [l['y_position'] for l in lines]
        avg_y = int(np.mean(y_positions))
        zone_height = max(y_positions) - min(y_positions)
        
        return {
            'y_position': avg_y,
            'zone_height': zone_height,
            'line_count': len(lines),
            'strength': 'strong' if len(lines) >= 3 else 'moderate' if len(lines) >= 2 else 'weak',
            'lines': lines,
        }
    
    def detect_price_levels(self) -> Dict:
        """
        Detect price level clusters using candlestick positions
        
        Logic:
        1. Get all candlestick high and low points
        2. Cluster by y-position
        3. Create support/resistance zones from clusters
        
        Returns:
            Dictionary with detected price levels
        """
        
        candlesticks_result = self.detect_candlesticks()
        candlesticks = candlesticks_result['candlesticks']
        
        if not candlesticks:
            return {'levels': [], 'count': 0}
        
        # Get high and low points
        highs = [c['y'] for c in candlesticks]
        lows = [c['y'] + c['height'] for c in candlesticks]
        
        all_points = highs + lows
        
        # Cluster by proximity
        levels = self._cluster_points(all_points, threshold=20)
        
        logger.info(f"Detected {len(levels)} price levels")
        
        return {
            'levels': levels,
            'count': len(levels),
        }
    
    def _cluster_points(self, points: List[int], threshold: int = 20) -> List[Dict]:
        """Cluster nearby points"""
        if not points:
            return []
        
        sorted_points = sorted(points)
        clusters = []
        current_cluster = [sorted_points[0]]
        
        for point in sorted_points[1:]:
            if abs(point - current_cluster[0]) < threshold:
                current_cluster.append(point)
            else:
                clusters.append({
                    'position': int(np.mean(current_cluster)),
                    'count': len(current_cluster),
                    'range': (min(current_cluster), max(current_cluster)),
                })
                current_cluster = [point]
        
        clusters.append({
            'position': int(np.mean(current_cluster)),
            'count': len(current_cluster),
            'range': (min(current_cluster), max(current_cluster)),
        })
        
        return sorted(clusters, key=lambda c: c['count'], reverse=True)
    
    def detect_volume_profile(self) -> Dict:
        """
        Detect volume profile (if visible on chart)
        
        Logic:
        1. Look for volume bars on right side of chart
        2. Measure bar heights
        3. Identify Point of Control (POC)
        
        Returns:
            Dictionary with volume profile data
        """
        
        # Volume is usually on the right side with distinct color
        # This is a simplified approach
        
        right_section = self.gray[:, int(self.width * 0.75):]
        
        # Look for vertical bars (volume bars)
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 5))
        morphed = cv2.morphologyEx(right_section, cv2.MORPH_CLOSE, kernel)
        
        # Find contours
        contours, _ = cv2.findContours(morphed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        volume_bars = []
        for contour in contours:
            x, y, w, h = cv2.boundingRect(contour)
            if w < 20 and h > 10:  # Typical volume bar dimensions
                volume_bars.append({
                    'y': int(y),
                    'height': int(h),
                    'x': int(x),
                    'width': int(w),
                })
        
        if volume_bars:
            # Find POC (highest volume bar)
            poc = max(volume_bars, key=lambda b: b['height'])
            return {
                'detected': True,
                'poc_y': poc['y'],
                'bar_count': len(volume_bars),
                'bars': volume_bars,
            }
        
        return {
            'detected': False,
            'poc_y': None,
            'bar_count': 0,
        }
    
    def analyze(self) -> Dict:
        """
        Run full chart analysis
        
        Returns:
            Complete analysis results
        """
        
        results = {
            'metadata': self.get_metadata(),
            'candlesticks': self.detect_candlesticks(),
            'horizontal_lines': self.detect_horizontal_lines(),
            'price_levels': self.detect_price_levels(),
            'volume_profile': self.detect_volume_profile(),
            'analysis_complete': True,
        }
        
        return results


class ChartAnalyzer:
    """Main analyzer class for API integration"""
    
    @staticmethod
    def analyze_image(image_path: str) -> Dict:
        """Analyze a chart image"""
        try:
            chart = ChartImage(image_path)
            results = chart.analyze()
            results['status'] = 'success'
            return results
        except Exception as e:
            logger.error(f"Analysis failed: {str(e)}")
            return {
                'status': 'error',
                'error': str(e),
            }
```

### STEP 2: Create Express Route

**File:** `server/src/api/chart-analysis.ts`

```typescript
import { Router, Request, Response } from "express";
import multer from "multer";
import path from "path";
import { exec } from "child_process";
import fs from "fs";

const router = Router();

// Setup multer for file uploads
const upload = multer({
  dest: "uploads/charts/",
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    const allowedMimes = ["image/jpeg", "image/png", "image/jpg"];
    if (allowedMimes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Invalid file type. Only JPEG and PNG allowed."));
    }
  },
});

/**
 * POST /api/chart/analyze
 * Analyze a chart image and extract trading information
 */
router.post(
  "/analyze",
  upload.single("chart"),
  async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({
          success: false,
          error: "No file uploaded",
        });
      }

      const imagePath = path.resolve(req.file.path);
      const pythonScript = path.resolve(
        __dirname,
        "../../chart_analyzer.py"
      );

      // Call Python analyzer
      const command = `python "${pythonScript}" "${imagePath}"`;

      exec(command, (error, stdout, stderr) => {
        // Clean up uploaded file
        fs.unlink(imagePath, () => {});

        if (error) {
          console.error("Python error:", stderr);
          return res.status(500).json({
            success: false,
            error: "Chart analysis failed",
            details: stderr,
          });
        }

        try {
          const analysisResults = JSON.parse(stdout);
          return res.json({
            success: true,
            data: analysisResults,
          });
        } catch (parseError) {
          return res.status(500).json({
            success: false,
            error: "Failed to parse analysis results",
          });
        }
      });
    } catch (error) {
      console.error("Upload error:", error);
      return res.status(500).json({
        success: false,
        error: "Upload failed",
      });
    }
  }
);

export default router;
```

### STEP 3: Frontend Component

**File:** `client/src/components/ChartAnalyzer.tsx`

```tsx
import React, { useState, useRef } from 'react';
import { Upload, Loader, AlertCircle, CheckCircle2 } from 'lucide-react';

interface AnalysisResult {
  metadata: {
    width: number;
    height: number;
  };
  candlesticks: {
    count: number;
    confidence: number;
    candlesticks: Array<any>;
  };
  horizontal_lines: Array<any>;
  price_levels: {
    levels: Array<any>;
    count: number;
  };
  volume_profile: any;
}

export function ChartAnalyzer() {
  const [uploading, setUploading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [results, setResults] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!['image/jpeg', 'image/png', 'image/jpg'].includes(file.type)) {
      setError('Only JPEG and PNG files are supported');
      return;
    }

    // Validate file size
    if (file.size > 10 * 1024 * 1024) {
      setError('File size must be less than 10MB');
      return;
    }

    setError(null);
    setUploading(true);
    setAnalyzing(true);

    // Show preview
    const reader = new FileReader();
    reader.onload = (e) => {
      setPreviewImage(e.target?.result as string);
    };
    reader.readAsDataURL(file);

    // Upload and analyze
    const formData = new FormData();
    formData.append('chart', file);

    try {
      const response = await fetch('/api/chart/analyze', {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();

      if (data.success) {
        setResults(data.data);
      } else {
        setError(data.error || 'Analysis failed');
      }
    } catch (err) {
      setError('Upload failed. Please try again.');
      console.error('Upload error:', err);
    } finally {
      setUploading(false);
      setAnalyzing(false);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto p-6 bg-slate-900 rounded-lg border border-emerald-500/20">
      {/* Upload Area */}
      {!previewImage ? (
        <div
          onClick={() => fileInputRef.current?.click()}
          className="border-2 border-dashed border-emerald-500/30 rounded-lg p-12 text-center cursor-pointer hover:border-emerald-500/50 transition-colors"
        >
          <Upload className="w-12 h-12 text-emerald-400 mx-auto mb-4" />
          <p className="text-slate-200 font-medium">
            Click to upload or drag and drop
          </p>
          <p className="text-slate-400 text-sm mt-2">
            PNG or JPEG • Max 10MB
          </p>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileSelect}
            className="hidden"
          />
        </div>
      ) : (
        <div className="space-y-4">
          {/* Image Preview */}
          <div className="relative bg-slate-800 rounded-lg overflow-hidden">
            <img
              src={previewImage}
              alt="Chart preview"
              className="w-full h-auto max-h-96 object-cover"
            />
          </div>

          {/* Loading State */}
          {analyzing && (
            <div className="flex items-center justify-center p-6 bg-slate-800 rounded-lg">
              <Loader className="w-5 h-5 text-emerald-400 animate-spin mr-2" />
              <span className="text-slate-200">Analyzing chart...</span>
            </div>
          )}

          {/* Results */}
          {results && !analyzing && (
            <div className="space-y-4">
              <div className="bg-slate-800 rounded-lg p-4 border border-emerald-500/20">
                <h3 className="text-emerald-400 font-semibold mb-3">
                  Analysis Results
                </h3>

                {/* Candlesticks */}
                {results.candlesticks.count > 0 && (
                  <div className="mb-3 pb-3 border-b border-slate-700">
                    <div className="flex items-center">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 mr-2" />
                      <span className="text-slate-300">
                        Detected {results.candlesticks.count} candlesticks
                      </span>
                    </div>
                    <p className="text-slate-400 text-sm mt-1 ml-6">
                      Confidence: {(
                        results.candlesticks.confidence * 100
                      ).toFixed(0)}%
                    </p>
                  </div>
                )}

                {/* Price Levels */}
                {results.price_levels.count > 0 && (
                  <div className="mb-3 pb-3 border-b border-slate-700">
                    <div className="flex items-center">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 mr-2" />
                      <span className="text-slate-300">
                        Detected {results.price_levels.count} price levels
                      </span>
                    </div>
                  </div>
                )}

                {/* Horizontal Lines */}
                {results.horizontal_lines.length > 0 && (
                  <div className="mb-3 pb-3 border-b border-slate-700">
                    <div className="flex items-center">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 mr-2" />
                      <span className="text-slate-300">
                        Detected {results.horizontal_lines.length} S/R zones
                      </span>
                    </div>
                  </div>
                )}

                {/* Volume Profile */}
                {results.volume_profile.detected && (
                  <div>
                    <div className="flex items-center">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 mr-2" />
                      <span className="text-slate-300">
                        Volume profile detected
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setPreviewImage(null);
                    setResults(null);
                    fileInputRef.current?.click();
                  }}
                  className="flex-1 px-4 py-2 bg-emerald-500/20 text-emerald-400 rounded-lg hover:bg-emerald-500/30 transition-colors"
                >
                  Upload Another
                </button>
                <button
                  onClick={() => {
                    // Use results to pre-fill entry form
                    console.log('Using analysis:', results);
                  }}
                  className="flex-1 px-4 py-2 bg-emerald-500 text-white rounded-lg hover:bg-emerald-600 transition-colors"
                >
                  Use in Entry
                </button>
              </div>
            </div>
          )}

          {/* Error */}
          {error && !analyzing && (
            <div className="flex items-start p-4 bg-red-500/10 rounded-lg border border-red-500/20">
              <AlertCircle className="w-5 h-5 text-red-400 mr-3 mt-0.5 flex-shrink-0" />
              <span className="text-red-200">{error}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
```

---

## Integration Points

### In `NewEntryTab.tsx`:

```tsx
import { ChartAnalyzer } from './ChartAnalyzer';

export function NewEntryTab() {
  return (
    <div className="space-y-6">
      {/* Chart Analyzer Section */}
      <div>
        <h3 className="text-lg font-semibold text-slate-100 mb-4">
          Chart Analysis (Optional)
        </h3>
        <p className="text-sm text-slate-400 mb-4">
          Upload a screenshot of your entry setup. We'll analyze it to extract
          support/resistance levels and help you fill in your entry details.
        </p>
        <ChartAnalyzer />
      </div>

      {/* Existing Form */}
      <NewEntryForm />
    </div>
  );
}
```

---

## Python Installation

Add to `requirements.txt`:

```
opencv-python==4.8.0.74
numpy==1.24.3
scipy==1.11.0
scikit-image==0.21.0
pillow==10.0.0
```

Install:

```bash
pip install -r requirements.txt
```

---

## Testing Checklist

- [ ] Upload MT5 chart screenshot (candlestick)
- [ ] Verify candlestick count is accurate
- [ ] Verify S/R zones detected
- [ ] Test with different chart timeframes
- [ ] Test with different brokers (same logic should work)
- [ ] Measure performance (< 2s processing time)
- [ ] Test error handling (corrupted images, etc.)
- [ ] Verify results pre-fill form correctly

---

## Performance Expectations

| Component | Time | Notes |
|-----------|------|-------|
| Image upload | 200-500ms | Network dependent |
| Candlestick detection | 200-400ms | Fast, well-optimized |
| S/R zone detection | 300-600ms | Depends on chart complexity |
| Volume profile | 100-200ms | Optional |
| **Total** | **800-1700ms** | Sub-2 second target |

---

## Next Steps

1. Install Python dependencies
2. Create `chart_analyzer.py` module
3. Create `/api/chart/analyze` endpoint
4. Build `ChartAnalyzer.tsx` component
5. Integrate into `NewEntryTab.tsx`
6. Test with real MT5 screenshots
7. Iterate based on accuracy feedback

This approach gives you professional chart analysis without AI costs or external dependencies!
