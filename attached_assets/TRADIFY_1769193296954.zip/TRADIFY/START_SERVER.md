# How to Start TRADIFY Development Server

## Quick Start

### Option 1: Use npm.cmd (Recommended for PowerShell)
```powershell
npm.cmd run dev
```

### Option 2: Use Batch File
Double-click `start-dev.bat` or run:
```cmd
start-dev.bat
```

### Option 3: Use PowerShell Script
```powershell
.\start-dev-detailed.ps1
```

### Option 4: Start Servers Separately

**Terminal 1 - Backend:**
```powershell
cd server
npm.cmd run dev
```

**Terminal 2 - Frontend:**
```powershell
cd client
npm.cmd run dev
```

## Expected Output

When servers start successfully, you should see:

**Backend:**
```
🚀 TRADIFY Server running on http://localhost:3002
📊 API docs available at http://localhost:3002/api
```

**Frontend:**
```
  VITE v5.x.x  ready in xxx ms

  ➜  Local:   http://localhost:3000/
  ➜  Network: use --host to expose
```

## Access URLs

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:3002
- **Health Check**: http://localhost:3002/api/health

## Troubleshooting

### Port Already in Use

If you see "port already in use" errors:

1. **Find the process:**
```powershell
netstat -ano | findstr ":3000"
netstat -ano | findstr ":3002"
```

2. **Kill the process** (replace PID with actual process ID):
```powershell
taskkill /PID <PID> /F
```

3. **Or change ports:**
   - Frontend: Edit `client/vite.config.ts` → change `port: 3000`
   - Backend: Edit `server/src/index.ts` → change `PORT = 3002`

### Servers Not Starting

1. **Check dependencies are installed:**
```powershell
npm install
```

2. **Check for errors in terminal output**
3. **Verify Node.js version** (requires 18+):
```powershell
node --version
```

### Connection Refused

If you see "ERR_CONNECTION_REFUSED":

1. **Verify servers are running:**
   - Check terminal for server startup messages
   - Look for "Server running on http://localhost:3002"
   - Look for "Local: http://localhost:3000/"

2. **Check firewall** - Windows Firewall might be blocking ports

3. **Try accessing health endpoint:**
   - Open browser: http://localhost:3002/api/health
   - Should return: `{"status":"ok","timestamp":"...","version":"1.0.0","mode":"read-only"}`

## Still Having Issues?

1. Check `TROUBLESHOOTING.md` for more solutions
2. Verify all files were saved correctly
3. Try restarting your terminal/IDE
4. Check Windows Event Viewer for port conflicts
