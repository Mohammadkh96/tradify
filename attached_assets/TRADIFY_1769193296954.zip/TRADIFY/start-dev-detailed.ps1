# TRADIFY Development Server Startup Script (Detailed Output)
# This script shows detailed output for troubleshooting

Write-Host "🚀 Starting TRADIFY Development Server..." -ForegroundColor Green
Write-Host "Frontend will run on: http://localhost:3000" -ForegroundColor Cyan
Write-Host "Backend will run on: http://localhost:3002" -ForegroundColor Cyan
Write-Host ""

# Check if ports are available
Write-Host "Checking ports..." -ForegroundColor Yellow
$port3000 = Get-NetTCPConnection -LocalPort 3000 -ErrorAction SilentlyContinue
$port3002 = Get-NetTCPConnection -LocalPort 3002 -ErrorAction SilentlyContinue

if ($port3000) {
    Write-Host "⚠️  Port 3000 is already in use!" -ForegroundColor Red
    Write-Host "   Please stop the process using port 3000 or change the port in vite.config.ts" -ForegroundColor Yellow
}

if ($port3002) {
    Write-Host "⚠️  Port 3002 is already in use!" -ForegroundColor Red
    Write-Host "   Please stop the process using port 3002 or change PORT in server/.env.local" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Starting servers with concurrently..." -ForegroundColor Yellow
Write-Host ""

# Use npm.cmd to bypass PowerShell script execution issues
& npm.cmd run dev
