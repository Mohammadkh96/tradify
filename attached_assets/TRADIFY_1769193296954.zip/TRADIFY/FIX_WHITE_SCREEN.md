# 🔧 FIX: White Screen / Connection Refused

## The Problem
- You're seeing a white screen or "connection refused"
- This means **the servers are NOT running**

## ⚠️ IMPORTANT: Which URL to Use

- ❌ **WRONG:** http://localhost:3002 (this is the backend API)
- ✅ **CORRECT:** http://localhost:3000 (this is the frontend app)

## ✅ SOLUTION: Start the Servers

### Step 1: Open PowerShell
Press `Windows Key + X` → Click "Windows PowerShell"

### Step 2: Go to TRADIFY Folder
```powershell
cd "C:\Users\Mohammad\OneDrive - Default Directory\Desktop\TRADIFY"
```

### Step 3: Start Servers
```powershell
npm.cmd run dev
```

### Step 4: WAIT for These Messages
**Don't open browser yet!** Wait for:

✅ **Backend message:**
```
🚀 TRADIFY Server running on http://localhost:3002
```

✅ **Frontend message:**
```
  VITE v5.x.x  ready in xxx ms
  ➜  Local:   http://localhost:3000/
```

### Step 5: Open the CORRECT URL
**ONLY AFTER** seeing both messages above:
- Open: **http://localhost:3000** ← This is the frontend!

---

## 🔍 If You See Errors

### Error: "Cannot find module"
**Fix:**
```powershell
npm install
```
Then try `npm.cmd run dev` again

### Error: "Port already in use"
**Fix:**
```powershell
# Kill all Node processes
taskkill /F /IM node.exe

# Then start again
npm.cmd run dev
```

### Error: "npm is not recognized"
**Fix:** Node.js is not installed. Install from https://nodejs.org/

### Nothing happens / No output
**Fix:** Make sure you're in the TRADIFY folder. Check with:
```powershell
pwd
```
Should show: `C:\Users\Mohammad\OneDrive - Default Directory\Desktop\TRADIFY`

---

## 📋 Quick Checklist

- [ ] PowerShell is open
- [ ] In TRADIFY folder (check with `pwd`)
- [ ] Ran `npm.cmd run dev`
- [ ] Waited 30 seconds
- [ ] Saw BOTH startup messages (backend AND frontend)
- [ ] Opened **http://localhost:3000** (NOT 3002!)

---

## 🧪 Test It's Working

1. **Backend test:** http://localhost:3002/api/health
   - Should show: `{"status":"ok",...}`

2. **Frontend test:** http://localhost:3000
   - Should show: TRADIFY dashboard with sidebar

---

## ⚠️ REMEMBER

1. ✅ **Keep PowerShell window OPEN** - Closing stops servers
2. ✅ **Use port 3000** for the app (not 3002)
3. ✅ **Wait for startup messages** before opening browser
4. ✅ **Both servers must be running** (frontend AND backend)

---

**The servers MUST be running before you can see the dashboard!**
