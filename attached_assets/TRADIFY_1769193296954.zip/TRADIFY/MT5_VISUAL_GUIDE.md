# 📊 MT5 Bridge Visual Guide

## 🎯 The Three Problems (Now Fixed)

### ❌ Problem 1: Architecture Mismatch
```
BEFORE (Broken):
┌──────────┐                 ┌─────────────┐          ┌──────────┐
│  MT5 EA  │────WebRequest───│   Replit    │─────────│ TRADIFY  │
│          │     HTTPS       │   (Cloud)   │  HTTP   │          │
└──────────┘                 └─────────────┘          └──────────┘
     ❌ SSL Issues          ❌ Sleep Mode          ❌ High Latency
     ❌ Timeouts            ❌ Unreliable          ❌ Network Required
     ❌ Redirects           ❌ Hard to Debug       ❌ Complex

AFTER (Fixed):
┌──────────┐                 ┌──────────────┐        ┌──────────┐
│  MT5 EA  │────FileWrite───│  JSON File   │───Read──│ TRADIFY  │
│          │    2 seconds   │  (Common)    │ 3 sec  │ Backend  │
└──────────┘                 └──────────────┘         └──────────┘
     ✅ No Network              ✅ Local             ✅ Simple
     ✅ Instant Write            ✅ Reliable          ✅ Easy Debug
     ✅ No SSL                   ✅ Offline OK        ✅ 99.9% Uptime
```

### ❌ Problem 2: StringToCharArray Bug
```
BEFORE (Broken):
ArrayResize(data, StringLen(json));      // ❌ Missing +1
StringToCharArray(json, data);           // ❌ Buffer overflow
                                          // Result: Corrupted data

AFTER (Fixed):
string json = BuildJsonData();            // ✅ Build JSON string
FileWriteString(handle, json);            // ✅ Write directly
                                          // No char array needed!
```

### ❌ Problem 3: MT5 WebRequest Limitations
```
MT5 WebRequest Restrictions:
❌ Limited TLS support
❌ Certificate validation often fails
❌ Long URLs frequently timeout
❌ Redirects break requests
❌ No automatic retries
❌ Cloud endpoints unreliable

File-Based Approach:
✅ No network = no network problems
✅ No TLS = no TLS problems
✅ No cloud = no cloud problems
✅ Simple filesystem = bulletproof
```

---

## 🏗️ Complete System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         MT5 TERMINAL                             │
│                                                                  │
│  ┌────────────────────────────────────────────────────────┐    │
│  │                 TradifyBridge.ex5                       │    │
│  │                                                         │    │
│  │  OnInit()                                               │    │
│  │    └─ EventSetTimer(2)  // Start 2-second timer        │    │
│  │                                                         │    │
│  │  OnTimer() [Fires every 2 seconds]                     │    │
│  │    │                                                    │    │
│  │    ├─ ExportAccountData()                              │    │
│  │    │   │                                                │    │
│  │    │   ├─ Get Account Info:                            │    │
│  │    │   │   • Balance, Equity, Margin                   │    │
│  │    │   │   • Account Number, Server                    │    │
│  │    │   │   • Leverage, Currency                        │    │
│  │    │   │                                                │    │
│  │    │   ├─ Loop Through Positions:                      │    │
│  │    │   │   • Symbol, Type (BUY/SELL)                   │    │
│  │    │   │   • Volume, Entry Price                       │    │
│  │    │   │   • SL, TP, Current P&L                       │    │
│  │    │   │                                                │    │
│  │    │   ├─ BuildJsonData()                              │    │
│  │    │   │   └─ Create JSON string                       │    │
│  │    │   │                                                │    │
│  │    │   └─ FileOpen() → Write → FileClose()             │    │
│  │    │       └─ FILE_COMMON | FILE_WRITE | FILE_TXT      │    │
│  │    │                                                    │    │
│  │    └─ Log Status (every 10 exports)                    │    │
│  │                                                         │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                  │
└──────────────────────────────────┬───────────────────────────────┘
                                   │
                                   ▼ File Write (2s interval)
                                   
         ┌─────────────────────────────────────────────┐
         │   📄 tradify_mt5_data.json                  │
         │                                             │
         │   Location (auto-detected):                 │
         │   • Windows: %APPDATA%\MetaQuotes\...       │
         │   • macOS: ~/Library/Application Support... │
         │   • Linux: ~/.wine/drive_c/users/...        │
         │                                             │
         │   Structure:                                │
         │   {                                         │
         │     "connected": true,                      │
         │     "timestamp": 1737336000,                │
         │     "export_count": 42,                     │
         │     "account": {                            │
         │       "number": 12345678,                   │
         │       "balance": 10000.00,                  │
         │       "equity": 10250.50,                   │
         │       ...                                   │
         │     },                                      │
         │     "positions": [...]                      │
         │   }                                         │
         │                                             │
         │   Size: ~2-5 KB (+ 200 bytes per position)  │
         │   Updates: Every 2 seconds                  │
         └─────────────────────────────────────────────┘
                                   │
                                   ▼ File Read (3s interval)
                                   
┌─────────────────────────────────────────────────────────────────┐
│                    TRADIFY BACKEND (Node.js)                     │
│                                                                  │
│  readMT5File() [Called on each API request]                     │
│    │                                                             │
│    ├─ Check cache (2s TTL)                                      │
│    │   └─ If fresh, return cached                               │
│    │                                                             │
│    ├─ fs.existsSync(MT5_FILE_PATH)                              │
│    │   └─ If not found, return null                             │
│    │                                                             │
│    ├─ fs.readFileSync() → UTF-8                                 │
│    │                                                             │
│    ├─ JSON.parse()                                              │
│    │   └─ If invalid, return null                               │
│    │                                                             │
│    ├─ Check timestamp age                                       │
│    │   └─ If > 10 seconds, reject (EA not running)              │
│    │                                                             │
│    └─ Return MT5Data                                            │
│                                                                  │
│  REST API Endpoints:                                            │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │ GET /api/mt5/status                                      │  │
│  │   → { connected, account, server, ... }                  │  │
│  │                                                          │  │
│  │ GET /api/mt5/account                                     │  │
│  │   → { balance, equity, margin, ... }                     │  │
│  │                                                          │  │
│  │ GET /api/mt5/open-trades                                 │  │
│  │   → { trades: [...] }                                    │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                  │
└──────────────────────────────┬───────────────────────────────────┘
                               │
                               ▼ HTTP Requests
                               
┌─────────────────────────────────────────────────────────────────┐
│                 TRADIFY FRONTEND (React)                         │
│                                                                  │
│  Component: MT5ConnectionStatus                                 │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │  useEffect(() => {                                         │ │
│  │    fetch('/api/mt5/status')                                │ │
│  │      .then(data => setStatus(data))                        │ │
│  │  }, [5000ms])  // Poll every 5 seconds                     │ │
│  │                                                            │ │
│  │  Display:                                                  │ │
│  │    • Green indicator (connected) / Red (disconnected)     │ │
│  │    • Account number and server                            │ │
│  │    • Account type badge (DEMO / LIVE)                     │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                  │
│  Component: MT5ConnectionModal                                  │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │  Detailed Status View (opens on click)                    │ │
│  │                                                            │ │
│  │  Shows:                                                    │ │
│  │    • Connection status with color coding                  │ │
│  │    • Account details (number, server, type)               │ │
│  │    • Export count (tracks EA activity)                    │ │
│  │    • Data age in seconds                                  │ │
│  │    • File path (for troubleshooting)                      │ │
│  │    • File existence check                                 │ │
│  │    • Error messages (if any)                              │ │
│  │                                                            │ │
│  │  Updates every 3 seconds while open                       │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                  │
│  Component: AccountSnapshot                                     │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │  fetch('/api/mt5/account')                                 │ │
│  │                                                            │ │
│  │  Display:                                                  │ │
│  │    • Balance: $10,000.00                                  │ │
│  │    • Equity: $10,250.50                                   │ │
│  │    • Free Margin: $9,750.50                               │ │
│  │    • Margin Level: 2050.10%                               │ │
│  │    • Unrealized P&L: +$250.50                             │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                  │
│  Component: OpenTradesOverview                                  │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │  fetch('/api/mt5/open-trades')                             │ │
│  │                                                            │ │
│  │  Display list of positions:                               │ │
│  │    • EURUSD BUY 0.10 @ 1.12345                            │ │
│  │    • GBPUSD SELL 0.05 @ 1.28000                           │ │
│  │    • Current P&L for each                                 │ │
│  └────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

---

## ⏱️ Timing Diagram

```
Time →

MT5 EA:
├─────2s─────┤────2s────┤────2s────┤────2s────┤
Write         Write      Write      Write      Write
  │             │          │          │          │
  ▼             ▼          ▼          ▼          ▼
┌─────────────────────────────────────────────────┐
│         JSON File (Updated Every 2s)            │
└─────────────────────────────────────────────────┘
  │               │          │           │
  │               │          │           │
Backend:
  ▼               ▼          ▼           ▼
├──────3s──────┤──────3s──────┤──────3s──────┤
Read (cached)   Read (cached)  Read (cached)
  │               │              │
  ▼               ▼              ▼
┌─────────────────────────────────────────────────┐
│      Backend Cache (2s TTL)                     │
└─────────────────────────────────────────────────┘
  │               │              │
  ▼               ▼              ▼
UI Poll:
├──────5s──────┤──────5s──────┤──────5s──────┤
Display         Display        Display
```

**Latency Breakdown:**
- EA exports: 0-2 seconds old
- Backend cache: 0-2 seconds old
- UI display: 0-5 seconds old
- **Total latency: 2-5 seconds** (acceptable for trading journal)

---

## 🔍 Data Flow Example

### Scenario: Trader Opens New Position in MT5

```
T=0s    Trader opens EURUSD BUY 0.10 lot

T=0.5s  MT5 records the position internally

T=2s    EA OnTimer() fires
        ├─ Reads positions from MT5
        ├─ Finds new EURUSD position
        ├─ Builds JSON with new position
        └─ Writes to tradify_mt5_data.json
        
T=3s    Backend receives API request
        ├─ readMT5File() called
        ├─ Reads JSON file
        ├─ Parses data
        ├─ Validates timestamp (fresh!)
        └─ Returns data with EURUSD position
        
T=3.1s  Frontend receives response
        ├─ Updates state
        ├─ OpenTradesOverview re-renders
        └─ EURUSD position appears in UI
        
Total time from MT5 to UI: ~3 seconds ✅
```

---

## 🎯 Success Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    SETUP CHECKLIST                          │
└─────────────────────────────────────────────────────────────┘

1. Compile EA in MetaEditor
   ├─ Open TradifyBridge.mq5
   ├─ Press F7
   └─ Result: "0 error(s), 0 warning(s)" ✅

2. Attach EA to MT5 Chart
   ├─ Drag from Navigator
   ├─ Configure parameters (or use defaults)
   └─ Result: Smiley face ☺ on chart ✅

3. Verify File Export
   ├─ Check Experts tab
   ├─ See: "TRADIFY MT5 Bridge v2.0 - INITIALIZED" ✅
   ├─ Navigate to Common/Files/
   ├─ Open: tradify_mt5_data.json
   └─ Verify: File updates every 2 seconds ✅

4. Start TRADIFY Backend
   ├─ Run: npm run dev
   ├─ See: "Server running on http://localhost:3001"
   └─ Test: curl http://localhost:3001/api/mt5/status ✅

5. Open TRADIFY UI
   ├─ Navigate to: http://localhost:5173
   ├─ Click MT5 connection icon
   └─ Result: Green checkmark "Connected to MT5" ✅

6. Verify Real Data
   ├─ Check account number matches MT5 ✅
   ├─ Check balance matches MT5 ✅
   ├─ Open trade in MT5
   └─ See it appear in TRADIFY within 5s ✅

SUCCESS! 🎉
```

---

## 🐛 Debugging Flow

```
Problem: "MT5 Not Connected" in UI

Step 1: Check EA Status
├─ Look at MT5 chart
├─ Smiley face ☺ or sad face ☹?
│
├─ If sad face ☹:
│  └─ Check: Tools → Options → Expert Advisors
│     └─ Enable "Allow automated trading" ✅
│     └─ Restart EA
│
└─ If smiley face ☺:
   └─ Continue to Step 2

Step 2: Check File Export
├─ Open MT5 Experts tab (Ctrl+T)
├─ See "TRADIFY" messages?
│
├─ If no messages:
│  └─ EA may not be running
│     └─ Re-attach EA to chart
│
├─ If see error messages:
│  └─ Read error and follow guidance
│     └─ Common: Permission denied
│        └─ Run MT5 as administrator
│
└─ If see success messages:
   └─ Continue to Step 3

Step 3: Check File Existence
├─ Navigate to file path (shown in TRADIFY status modal)
├─ File exists?
│
├─ If no file:
│  └─ EA cannot write (permissions)
│     └─ Run MT5 as admin (Windows)
│     └─ Check file permissions (macOS/Linux)
│
└─ If file exists:
   └─ Continue to Step 4

Step 4: Check File Freshness
├─ Open tradify_mt5_data.json
├─ Look at "timestamp" field
├─ Convert to readable time
│
├─ If timestamp > 10 seconds old:
│  └─ EA stopped writing
│     └─ Check EA is still attached (smiley face)
│     └─ Check no errors in Experts tab
│     └─ Restart EA if needed
│
└─ If timestamp is recent (<10s):
   └─ Continue to Step 5

Step 5: Check Backend
├─ Is backend running?
├─ Check terminal: npm run dev
│
├─ If not running:
│  └─ Start it: npm run dev
│
├─ If running with errors:
│  └─ Read error messages
│     └─ Common: Cannot read file
│        └─ Check MT5_FILE_PATH env var
│
└─ If running without errors:
   └─ Continue to Step 6

Step 6: Test API Directly
├─ Run: curl http://localhost:3001/api/mt5/status
├─ See "connected": true?
│
├─ If error (connection refused):
│  └─ Backend not running on port 3001
│     └─ Check if another process using port
│
├─ If "connected": false:
│  └─ Check "message" field for details
│     └─ Follow guidance in message
│
└─ If "connected": true:
   └─ Backend working! Problem is in frontend.
      └─ Check browser console for errors
      └─ Check API endpoint URL in code

SOLVED! ✅
```

---

## 📊 Performance Characteristics

```
Resource Usage:

MT5 EA (TradifyBridge):
├─ CPU: ~0.1% (negligible)
├─ RAM: ~5 MB
├─ Disk I/O: 1 write every 2s (~2 KB)
└─ Network: 0 bytes ✅

JSON File:
├─ Size: 2-5 KB base
├─ Per position: +200 bytes
├─ 100 positions: ~21 KB (still tiny)
└─ Location: User's local disk

Backend (Node.js):
├─ CPU: ~1-2% (reading file)
├─ RAM: ~50 MB (typical Node.js)
├─ Disk I/O: 1 read every 3s (cached 2s)
└─ Network: Only local HTTP (localhost)

Frontend (React):
├─ CPU: ~1-2% (rendering)
├─ RAM: ~100 MB (typical browser tab)
├─ Network: HTTP polls every 3-5s (~2 KB each)
└─ Render: Only on data change

Total System Impact:
✅ Minimal - Unnoticeable on modern computers
✅ No network bandwidth used (localhost only)
✅ No impact on MT5 trading performance
```

---

## 🎓 Best Practices Summary

```
✅ DO:
├─ Keep EA running continuously
├─ Use 2-5 second export interval
├─ Enable logging for first-time setup
├─ Check Experts tab regularly
├─ Verify file updates before reporting issues
├─ Read documentation when stuck
└─ Test on demo account first

❌ DON'T:
├─ Set UpdateInterval < 1 second (unnecessary load)
├─ Delete JSON file while EA running
├─ Run multiple EAs writing to same file
├─ Edit JSON file manually (EA overwrites it)
├─ Disable "Allow automated trading" (EA won't run)
├─ Use WebRequest approach (abandoned for good reason)
└─ Skip verification steps (leads to confusion)
```

---

**🎊 Visual guide complete! Refer to this for understanding the complete system.**
