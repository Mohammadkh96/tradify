# 🚨 START HERE FIRST - Servers Not Running

## The Problem
"localhost refused to connect" = **Servers are NOT running**

You MUST start the servers before opening the browser!

---

## ✅ STEP-BY-STEP SOLUTION

### Step 1: Open PowerShell
1. Press `Windows Key + X`
2. Click "Windows PowerShell" or "Terminal"
3. Navigate to TRADIFY folder:
   ```powershell
   cd "C:\Users\Mohammad\OneDrive - Default Directory\Desktop\TRADIFY"
   ```

### Step 2: Kill Any Old Processes
```powershell
taskkill /F /IM node.exe
```

### Step 3: Start the Servers
```powershell
npm.cmd run dev
```

### Step 4: WAIT 20-30 SECONDS
**Don't open browser yet!** Wait for these messages:

✅ **Backend should show:**
```
🚀 TRADIFY Server running on http://localhost:3002
```

✅ **Frontend should show:**
```
  VITE v5.x.x  ready in xxx ms
  ➜  Local:   http://localhost:3000/
```

### Step 5: Open Browser
**ONLY AFTER** you see both messages above:
- Open: **http://localhost:3000**

---

## 🔍 TROUBLESHOOTING

### If you see "npm is not recognized":
→ Node.js is not installed
→ **Fix:** Install Node.js from https://nodejs.org/

### If you see "Cannot find module":
→ Dependencies not installed
→ **Fix:** Run `npm install` first, then `npm.cmd run dev`

### If you see "Port already in use":
→ Something else is using ports 3000/3002
→ **Fix:** 
```powershell
# Find what's using the port
netstat -ano | findstr ":3000"
netstat -ano | findstr ":3002"

# Kill it (replace PID with number from above)
taskkill /PID <PID> /F
```

### If nothing happens / blank terminal:
→ Check you're in the right folder
→ **Fix:** Make sure you see `TRADIFY` in your PowerShell prompt

### If servers start but browser still shows "refused":
→ Wait longer (30 seconds)
→ Try: http://127.0.0.1:3000 instead of localhost:3000
→ Check Windows Firewall isn't blocking

---

## 📋 QUICK CHECKLIST

- [ ] PowerShell is open
- [ ] In TRADIFY folder (check with `pwd`)
- [ ] Ran `npm.cmd run dev`
- [ ] Waited 20-30 seconds
- [ ] Saw "Server running" messages
- [ ] Opened http://localhost:3000

---

## 🎯 ALTERNATIVE: Start Servers Separately

If `npm.cmd run dev` doesn't work, try starting them separately:

**Terminal 1 - Backend:**
```powershell
cd "C:\Users\Mohammad\OneDrive - Default Directory\Desktop\TRADIFY\server"
npm.cmd run dev
```

**Terminal 2 - Frontend (NEW terminal):**
```powershell
cd "C:\Users\Mohammad\OneDrive - Default Directory\Desktop\TRADIFY\client"
npm.cmd run dev
```

---

## ⚠️ IMPORTANT REMINDERS

1. ✅ **Keep terminal window OPEN** - Closing stops servers
2. ✅ **Wait for startup messages** - Don't rush
3. ✅ **Both servers must start** - Frontend AND Backend
4. ✅ **Start servers FIRST** - Then open browser

---

## 🧪 TEST IT'S WORKING

**Test Backend:**
- Open: http://localhost:3002/api/health
- Should show: `{"status":"ok","timestamp":"...","version":"1.0.0","mode":"read-only"}`

**Test Frontend:**
- Open: http://localhost:3000
- Should show: TRADIFY dashboard with sidebar and content

---

**Remember: Servers MUST be running before you can access the app!**

If you're still having issues, check the terminal for error messages and share them.
