# 🚀 MT5 Bridge Setup Guide - Local File-Based (Production Ready)

## 📋 Overview

This is the **correct, stable, production-ready architecture** for MT5 integration:

```
┌──────────────┐         ┌─────────────────┐         ┌──────────────┐
│   MT5 EA     │ ──────► │   JSON File     │ ◄────── │   TRADIFY    │
│ TradifyBridge│  Write  │   (Common)      │   Read  │   Backend    │
└──────────────┘  2s     └─────────────────┘   3s    └──────────────┘
     Timer               Shared Folder              API Polling
```

**Why This Works:**
- ✅ No network complexity
- ✅ No SSL/TLS issues
- ✅ No WebRequest limitations
- ✅ Works 100% offline
- ✅ Easy to debug (just open the JSON file)
- ✅ Production-proven approach

---

## 🔧 Installation Steps

### Step 1: Compile the Expert Advisor

1. **Open MetaEditor** (press F4 in MT5)

2. **Open TradifyBridge.mq5**
   - File → Open → Navigate to: `TRADIFY/tradify-bridge/ea/TradifyBridge.mq5`

3. **Compile the EA** 
   - Press F7 or click "Compile" button
   - Should see: `0 error(s), 0 warning(s)`
   - This creates `TradifyBridge.ex5` in the same folder

4. **Refresh MT5 Navigator**
   - In MT5, press Ctrl+N to open Navigator
   - Right-click "Expert Advisors" → Refresh

---

### Step 2: Attach EA to Chart

1. **Open any chart** in MT5 (symbol doesn't matter - EA runs globally)

2. **Drag `TradifyBridge` EA onto the chart**
   - From Navigator → Expert Advisors → TradifyBridge

3. **Configure Parameters** (dialog box appears):
   ```
   UpdateInterval: 2        (export every 2 seconds)
   ExportFileName: tradify_mt5_data.json
   EnableLogging: true      (see console messages)
   ```

4. **Enable "Allow DLL imports"** ✅ (if prompted)

5. **Click OK**

6. **Verify EA is running:**
   - Smiley face icon in top-right corner of chart should be **smiling** ☺
   - Check "Experts" tab (Ctrl+T) at bottom of MT5
   - Should see: `TRADIFY MT5 Bridge v2.0 - INITIALIZED`

---

### Step 3: Verify File Export

1. **Find the export file location:**

   **Windows:**
   ```
   C:\Users\<YourUsername>\AppData\Roaming\MetaQuotes\Terminal\Common\Files\tradify_mt5_data.json
   ```

   **macOS:**
   ```
   ~/Library/Application Support/MetaQuotes/Terminal/Common/Files/tradify_mt5_data.json
   ```

   **Linux (Wine):**
   ```
   ~/.wine/drive_c/users/<username>/Application Data/MetaQuotes/Terminal/Common/Files/tradify_mt5_data.json
   ```

2. **Open the file** with any text editor

3. **Verify JSON content:**
   ```json
   {
     "connected": true,
     "timestamp": 1737336000,
     "timestamp_iso": "2026-01-19 14:30:00",
     "export_count": 15,
     "account": {
       "number": 12345678,
       "name": "Your Name",
       "server": "Broker-Server",
       "balance": 10000.00,
       "equity": 10250.50,
       ...
     },
     "positions": [...]
   }
   ```

4. **Watch it update** - refresh the file every 2 seconds to see new data

---

### Step 4: Start TRADIFY Backend

1. **Open terminal** in TRADIFY folder:
   ```bash
   cd /workspaces/TRADIFY
   ```

2. **Install dependencies** (if not already done):
   ```bash
   npm install
   ```

3. **Start the backend:**
   ```bash
   npm run dev
   ```

4. **Backend should start on port 3001**

5. **Optional: Set custom file path** (if MT5 is in non-standard location):
   ```bash
   export MT5_FILE_PATH="/path/to/your/tradify_mt5_data.json"
   npm run dev
   ```

---

### Step 5: Test Connection in TRADIFY

1. **Open TRADIFY frontend:**
   ```
   http://localhost:5173
   ```

2. **Click the MT5 connection icon** (top right or dashboard)

3. **Check Status Modal:**

   **✅ Connected State:**
   - Shows green checkmark
   - Displays account number, server, type (DEMO/LIVE)
   - Shows export count and last update time

   **⚠️ Disconnected State:**
   - Shows amber warning
   - Displays expected file path
   - Shows whether file exists
   - Helpful troubleshooting info

---

## 🐛 Troubleshooting

### Problem: "EA not detected"

**Check 1: Is EA running?**
- Look for smiley face ☺ on chart (not sad face ☹)
- Check Experts tab for initialization message

**Check 2: Does file exist?**
- Navigate to file path shown in TRADIFY status modal
- File should exist and update every 2 seconds

**Check 3: Is file recent?**
- Open JSON file
- Check `timestamp` field - should be within last 10 seconds
- If old, EA may have stopped

**Check 4: MT5 Terminal settings**
- Tools → Options → Expert Advisors
- ✅ "Allow automated trading" must be enabled
- ✅ "Allow DLL imports" (not needed but good to have)

---

### Problem: File exists but TRADIFY says "Not connected"

**Check: File timestamp**
- File might be stale (EA stopped but file remains)
- Backend rejects data older than 10 seconds
- Restart EA to fix

**Check: Backend logs**
- Look at terminal running `npm run dev`
- Should see no errors reading file
- If parsing errors, file might be corrupted

---

### Problem: Permission denied reading file

**Windows:**
- Run MT5 as Administrator (right-click → Run as administrator)

**macOS/Linux:**
- Check file permissions: `ls -la <file path>`
- Should be readable by your user

---

### Problem: Can't find Common/Files folder

**MT5 File Locations:**

The EA exports to `FILE_COMMON` which is MT5's shared folder:

**To find it in MT5:**
1. File → Open Data Folder
2. Navigate to `Common/Files/`
3. Or check Experts tab - EA logs the full path on startup

**Typical paths:**
- Windows: `%APPDATA%\MetaQuotes\Terminal\Common\Files\`
- macOS: `~/Library/Application Support/MetaQuotes/Terminal/Common/Files/`

---

## 📊 What Data is Exported

The EA exports comprehensive data every 2 seconds:

### Account Information
- Account number, name, server, currency
- Balance, equity, profit
- Margin, free margin, margin level
- Leverage

### Open Positions
- Ticket number, symbol, type (BUY/SELL)
- Volume, entry price, current price
- Stop loss, take profit
- Current profit/loss, swap
- Open time

### Metadata
- Export timestamp (Unix + ISO format)
- Export counter (tracks EA activity)
- Connection status

---

## 🔒 Security & Privacy

**Local Only:**
- ✅ Data never leaves your machine
- ✅ No cloud servers involved
- ✅ No credentials required
- ✅ Works completely offline

**File Permissions:**
- File is in your user directory
- Only you (and TRADIFY) can read it
- Standard OS file permissions apply

---

## ⚡ Performance

**Resource Usage:**
- **CPU:** Minimal (~0.1% on modern CPU)
- **Memory:** ~5MB in MT5
- **Disk I/O:** 1 small write every 2 seconds (~2KB)
- **Network:** Zero (no network calls)

**Timing:**
- EA exports every 2 seconds
- TRADIFY reads every 3 seconds
- Data age tolerance: 10 seconds max

---

## 🎯 Best Practices

### ✅ DO:
- Keep UpdateInterval at 2-5 seconds (good balance)
- Enable logging for first-time setup
- Check Experts tab regularly for errors
- Verify file updates before assuming connection

### ❌ DON'T:
- Set UpdateInterval to less than 1 second (unnecessary load)
- Delete the JSON file while EA is running
- Run multiple EAs writing to same file
- Edit the JSON file manually (EA overwrites it)

---

## 🚀 Future Upgrade Path

Once this is stable, you can optionally upgrade to:

```
MT5 EA → File → Local HTTP Service → TRADIFY
          ↓
     (Optional)
  WebSocket Push
```

**Benefits of HTTP Service:**
- Real-time push updates (WebSocket)
- Data transformation/aggregation
- Multiple app connections
- Historical data buffering

**Still 100% local** - no cloud fragility.

---

## 📞 Support

**EA Not Starting?**
- Check MT5 Experts tab for error messages
- Verify MT5 build number (should be recent)
- Try recompiling EA (F7 in MetaEditor)

**File Not Updating?**
- Check EA is still running (smiley face)
- Look for error messages in Experts tab
- Restart EA

**TRADIFY Not Connecting?**
- Verify backend is running on port 3001
- Check backend console for file read errors
- Verify file path in status modal

---

## ✅ Verification Checklist

Before reporting issues, verify:

- [ ] EA compiled successfully (0 errors)
- [ ] EA attached to chart (smiley face visible)
- [ ] "Allow automated trading" enabled in MT5
- [ ] JSON file exists at expected path
- [ ] JSON file updates every 2 seconds
- [ ] File timestamp is recent (<10 seconds old)
- [ ] TRADIFY backend running on port 3001
- [ ] Browser can reach http://localhost:5173
- [ ] No CORS errors in browser console

---

## 🎉 Success Indicators

**You'll know it's working when:**

1. **MT5 Experts Tab:**
   ```
   TRADIFY MT5 Bridge v2.0 - INITIALIZED
   TRADIFY: Export #10 completed at 2026-01-19 14:30:00
   TRADIFY: Export #20 completed at 2026-01-19 14:30:20
   ```

2. **JSON File:**
   - Updates every 2 seconds
   - Contains current account data
   - Shows recent timestamp

3. **TRADIFY Status Modal:**
   - Green checkmark "Connected to MT5"
   - Shows your account number and server
   - Export count incrementing
   - Data age: <5 seconds

4. **Dashboard:**
   - Account snapshot shows real MT5 data
   - Open trades display correctly
   - Updates in real-time

---

**🎊 Congratulations! Your MT5 bridge is now running!**

This is the foundation. From here, you can:
- View real-time account data in TRADIFY
- Monitor open positions
- Track performance
- Enforce trading rules

**Next:** Consider adding trade import functionality to automatically log MT5 trades into TRADIFY journal.
