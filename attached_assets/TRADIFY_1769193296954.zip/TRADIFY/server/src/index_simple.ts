import express, { Request, Response } from "express";
import cors from "cors";
import compression from "compression";

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(compression({ level: 6 }));
app.use(cors());
app.use(express.json({ limit: "50mb" }));

// Cache
const cache = new Map<string, { data: any; timestamp: number }>();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

function getCache(key: string) {
  const cached = cache.get(key);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    return cached.data;
  }
  cache.delete(key);
  return null;
}

function setCache(key: string, data: any) {
  cache.set(key, { data, timestamp: Date.now() });
}

// Health check
app.get("/api/health", (req: Request, res: Response) => {
  res.json({ status: "ok" });
});

// MT5 Connection State
let mt5Connection: { 
  account: string;
  server: string;
  connected: boolean;
  accountType: "demo" | "live";
  broker: string;
  lastSync: Date;
} | null = null;

// MT5 Connect
app.post("/api/mt5/connect", async (req: Request, res: Response) => {
  try {
    const { account, password, server } = req.body;

    if (!account || !password || !server) {
      return res.status(400).json({ error: "Missing fields" });
    }

    console.log(`📡 Connecting to MT5 - Account: ${account}, Server: ${server}`);
    await new Promise(resolve => setTimeout(resolve, 1000));

    mt5Connection = {
      account,
      server,
      connected: true,
      accountType: server.toLowerCase().includes("demo") ? "demo" : "live",
      broker: server,
      lastSync: new Date()
    };

    res.json({ 
      success: true, 
      message: "Connected to MT5 successfully",
      connection: {
        account: mt5Connection.account,
        server: mt5Connection.server,
        connected: mt5Connection.connected,
        accountType: mt5Connection.accountType
      }
    });
  } catch (error) {
    console.error("MT5 connection error:", error);
    res.status(500).json({ error: "Failed to connect to MT5" });
  }
});

// MT5 Disconnect
app.post("/api/mt5/disconnect", async (req: Request, res: Response) => {
  try {
    if (!mt5Connection) {
      return res.status(400).json({ error: "No active MT5 connection" });
    }

    console.log(`📡 Disconnecting from MT5 - Account: ${mt5Connection.account}`);
    mt5Connection = null;

    res.json({ 
      success: true, 
      message: "Disconnected from MT5 successfully" 
    });
  } catch (error) {
    console.error("MT5 disconnection error:", error);
    res.status(500).json({ error: "Failed to disconnect from MT5" });
  }
});

// MT5 Status
app.get("/api/mt5/status", (req: Request, res: Response) => {
  res.json({ 
    connected: mt5Connection?.connected || false,
    account: mt5Connection?.account || null,
    server: mt5Connection?.server || null,
    accountType: mt5Connection?.accountType || null,
    lastSync: mt5Connection?.lastSync?.toISOString() || null
  });
});

// MT5 Account Data
app.get("/api/mt5/account", async (req: Request, res: Response) => {
  try {
    if (!mt5Connection?.connected) {
      return res.status(400).json({ error: "Not connected to MT5" });
    }

    const accountData = {
      balance: 10000 + (Math.random() * 100 - 50),
      equity: 10250 + (Math.random() * 100 - 50),
      freeMargin: 9500 + (Math.random() * 100 - 50),
      marginLevel: 1025 + (Math.random() * 50 - 25),
      unrealizedPL: 250 + (Math.random() * 50 - 25),
      dailyPL: 180 + (Math.random() * 50 - 25),
    };

    res.json({ success: true, account: accountData });
  } catch (error) {
    console.error("Failed to fetch account data:", error);
    res.status(500).json({ error: "Failed to fetch account data" });
  }
});

// MT5 Open Trades
app.get("/api/mt5/open-trades", (req: Request, res: Response) => {
  try {
    if (!mt5Connection?.connected) {
      return res.json({ success: true, trades: [] });
    }

    const openTrades = [
      {
        id: "1",
        symbol: "EURUSD",
        direction: "long",
        lotSize: 0.1,
        entryPrice: 1.0850,
        currentPrice: 1.0865,
        floatingPL: 15.0,
        riskReward: 2.5,
        openTime: new Date(Date.now() - 3600000),
      },
    ];

    res.json({ success: true, trades: openTrades });
  } catch (error) {
    console.error("Failed to fetch open trades:", error);
    res.status(500).json({ error: "Failed to fetch open trades" });
  }
});

// MT5 Risk Exposure
app.get("/api/mt5/risk-exposure", (req: Request, res: Response) => {
  try {
    if (!mt5Connection?.connected) {
      return res.json({
        success: true,
        risk: {
          totalOpenRisk: 0,
          riskPerSymbol: [],
          riskPerSession: [],
          maxDailyRisk: 5.0,
          currentExposure: 0,
          warnings: [],
        },
      });
    }

    const riskData = {
      totalOpenRisk: 2.5,
      riskPerSymbol: [{ symbol: "EURUSD", risk: 1.5 }],
      riskPerSession: [{ session: "London", risk: 1.5 }],
      maxDailyRisk: 5.0,
      currentExposure: 2.5,
      warnings: [] as string[],
    };

    if (riskData.currentExposure > riskData.maxDailyRisk * 0.8) {
      riskData.warnings.push("Risk exposure above 80% of daily limit");
    }

    res.json({ success: true, risk: riskData });
  } catch (error) {
    console.error("Failed to fetch risk exposure:", error);
    res.status(500).json({ error: "Failed to fetch risk exposure" });
  }
});

// Compliance
app.get("/api/compliance", (req: Request, res: Response) => {
  try {
    const cached = getCache("compliance");
    if (cached) {
      return res.json(cached);
    }

    const complianceData = {
      tradesAlignedPercent: 85,
      totalTrades: 20,
      alignedTrades: 17,
      violatingTrades: [],
      emotionalDisciplineScore: 78,
      ruleBreakdowns: [],
    };

    const response = { success: true, compliance: complianceData };
    setCache("compliance", response);
    res.json(response);
  } catch (error) {
    console.error("Failed to fetch compliance data:", error);
    res.status(500).json({ error: "Failed to fetch compliance data" });
  }
});

// Discipline Alerts
app.get("/api/discipline-alerts", (req: Request, res: Response) => {
  try {
    const alerts = [
      {
        type: "rule",
        message: "Remember: Always set a stop-loss before entering a trade",
        priority: "high",
      },
    ];

    res.json({ success: true, alerts });
  } catch (error) {
    console.error("Failed to fetch discipline alerts:", error);
    res.status(500).json({ error: "Failed to fetch discipline alerts" });
  }
});

// Start server
async function start() {
  app.listen(PORT, () => {
    console.log(`\n🚀 TRADIFY Server running on http://localhost:${PORT}`);
    console.log(`📊 MT5 Dashboard API ready`);
  });
}

start().catch((error) => {
  console.error("Fatal error:", error);
  process.exit(1);
});
