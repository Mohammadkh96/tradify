/**
 * Structured Logging
 * All rule evaluations and important events are logged
 */

export interface LogEntry {
  timestamp: string;
  level: "info" | "warn" | "error" | "debug";
  message: string;
  context?: Record<string, unknown>;
}

export class Logger {
  private static formatLog(entry: LogEntry): string {
    return JSON.stringify({
      ...entry,
      timestamp: new Date().toISOString(),
    });
  }

  static info(message: string, context?: Record<string, unknown>): void {
    const entry: LogEntry = {
      timestamp: new Date().toISOString(),
      level: "info",
      message,
      context,
    };
    console.log(this.formatLog(entry));
  }

  static warn(message: string, context?: Record<string, unknown>): void {
    const entry: LogEntry = {
      timestamp: new Date().toISOString(),
      level: "warn",
      message,
      context,
    };
    console.warn(this.formatLog(entry));
  }

  static error(message: string, context?: Record<string, unknown>): void {
    const entry: LogEntry = {
      timestamp: new Date().toISOString(),
      level: "error",
      message,
      context,
    };
    console.error(this.formatLog(entry));
  }

  static debug(message: string, context?: Record<string, unknown>): void {
    if (process.env.NODE_ENV === "development") {
      const entry: LogEntry = {
        timestamp: new Date().toISOString(),
        level: "debug",
        message,
        context,
      };
      console.debug(this.formatLog(entry));
    }
  }

  /**
   * Log rule evaluation for audit trail
   */
  static logRuleEvaluation(
    facts: Record<string, unknown>,
    result: { isValid: boolean; violations: Array<{ rule_id: string; rule_name: string; reason: string }> }
  ): void {
    this.info("Rule evaluation completed", {
      isValid: result.isValid,
      violations: result.violations,
      facts: {
        asset: facts.asset,
        direction: facts.direction,
        htfBias: facts.htfBias,
        entryType: facts.entryType,
      },
    });
  }
}
