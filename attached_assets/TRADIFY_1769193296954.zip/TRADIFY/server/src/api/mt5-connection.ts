/**
 * MT5 Connection API
 * Handles user MT5 terminal connections and account synchronization
 */

import { Router, Request, Response } from "express";
import crypto from "crypto";
import { db } from "../db";
import { tradeJournal } from "../schema";

const router = Router();

// Demo mode: In-memory storage for MT5 connections
const demoMt5Connections: Map<string, any> = new Map();
const demoConnectionTokens: Map<string, any> = new Map();
const demoSyncedTrades: Map<string, any> = new Map();

/**
 * POST /api/mt5/initiate-connection
 * User initiates a new MT5 connection
 * Returns a connection token that the local connector will use
 */
router.post("/initiate-connection", (req: Request, res: Response) => {
  try {
    const { userId, accountNumber, broker } = req.body;

    // Validation
    if (!userId || !accountNumber || !broker) {
      return res.status(400).json({
        success: false,
        error: "Missing required fields: userId, accountNumber, broker",
      });
    }

    // Generate unique connection token (valid for 15 minutes)
    const connectionToken = crypto.randomBytes(32).toString("hex");
    const tokenExpiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes

    // Store token in demo mode
    demoConnectionTokens.set(connectionToken, {
      userId,
      accountNumber,
      broker,
      expiresAt: tokenExpiresAt,
      createdAt: new Date(),
    });

    return res.json({
      success: true,
      connectionToken,
      expiresIn: 900, // 15 minutes in seconds
      message:
        "Connection token generated. Use this in your local MT5 connector.",
    });
  } catch (error) {
    console.error("Error initiating connection:", error);
    return res.status(500).json({
      success: false,
      error: "Failed to initiate connection",
    });
  }
});

/**
 * POST /api/mt5/register-connection
 * Local connector registers the connection after user authenticates
 * This endpoint is called by the local MT5 connector application
 */
router.post("/register-connection", (req: Request, res: Response) => {
  try {
    const {
      connectionToken,
      accountName,
      serverName,
      connectorVersion,
      localConnectorIP,
    } = req.body;

    if (!connectionToken) {
      return res.status(400).json({
        success: false,
        error: "Connection token required",
      });
    }

    // Validate token
    const tokenData = demoConnectionTokens.get(connectionToken);
    if (!tokenData) {
      return res.status(401).json({
        success: false,
        error: "Invalid or expired connection token",
      });
    }

    // Check expiration
    if (new Date() > tokenData.expiresAt) {
      demoConnectionTokens.delete(connectionToken);
      return res.status(401).json({
        success: false,
        error: "Connection token has expired",
      });
    }

    // Create connection record
    const connectionId = `conn_${crypto.randomBytes(8).toString("hex")}`;
    const connection = {
      id: connectionId,
      userId: tokenData.userId,
      accountNumber: tokenData.accountNumber,
      accountName,
      broker: tokenData.broker,
      serverName,
      isConnected: true,
      connectionStatus: "CONNECTED",
      connectorVersion,
      localConnectorIP,
      lastConnectedAt: new Date(),
      connectionToken: null, // Token consumed, don't store
      createdAt: new Date(),
      updatedAt: new Date(),
      accountBalance: 10000,
      accountEquity: 10000,
      accountMargin: 0,
      accountFreeMargin: 10000,
      accountProfit: 0,
    };

    // Store connection
    demoMt5Connections.set(connectionId, connection);

    // Clean up token
    demoConnectionTokens.delete(connectionToken);

    return res.json({
      success: true,
      connectionId,
      message: "MT5 connection registered successfully",
      connection,
    });
  } catch (error) {
    console.error("Error registering connection:", error);
    return res.status(500).json({
      success: false,
      error: "Failed to register connection",
    });
  }
});

/**
 * GET /api/mt5/status/:connectionId
 * Get current connection status
 */
router.get("/status/:connectionId", (req: Request, res: Response) => {
  try {
    const { connectionId } = req.params;

    const connection = demoMt5Connections.get(connectionId);
    if (!connection) {
      return res.status(404).json({
        success: false,
        error: "Connection not found",
      });
    }

    return res.json({
      success: true,
      connection: {
        id: connection.id,
        accountNumber: connection.accountNumber,
        accountName: connection.accountName,
        broker: connection.broker,
        isConnected: connection.isConnected,
        connectionStatus: connection.connectionStatus,
        lastConnectedAt: connection.lastConnectedAt,
        accountBalance: connection.accountBalance,
        accountEquity: connection.accountEquity,
        accountMargin: connection.accountMargin,
        accountFreeMargin: connection.accountFreeMargin,
        accountProfit: connection.accountProfit,
      },
    });
  } catch (error) {
    console.error("Error fetching connection status:", error);
    return res.status(500).json({
      success: false,
      error: "Failed to fetch connection status",
    });
  }
});

/**
 * GET /api/mt5/connections/:userId
 * Get all MT5 connections for a user
 */
router.get("/connections/:userId", (req: Request, res: Response) => {
  try {
    const { userId } = req.params;

    const connections = Array.from(demoMt5Connections.values()).filter(
      (conn) => conn.userId == userId
    );

    return res.json({
      success: true,
      count: connections.length,
      connections,
    });
  } catch (error) {
    console.error("Error fetching connections:", error);
    return res.status(500).json({
      success: false,
      error: "Failed to fetch connections",
    });
  }
});

/**
 * POST /api/mt5/sync-account-data/:connectionId
 * Local connector sends account data update
 * Called periodically by the local connector
 */
router.post("/sync-account-data/:connectionId", (req: Request, res: Response) => {
  try {
    const { connectionId } = req.params;
    const {
      accountBalance,
      accountEquity,
      accountMargin,
      accountFreeMargin,
      accountProfit,
      dailyProfit,
    } = req.body;

    const connection = demoMt5Connections.get(connectionId);
    if (!connection) {
      return res.status(404).json({
        success: false,
        error: "Connection not found",
      });
    }

    // Update account data
    connection.accountBalance = accountBalance || connection.accountBalance;
    connection.accountEquity = accountEquity || connection.accountEquity;
    connection.accountMargin = accountMargin || connection.accountMargin;
    connection.accountFreeMargin =
      accountFreeMargin || connection.accountFreeMargin;
    connection.accountProfit = accountProfit || connection.accountProfit;
    connection.dailyProfit = dailyProfit || 0;
    connection.lastConnectedAt = new Date();

    return res.json({
      success: true,
      message: "Account data synced",
      connection,
    });
  } catch (error) {
    console.error("Error syncing account data:", error);
    return res.status(500).json({
      success: false,
      error: "Failed to sync account data",
    });
  }
});

/**
 * POST /api/mt5/sync-trades/:connectionId
 * Local connector sends open trades data
 */
router.post("/sync-trades/:connectionId", async (req: Request, res: Response) => {
  try {
    const { connectionId } = req.params;
    const { trades } = req.body;

    if (!Array.isArray(trades)) {
      return res.status(400).json({
        success: false,
        error: "Trades must be an array",
      });
    }

    // Store trades with connection reference (for backward compatibility)
    const tradeKey = `trades_${connectionId}`;
    demoSyncedTrades.set(tradeKey, {
      connectionId,
      trades,
      syncedAt: new Date(),
    });

    // Also save each trade to the database for permanent persistence
    try {
      for (const trade of trades) {
        // Insert new trade - let database handle duplicate checks if needed
        await db.insert(tradeJournal).values({
          asset: trade.asset || "UNKNOWN",
          direction: trade.direction || "LONG",
          htfBias: trade.htfBias || "NEUTRAL",
          entryType: trade.entryType || "RETEST",
          entryPrice: trade.entryPrice || 0,
          stopLoss: trade.stopLoss || 0,
          takeProfit: trade.takeProfit || 0,
          hasValidZone: trade.hasValidZone || false,
          hasLiquiditySweep: trade.hasLiquiditySweep || false,
          hasObFvgRetest: trade.hasObFvgRetest || false,
          chartImageUrl: trade.chartImageUrl,
          status: trade.status || "ACTIVE",
          outcome: trade.outcome,
          closePrice: trade.closePrice,
          isRuleCompliant: trade.isRuleCompliant || false,
          violationReasons: trade.violationReasons,
          notes: trade.notes || `MT5 Synced Trade - Connection: ${connectionId}`,
        }).catch((err) => {
          // Silently handle duplicate or constraint errors
          if (err.code !== "23505" && err.code !== "42P01") {
            console.error("[MT5-Connection] Error inserting trade:", err);
          }
        });
      }
      console.log(`[MT5-Connection] Saved ${trades.length} trades to database`);
    } catch (dbError) {
      console.error("[MT5-Connection] Error saving trades to database:", dbError);
      // Don't fail the request if database save fails - in-memory storage is still available
    }

    return res.json({
      success: true,
      message: `${trades.length} trades synced`,
      tradeCount: trades.length,
    });
  } catch (error) {
    console.error("Error syncing trades:", error);
    return res.status(500).json({
      success: false,
      error: "Failed to sync trades",
    });
  }
});

/**
 * GET /api/mt5/trades/:connectionId
 * Get synced trades for a connection
 * Returns trades from memory first, then from database for historical data
 */
router.get("/trades/:connectionId", async (req: Request, res: Response) => {
  try {
    const { connectionId } = req.params;

    const tradeKey = `trades_${connectionId}`;
    const tradeData = demoSyncedTrades.get(tradeKey);

    // If trades are in memory, return them
    if (tradeData && tradeData.trades && tradeData.trades.length > 0) {
      return res.json({
        success: true,
        trades: tradeData.trades,
        tradeCount: tradeData.trades.length,
        lastSyncedAt: tradeData.syncedAt,
        source: "memory",
      });
    }

    // Otherwise, try to fetch from database
    try {
      const dbTrades = await db.select().from(tradeJournal);
      
      if (dbTrades && dbTrades.length > 0) {
        console.log(`[MT5-Connection] Found ${dbTrades.length} trades in database for connection ${connectionId}`);
        return res.json({
          success: true,
          trades: dbTrades,
          tradeCount: dbTrades.length,
          lastSyncedAt: new Date(),
          source: "database",
        });
      }
    } catch (dbError) {
      console.error("[MT5-Connection] Error fetching from database:", dbError);
      // Return empty array instead of throwing
    }

    // No trades found
    return res.json({
      success: true,
      trades: [],
      tradeCount: 0,
      lastSyncedAt: null,
      source: "none",
    });
  } catch (error) {
    console.error("Error fetching trades:", error);
    return res.status(500).json({
      success: false,
      error: "Failed to fetch trades",
    });
  }
});

/**
 * PUT /api/mt5/disconnect/:connectionId
 * User disconnects their MT5 connection
 */
router.put("/disconnect/:connectionId", (req: Request, res: Response) => {
  try {
    const { connectionId } = req.params;
    const { reason } = req.body;

    const connection = demoMt5Connections.get(connectionId);
    if (!connection) {
      return res.status(404).json({
        success: false,
        error: "Connection not found",
      });
    }

    connection.isConnected = false;
    connection.connectionStatus = "DISCONNECTED";
    connection.disconnectReason = reason || "User disconnected";
    connection.updatedAt = new Date();

    return res.json({
      success: true,
      message: "Connection disconnected",
      connection,
    });
  } catch (error) {
    console.error("Error disconnecting:", error);
    return res.status(500).json({
      success: false,
      error: "Failed to disconnect",
    });
  }
});

/**
 * DELETE /api/mt5/connection/:connectionId
 * User removes/deletes their MT5 connection
 */
router.delete("/connection/:connectionId", (req: Request, res: Response) => {
  try {
    const { connectionId } = req.params;

    if (!demoMt5Connections.has(connectionId)) {
      return res.status(404).json({
        success: false,
        error: "Connection not found",
      });
    }

    demoMt5Connections.delete(connectionId);
    demoSyncedTrades.delete(`trades_${connectionId}`);

    return res.json({
      success: true,
      message: "Connection deleted successfully",
    });
  } catch (error) {
    console.error("Error deleting connection:", error);
    return res.status(500).json({
      success: false,
      error: "Failed to delete connection",
    });
  }
});

/**
 * GET /api/mt5/health/:connectionId
 * Health check - connector calls this to keep connection alive
 */
router.get("/health/:connectionId", (req: Request, res: Response) => {
  try {
    const { connectionId } = req.params;

    const connection = demoMt5Connections.get(connectionId);
    if (!connection) {
      return res.status(404).json({
        success: false,
        error: "Connection not found",
      });
    }

    // Update last seen
    connection.lastConnectedAt = new Date();

    return res.json({
      success: true,
      status: "healthy",
      connectionId,
      isConnected: connection.isConnected,
    });
  } catch (error) {
    console.error("Error in health check:", error);
    return res.status(500).json({
      success: false,
      error: "Health check failed",
    });
  }
});

export default router;
