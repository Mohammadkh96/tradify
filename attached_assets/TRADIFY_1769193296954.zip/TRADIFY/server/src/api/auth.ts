/**
 * Authentication API Routes
 * Handles user signup, login, and session management
 * Uses file-based persistent storage (no database required)
 */

import { Router, Request, Response } from "express";
import { ValidationError } from "./errors.js";
import { Logger } from "./logger.js";
import { 
  findUserByUsername, 
  findUserByEmail, 
  createUser,
  type StoredUser 
} from "../storage/file-storage.js";
import bcrypt from "bcryptjs";

const router = Router();

// Simple base64 hash kept for backward compatibility with existing demo users
function simpleHash(password: string): string {
  return Buffer.from(password).toString("base64");
}

async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10);
}

async function verifyPassword(password: string, hash: string): Promise<boolean> {
  // Prefer bcrypt; fall back to legacy base64 hashes for existing demo users
  if (hash.startsWith("$2a$") || hash.startsWith("$2b$") || hash.startsWith("$2y$")) {
    return bcrypt.compare(password, hash);
  }
  return simpleHash(password) === hash;
}

/**
 * Sign up new user
 * POST /api/auth/signup
 */
router.post("/signup", async (req: Request, res: Response): Promise<void> => {
  try {
    const { username, email, password, tradingCapital } = req.body;

    // Validation
    if (!username || !email || !password || !tradingCapital) {
      res.status(400).json({
        success: false,
        error: "All fields are required",
      });
      return;
    }

    if (password.length < 6) {
      res.status(400).json({
        success: false,
        error: "Password must be at least 6 characters",
      });
      return;
    }

    const capital = parseFloat(tradingCapital);
    if (isNaN(capital) || capital <= 0) {
      res.status(400).json({
        success: false,
        error: "Invalid trading capital amount",
      });
      return;
    }

    // Check if user already exists
    const existingByUsername = await findUserByUsername(username);
    if (existingByUsername) {
      res.status(400).json({
        success: false,
        error: "Username already exists",
      });
      return;
    }

    const existingByEmail = await findUserByEmail(email);
    if (existingByEmail) {
      res.status(400).json({
        success: false,
        error: "Email already exists",
      });
      return;
    }

    // Create new user
    const passwordHash = await hashPassword(password);
    const newUser = await createUser({
      username,
      email,
      passwordHash,
      tradingCapital: capital.toString(),
      riskPerTrade: "2.0",
    });

    Logger.info("User registered", { username });

    res.json({
      success: true,
      user: {
        id: newUser.id,
        username: newUser.username,
        email: newUser.email,
        tradingCapital: newUser.tradingCapital,
        riskPerTrade: newUser.riskPerTrade,
      },
    });
  } catch (error) {
    Logger.error("Signup error", { error });
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : "Signup failed",
    });
  }
});

/**
 * Login user
 * POST /api/auth/login
 */
router.post("/login", async (req: Request, res: Response): Promise<void> => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      res.status(400).json({
        success: false,
        error: "Username and password are required",
      });
      return;
    }

    // Find user in file storage
    const user = await findUserByUsername(username);

    if (!user) {
      res.status(404).json({
        success: false,
        error: "User not found",
      });
      return;
    }

    const passwordValid = await verifyPassword(password, user.passwordHash);

    if (!passwordValid) {
      res.status(401).json({
        success: false,
        error: "Invalid password",
      });
      return;
    }

    Logger.info("User logged in", { username });

    res.json({
      success: true,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        tradingCapital: user.tradingCapital,
        riskPerTrade: user.riskPerTrade,
      },
    });
  } catch (error) {
    Logger.error("Login error", { error });
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : "Login failed",
    });
  }
});

/**
 * Get current user profile
 * GET /api/auth/profile/:username
 */
router.get("/profile/:username", async (req: Request, res: Response): Promise<void> => {
  try {
    const { username } = req.params;

    const user = await findUserByUsername(username);

    if (!user) {
      res.status(404).json({
        success: false,
        error: "User not found",
      });
      return;
    }

    res.json({
      success: true,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        tradingCapital: user.tradingCapital,
        riskPerTrade: user.riskPerTrade,
      },
    });
  } catch (error) {
    Logger.error("Profile fetch error", { error });
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : "Failed to fetch profile",
    });
  }
});

export default router;
