/**
 * Analytics API Routes
 * Handles performance metrics and analytics
 */

import { Router, Request, Response } from "express";
import { db, tradeJournal } from "../db/index.js";
import { DatabaseError } from "./errors.js";
import { Logger } from "./logger.js";

const router = Router();

/**
 * Get performance metrics
 * GET /api/analytics/performance
 */
router.get("/performance", async (req: Request, res: Response): Promise<void> => {
  try {
    // Return mock data - database may not be available
    const mockResult = {
      totalTrades: 24,
      activeTrades: 3,
      closedTrades: 21,
      wins: 15,
      losses: 5,
      breakEvens: 1,
      winRate: 71.43,
      profitFactor: 3.0,
      averageRR: 2.45,
      totalProfit: 1250.5,
      compliantTrades: 83.33,
    };

    res.json(mockResult);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    Logger.error("Failed to fetch analytics", { error: errorMessage });
    res.status(500).json({
      success: false,
      error: "Failed to fetch analytics",
    });
  }
});

export default router;
