/**
 * AI Assistant Routes
 * Handles chat messages and AI interactions
 */

import { Router, Request, Response } from "express";
import { getAssistant } from "../ai/assistant.js";

const router = Router();

interface ChatRequest {
  message: string;
  userId?: string;
}

/**
 * POST /api/ai/chat
 * Send a message to the AI assistant
 */
router.post("/chat", async (req: Request, res: Response) => {
  try {
    const { message, userId } = req.body as ChatRequest;

    if (!message || message.trim().length === 0) {
      return res.status(400).json({ error: "Message cannot be empty" });
    }

    const assistant = getAssistant();
    const response = await assistant.chat(message);

    res.json({
      success: true,
      data: response,
    });
  } catch (error) {
    console.error("[AI Chat Error]", error);
    res.status(500).json({
      error: "Failed to process message",
      details: error instanceof Error ? error.message : "Unknown error",
    });
  }
});

/**
 * GET /api/ai/knowledge
 * Get available knowledge base items
 */
router.get("/knowledge", (_req: Request, res: Response) => {
  try {
    // Import here to avoid circular dependency
    const { knowledgeBase } = require("../ai/knowledgeBase.js");
    const items = knowledgeBase.getAllItems();

    res.json({
      success: true,
      count: items.length,
      data: items.map((item: any) => ({
        id: item.id,
        category: item.category,
        title: item.title,
        source: item.source,
      })),
    });
  } catch (error) {
    res.status(500).json({ error: "Failed to retrieve knowledge base" });
  }
});

/**
 * GET /api/ai/logs
 * Get assistant interaction logs (admin only)
 */
router.get("/logs", (_req: Request, res: Response) => {
  try {
    const assistant = getAssistant();
    const logs = assistant.getLogs();

    res.json({
      success: true,
      count: logs.length,
      data: logs.slice(-50), // Last 50 interactions
    });
  } catch (error) {
    res.status(500).json({ error: "Failed to retrieve logs" });
  }
});

/**
 * POST /api/ai/reset
 * Reset conversation history (start fresh session)
 */
router.post("/reset", (_req: Request, res: Response) => {
  try {
    const assistant = getAssistant();
    assistant.clearHistory();

    res.json({
      success: true,
      message: "Conversation history cleared",
    });
  } catch (error) {
    res.status(500).json({ error: "Failed to reset conversation" });
  }
});

export default router;
