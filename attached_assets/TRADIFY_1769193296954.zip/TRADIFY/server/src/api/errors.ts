/**
 * Centralized Error Handling
 * All API errors are structured and typed
 */

export class AppError extends Error {
  constructor(
    public statusCode: number,
    public message: string,
    public code?: string,
    public details?: unknown
  ) {
    super(message);
    this.name = "AppError";
    Object.setPrototypeOf(this, AppError.prototype);
  }
}

export class ValidationError extends AppError {
  constructor(message: string, details?: unknown) {
    super(400, message, "VALIDATION_ERROR", details);
    this.name = "ValidationError";
    Object.setPrototypeOf(this, ValidationError.prototype);
  }
}

export class RuleViolationError extends AppError {
  constructor(
    message: string,
    public violations: Array<{ rule_id: string; rule_name: string; reason: string }>
  ) {
    super(400, message, "RULE_VIOLATION", violations);
    this.name = "RuleViolationError";
    Object.setPrototypeOf(this, RuleViolationError.prototype);
  }
}

export class DatabaseError extends AppError {
  constructor(message: string, details?: unknown) {
    super(500, message, "DATABASE_ERROR", details);
    this.name = "DatabaseError";
    Object.setPrototypeOf(this, DatabaseError.prototype);
  }
}

export class NotFoundError extends AppError {
  constructor(resource: string) {
    super(404, `${resource} not found`, "NOT_FOUND");
    this.name = "NotFoundError";
    Object.setPrototypeOf(this, NotFoundError.prototype);
  }
}

/**
 * Error handler middleware
 */
import { Request, Response, NextFunction } from "express";

export function errorHandler(error: unknown, req: Request, res: Response, next: NextFunction): void {
  if (error instanceof AppError) {
    res.status(error.statusCode).json({
      success: false,
      error: {
        code: error.code,
        message: error.message,
        details: error.details,
      },
    });
    return;
  }

  // Unknown error
  const errorMessage = error instanceof Error ? error.message : "Internal server error";
  console.error("Unhandled error:", error);
  res.status(500).json({
    success: false,
    error: {
      code: "INTERNAL_ERROR",
      message: errorMessage,
    },
  });
}
