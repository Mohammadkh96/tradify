/**
 * Trades API Routes
 * Handles trade creation, validation, and retrieval
 */

import { Router, Request, Response } from "express";
import { eq, desc } from "drizzle-orm";
import { TradeEntrySchema, calculateRiskRewardRatio } from "../../../shared/dist/index.js";
import { evaluateRules, validateMarketFacts, MarketFacts } from "../engine/index.js";
import { db, tradeJournal } from "../db/index.js";
import { ValidationError, RuleViolationError, DatabaseError, NotFoundError } from "./errors.js";
import { Logger } from "./logger.js";

const router = Router();
const DEMO_MODE = process.env.DEMO_MODE === "true" || process.env.DB_DISABLED === "true";

/**
 * Validate trade against rules (real-time)
 * POST /api/trades/validate
 */
router.post("/validate", async (req: Request, res: Response): Promise<void> => {
  try {
    const tradeData = req.body;

    // Validate schema
    const parsed = TradeEntrySchema.parse(tradeData);

    // Convert to MarketFacts format
    const marketFacts: MarketFacts = {
      asset: parsed.asset,
      direction: parsed.direction,
      htfBias: parsed.htfBias,
      entryType: parsed.entryType,
      entryPrice: Number(parsed.entryPrice),
      stopLoss: Number(parsed.stopLoss),
      takeProfit: Number(parsed.takeProfit),
      hasValidZone: parsed.hasValidZone,
      hasLiquiditySweep: parsed.hasLiquiditySweep,
      hasObFvgRetest: parsed.hasObFvgRetest,
    };

    // Validate market facts structure
    if (!validateMarketFacts(marketFacts)) {
      throw new ValidationError("Invalid market facts structure");
    }

    // Run rule evaluation
    const evaluation = evaluateRules(marketFacts);

    // Log for audit trail
    Logger.logRuleEvaluation(marketFacts, evaluation);

    // Calculate R:R
    const rrRatio = calculateRiskRewardRatio(
      marketFacts.entryPrice,
      marketFacts.stopLoss,
      marketFacts.takeProfit
    );

    res.json({
      isValid: evaluation.isValid,
      violations: evaluation.violations,
      rrRatio,
      parsedTrade: parsed,
    });
  } catch (error) {
    if (error instanceof ValidationError || error instanceof RuleViolationError) {
      throw error;
    }
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    throw new ValidationError(`Validation failed: ${errorMessage}`);
  }
});

/**
 * Get all trades
 * GET /api/trades
 */
router.get("/", async (req: Request, res: Response): Promise<void> => {
  try {
    const trades = await db.select().from(tradeJournal).orderBy(desc(tradeJournal.createdAt));
    res.json(trades);
  } catch (error) {
    // In demo mode without database, return empty array
    Logger.warn("Database unavailable, returning empty trades list");
    res.json([]);
  }
});

/**
 * Get trade by ID
 * GET /api/trades/:id
 */
router.get("/:id", async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const tradeId = parseInt(id, 10);

    if (isNaN(tradeId)) {
      throw new ValidationError("Invalid trade ID");
    }

    const trades = await db
      .select()
      .from(tradeJournal)
      .where(eq(tradeJournal.id, tradeId))
      .limit(1);

    if (trades.length === 0) {
      throw new NotFoundError("Trade");
    }

    res.json(trades[0]);
  } catch (error) {
    if (error instanceof ValidationError || error instanceof NotFoundError) {
      throw error;
    }
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    throw new DatabaseError(`Failed to fetch trade: ${errorMessage}`);
  }
});

/**
 * Create new trade
 * POST /api/trades
 */
router.post("/", async (req: Request, res: Response): Promise<void> => {
  try {
    const tradeData = req.body;

    // Validate schema
    const parsed = TradeEntrySchema.parse(tradeData);

    // Convert to MarketFacts and evaluate rules
    const marketFacts: MarketFacts = {
      asset: parsed.asset,
      direction: parsed.direction,
      htfBias: parsed.htfBias,
      entryType: parsed.entryType,
      entryPrice: Number(parsed.entryPrice),
      stopLoss: Number(parsed.stopLoss),
      takeProfit: Number(parsed.takeProfit),
      hasValidZone: parsed.hasValidZone,
      hasLiquiditySweep: parsed.hasLiquiditySweep,
      hasObFvgRetest: parsed.hasObFvgRetest,
    };

    const evaluation = evaluateRules(marketFacts);

    // Log for audit trail
    Logger.logRuleEvaluation(marketFacts, evaluation);

    // If rules are violated, reject the trade
    if (!evaluation.isValid) {
      throw new RuleViolationError(
        "Trade violates one or more rules",
        evaluation.violations
      );
    }

    if (DEMO_MODE) {
      // Demo mode: return a non-persisted trade so the UI can proceed
      res.status(201).json({
        success: true,
        demo: true,
        trade: {
          id: Date.now(),
          ...parsed,
          isRuleCompliant: evaluation.isValid,
          violationReasons: evaluation.violations,
        },
        compliance: evaluation,
      });
      return;
    }

    // Insert into DB
    const result = await db
      .insert(tradeJournal)
      .values({
        asset: parsed.asset,
        direction: parsed.direction,
        htfBias: parsed.htfBias,
        entryType: parsed.entryType,
        entryPrice: parsed.entryPrice.toString(),
        stopLoss: parsed.stopLoss.toString(),
        takeProfit: parsed.takeProfit.toString(),
        hasValidZone: parsed.hasValidZone,
        hasLiquiditySweep: parsed.hasLiquiditySweep,
        hasObFvgRetest: parsed.hasObFvgRetest,
        chartImageUrl: parsed.chartImageUrl,
        isRuleCompliant: evaluation.isValid,
        violationReasons: evaluation.violations.length > 0 ? JSON.stringify(evaluation.violations) : null,
        notes: parsed.notes,
        status: parsed.status,
      })
      .returning();

    res.status(201).json({
      success: true,
      trade: result[0],
      compliance: evaluation,
    });
  } catch (error) {
    if (error instanceof ValidationError || error instanceof RuleViolationError) {
      throw error;
    }
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    throw new DatabaseError(`Failed to create trade: ${errorMessage}`);
  }
});

/**
 * Update trade
 * PUT /api/trades/:id
 */
router.put("/:id", async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const tradeId = parseInt(id, 10);

    if (isNaN(tradeId)) {
      throw new ValidationError("Invalid trade ID");
    }

    const tradeData = req.body as Partial<typeof tradeJournal.$inferInsert>;
    const { id: _, ...updateData } = tradeData;
    const dbUpdateData: Record<string, unknown> = {};
    
    for (const [key, value] of Object.entries(updateData)) {
      if (['entryPrice', 'stopLoss', 'takeProfit', 'closePrice'].includes(key) && value !== undefined) {
        dbUpdateData[key] = value.toString();
      } else {
        dbUpdateData[key] = value;
      }
    }

    if (DEMO_MODE) {
      res.json({
        success: true,
        demo: true,
        trade: { id: tradeId, ...updateData },
      });
      return;
    }

    const result = await db
      .update(tradeJournal)
      .set(dbUpdateData as typeof tradeJournal.$inferInsert)
      .where(eq(tradeJournal.id, tradeId))
      .returning();

    if (result.length === 0) {
      throw new NotFoundError("Trade");
    }

    res.json({
      success: true,
      trade: result[0],
    });
  } catch (error) {
    if (error instanceof ValidationError || error instanceof NotFoundError) {
      throw error;
    }
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    throw new DatabaseError(`Failed to update trade: ${errorMessage}`);
  }
});

/**
 * Close trade (set outcome)
 * POST /api/trades/:id/close
 */
router.post("/:id/close", async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const tradeId = parseInt(id, 10);

    if (isNaN(tradeId)) {
      throw new ValidationError("Invalid trade ID");
    }

    const { outcome, closePrice } = req.body;

    if (DEMO_MODE) {
      res.json({
        success: true,
        demo: true,
        trade: {
          id: tradeId,
          status: "CLOSED",
          outcome,
          closePrice,
          exitTime: new Date(),
        },
      });
      return;
    }

    const result = await db
      .update(tradeJournal)
      .set({
        status: "CLOSED",
        outcome,
        closePrice: closePrice?.toString(),
        exitTime: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(tradeJournal.id, tradeId))
      .returning();

    if (result.length === 0) {
      throw new NotFoundError("Trade");
    }

    res.json({
      success: true,
      trade: result[0],
    });
  } catch (error) {
    if (error instanceof ValidationError || error instanceof NotFoundError) {
      throw error;
    }
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    throw new DatabaseError(`Failed to close trade: ${errorMessage}`);
  }
});

export default router;
