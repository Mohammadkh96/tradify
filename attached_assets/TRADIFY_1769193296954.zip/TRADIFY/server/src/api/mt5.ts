/**
 * MT5 Integration API Routes
 * Read-only/journal mode - NEVER auto-executes trades
 */

import { Router, Request, Response } from "express";
import fs from "fs";
import path from "path";
import os from "os";
import { DatabaseError } from "./errors.js";
import { Logger } from "./logger.js";

const router = Router();

interface MT5Data {
  connected: boolean;
  timestamp: number;
  timestamp_iso: string;
  export_count: number;
  account: {
    number: number;
    name: string;
    server: string;
    currency: string;
    balance: number;
    equity: number;
    profit: number;
    margin: number;
    margin_free: number;
    margin_level: number;
    leverage: number;
  };
  positions: Array<{
    ticket: number;
    symbol: string;
    type: string;
    volume: number;
    price_open: number;
    price_current: number;
    sl: number;
    tp: number;
    profit: number;
    swap: number;
    time: number;
  }>;
  positions_total: number;
}

let cachedMT5Data: MT5Data | null = null;
let lastFileReadTime = 0;
const FILE_CACHE_MS = 2000; // Read file every 2 seconds max

/**
 * Determine MT5 file path based on OS
 */
function getMT5FilePath(): string {
  const fileName = "tradify_mt5_data.json";
  
  if (os.platform() === "win32") {
    const appData = process.env.APPDATA || "";
    return path.join(appData, "MetaQuotes", "Terminal", "Common", "Files", fileName);
  } else if (os.platform() === "darwin") {
    return path.join(os.homedir(), "Library", "Application Support", "MetaQuotes", "Terminal", "Common", "Files", fileName);
  } else {
    const winePrefix = process.env.WINEPREFIX || path.join(os.homedir(), ".wine");
    return path.join(winePrefix, "drive_c", "users", os.userInfo().username, "Application Data", "MetaQuotes", "Terminal", "Common", "Files", fileName);
  }
}

const MT5_FILE_PATH = process.env.MT5_FILE_PATH || getMT5FilePath();

/**
 * Read MT5 data from file (read-only)
 */
function readMT5File(): MT5Data | null {
  const now = Date.now();
  
  // Return cached data if recent
  if (cachedMT5Data && (now - lastFileReadTime) < FILE_CACHE_MS) {
    return cachedMT5Data;
  }
  
  try {
    if (!fs.existsSync(MT5_FILE_PATH)) {
      return null;
    }
    
    const fileContent = fs.readFileSync(MT5_FILE_PATH, "utf8");
    const data = JSON.parse(fileContent) as MT5Data;
    
    // Check if data is stale (more than 10 seconds old)
    const dataAge = Date.now() / 1000 - data.timestamp;
    if (dataAge > 10) {
      Logger.warn(`MT5 data is ${dataAge.toFixed(1)}s old - EA may not be running`);
      return null;
    }
    
    cachedMT5Data = data;
    lastFileReadTime = now;
    return data;
    
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    Logger.error("Error reading MT5 file", { error: errorMessage });
    return null;
  }
}

/**
 * Get MT5 connection status
 * GET /api/mt5/status
 */
router.get("/status", (req: Request, res: Response): void => {
  const mt5Data = readMT5File();
  
  if (mt5Data) {
    res.json({ 
      connected: true,
      mode: "read-only", // Journal mode - no auto-trading
      account: mt5Data.account.number.toString(),
      server: mt5Data.account.server,
      accountType: mt5Data.account.server.toLowerCase().includes("demo") ? "demo" : "live",
      lastSync: new Date(mt5Data.timestamp * 1000).toISOString(),
      timestamp: mt5Data.timestamp,
      export_count: mt5Data.export_count,
      file_path: MT5_FILE_PATH
    });
  } else {
    res.json({ 
      connected: false,
      mode: "read-only",
      account: null,
      server: null,
      accountType: null,
      lastSync: null,
      message: "MT5 EA not detected. Ensure TradifyBridge.ex5 is running in MT5.",
      file_path: MT5_FILE_PATH,
      file_exists: fs.existsSync(MT5_FILE_PATH)
    });
  }
});

/**
 * Get MT5 account data
 * GET /api/mt5/account
 */
router.get("/account", (req: Request, res: Response): void => {
  try {
    const mt5Data = readMT5File();
    
    if (!mt5Data) {
      res.status(400).json({ error: "Not connected to MT5" });
      return;
    }

    const accountData = {
      balance: mt5Data.account.balance,
      equity: mt5Data.account.equity,
      freeMargin: mt5Data.account.margin_free,
      marginLevel: mt5Data.account.margin_level,
      unrealizedPL: mt5Data.account.profit,
      dailyPL: mt5Data.account.profit,
      currency: mt5Data.account.currency,
      leverage: mt5Data.account.leverage,
      margin: mt5Data.account.margin,
    };

    res.json({ success: true, account: accountData });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    Logger.error("Failed to fetch account data", { error: errorMessage });
    throw new DatabaseError(`Failed to fetch account data: ${errorMessage}`);
  }
});

/**
 * Get MT5 open trades (read-only)
 * GET /api/mt5/open-trades
 */
router.get("/open-trades", (req: Request, res: Response): void => {
  try {
    const mt5Data = readMT5File();
    
    if (!mt5Data) {
      res.json({ success: true, trades: [] });
      return;
    }

    // Transform MT5 positions to expected format
    const trades = mt5Data.positions.map(pos => ({
      symbol: pos.symbol,
      type: pos.type,
      volume: pos.volume,
      entryPrice: pos.price_open,
      currentPrice: pos.price_current,
      stopLoss: pos.sl || null,
      takeProfit: pos.tp || null,
      profit: pos.profit,
      swap: pos.swap,
      openTime: new Date(pos.time * 1000).toISOString(),
      ticket: pos.ticket,
    }));

    res.json({ success: true, trades });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    Logger.error("Failed to fetch open trades", { error: errorMessage });
    throw new DatabaseError(`Failed to fetch open trades: ${errorMessage}`);
  }
});

/**
 * Get MT5 risk exposure
 * GET /api/mt5/risk-exposure
 */
router.get("/risk-exposure", (req: Request, res: Response): void => {
  try {
    const mt5Data = readMT5File();
    
    if (!mt5Data) {
      res.json({ 
        success: true, 
        totalExposure: 0,
        exposurePercent: 0,
        positions: 0
      });
      return;
    }

    const totalExposure = Math.abs(mt5Data.account.margin);
    const exposurePercent = mt5Data.account.equity > 0 
      ? (totalExposure / mt5Data.account.equity) * 100 
      : 0;

    res.json({ 
      success: true,
      totalExposure,
      exposurePercent: Number(exposurePercent.toFixed(2)),
      positions: mt5Data.positions_total,
      marginLevel: mt5Data.account.margin_level
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    Logger.error("Failed to fetch risk exposure", { error: errorMessage });
    res.json({ 
      success: true, 
      totalExposure: 0,
      exposurePercent: 0,
      positions: 0
    });
  }
});

export default router;
