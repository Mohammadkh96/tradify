/**
 * Risk Calculator API Routes
 */

import { Router, Request, Response } from "express";
import { calculatePositionSize } from "../../../shared/dist/index.js";
import { ValidationError } from "./errors.js";

const router = Router();

/**
 * Calculate position size
 * POST /api/risk/calculate
 */
router.post("/calculate", (req: Request, res: Response): void => {
  try {
    const { capital, riskPercent, stopLossPips } = req.body;

    if (typeof capital !== "number" || capital <= 0) {
      throw new ValidationError("Capital must be a positive number");
    }

    if (typeof riskPercent !== "number" || riskPercent <= 0 || riskPercent > 100) {
      throw new ValidationError("Risk percent must be between 0 and 100");
    }

    if (typeof stopLossPips !== "number" || stopLossPips <= 0) {
      throw new ValidationError("Stop loss pips must be a positive number");
    }

    const positionSize = calculatePositionSize(capital, riskPercent, stopLossPips);

    res.json({
      capital,
      riskPercent,
      riskAmount: (capital * (riskPercent / 100)).toFixed(2),
      stopLossPips,
      positionSize,
    });
  } catch (error) {
    if (error instanceof ValidationError) {
      throw error;
    }
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    throw new ValidationError(`Invalid calculation parameters: ${errorMessage}`);
  }
});

export default router;
