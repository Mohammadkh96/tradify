/**
 * Simple file-based storage for user authentication
 * Persists data across server restarts without requiring database setup
 */

import fs from "fs/promises";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const USERS_FILE = path.join(__dirname, "users.json");

export interface StoredUser {
  id: number;
  username: string;
  email: string;
  passwordHash: string;
  tradingCapital: string;
  riskPerTrade: string;
  createdAt: string;
}

interface StorageData {
  users: StoredUser[];
}

let cache: StorageData | null = null;

/**
 * Load users from file
 */
async function loadData(): Promise<StorageData> {
  if (cache) return cache;

  try {
    const data = await fs.readFile(USERS_FILE, "utf-8");
    cache = JSON.parse(data);
    return cache!;
  } catch (error) {
    // File doesn't exist or is corrupted, start fresh
    cache = { users: [] };
    await saveData(cache);
    return cache;
  }
}

/**
 * Save users to file
 */
async function saveData(data: StorageData): Promise<void> {
  cache = data;
  await fs.writeFile(USERS_FILE, JSON.stringify(data, null, 2), "utf-8");
}

/**
 * Get all users
 */
export async function getAllUsers(): Promise<StoredUser[]> {
  const data = await loadData();
  return data.users;
}

/**
 * Find user by username
 */
export async function findUserByUsername(username: string): Promise<StoredUser | null> {
  const data = await loadData();
  return data.users.find((u) => u.username === username) || null;
}

/**
 * Find user by email
 */
export async function findUserByEmail(email: string): Promise<StoredUser | null> {
  const data = await loadData();
  return data.users.find((u) => u.email === email) || null;
}

/**
 * Create new user
 */
export async function createUser(user: Omit<StoredUser, "id" | "createdAt">): Promise<StoredUser> {
  const data = await loadData();
  
  const newUser: StoredUser = {
    ...user,
    id: data.users.length > 0 ? Math.max(...data.users.map((u) => u.id)) + 1 : 1,
    createdAt: new Date().toISOString(),
  };

  data.users.push(newUser);
  await saveData(data);
  
  return newUser;
}

/**
 * Clear all users (for testing)
 */
export async function clearAllUsers(): Promise<void> {
  await saveData({ users: [] });
}
