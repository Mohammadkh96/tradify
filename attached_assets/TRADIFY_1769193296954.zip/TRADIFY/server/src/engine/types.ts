/**
 * Type definitions for the rule engine
 * All types are strictly typed - no `any` allowed
 */

export enum RuleType {
  FORBIDDEN = "forbidden",
  REQUIRED = "required",
  CONDITIONAL = "conditional",
}

export enum Operator {
  EQUALS = "equals",
  NOT_EQUALS = "not_equals",
  GREATER_THAN = "greater_than",
  LESS_THAN = "less_than",
  IN = "in",
  NOT_IN = "not_in",
}

export interface RuleCondition {
  field: string;
  operator: Operator;
  value: string | number | boolean;
  then?: RuleCondition;
}

export interface ComplexCondition {
  operator: "AND" | "OR";
  checks: Array<RuleCondition | ComplexCondition>;
}

export interface Rule {
  id: string;
  name: string;
  description: string;
  type: RuleType;
  condition: RuleCondition | ComplexCondition;
  violation_message: string;
}

export interface RulesConfig {
  version: string;
  rules: Rule[];
}

export interface RuleViolation {
  rule_id: string;
  rule_name: string;
  reason: string;
}

export interface RuleEvaluationResult {
  isValid: boolean;
  violations: RuleViolation[];
}

export interface MarketFacts {
  asset: string;
  direction: "LONG" | "SHORT";
  htfBias: "BULLISH" | "BEARISH" | "NEUTRAL";
  entryType: "RETEST" | "REVERSAL" | "BREAKOUT";
  entryPrice: number;
  stopLoss: number;
  takeProfit: number;
  hasValidZone: boolean;
  hasLiquiditySweep: boolean;
  hasObFvgRetest: boolean;
}
