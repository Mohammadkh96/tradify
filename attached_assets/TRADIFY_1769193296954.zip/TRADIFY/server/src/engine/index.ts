/**
 * Rule Engine Module
 * Exports the main evaluation function and types
 */

export {
  evaluateRules,
  loadRules,
  validateMarketFacts,
} from "./rule-engine.js";

export type {
  Rule,
  RuleType,
  Operator,
  RuleCondition,
  ComplexCondition,
  RuleViolation,
  RuleEvaluationResult,
  MarketFacts,
  RulesConfig,
} from "./types.js";
