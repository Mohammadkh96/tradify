/**
 * Unit Tests for Rule Engine
 * Tests deterministic rule evaluation
 */

import { describe, it, expect } from "vitest";
import { evaluateRules, validateMarketFacts, MarketFacts } from "./index.js";

describe("Rule Engine", () => {
  const validFacts: MarketFacts = {
    asset: "EURUSD",
    direction: "LONG",
    htfBias: "BULLISH",
    entryType: "RETEST",
    entryPrice: 1.0850,
    stopLoss: 1.0800,
    takeProfit: 1.0950,
    hasValidZone: true,
    hasLiquiditySweep: false,
    hasObFvgRetest: true,
  };

  it("should validate market facts structure", () => {
    expect(validateMarketFacts(validFacts)).toBe(true);
    expect(validateMarketFacts({})).toBe(false);
    expect(validateMarketFacts(null)).toBe(false);
  });

  it("should pass all rules for valid trade", () => {
    const result = evaluateRules(validFacts);
    expect(result.isValid).toBe(true);
    expect(result.violations).toHaveLength(0);
  });

  it("should fail GR-02 when LONG direction has non-BULLISH bias", () => {
    const facts: MarketFacts = {
      ...validFacts,
      direction: "LONG",
      htfBias: "BEARISH",
    };
    const result = evaluateRules(facts);
    expect(result.isValid).toBe(false);
    expect(result.violations.some(v => v.rule_id === "GR-02")).toBe(true);
  });

  it("should fail GR-02 when SHORT direction has non-BEARISH bias", () => {
    const facts: MarketFacts = {
      ...validFacts,
      direction: "SHORT",
      htfBias: "BULLISH",
    };
    const result = evaluateRules(facts);
    expect(result.isValid).toBe(false);
    expect(result.violations.some(v => v.rule_id === "GR-02")).toBe(true);
  });

  it("should fail GR-03 when hasValidZone is false", () => {
    const facts: MarketFacts = {
      ...validFacts,
      hasValidZone: false,
    };
    const result = evaluateRules(facts);
    expect(result.isValid).toBe(false);
    expect(result.violations.some(v => v.rule_id === "GR-03")).toBe(true);
  });

  it("should fail GR-05 when hasObFvgRetest is false", () => {
    const facts: MarketFacts = {
      ...validFacts,
      hasObFvgRetest: false,
    };
    const result = evaluateRules(facts);
    expect(result.isValid).toBe(false);
    expect(result.violations.some(v => v.rule_id === "GR-05")).toBe(true);
  });

  it("should fail GR-08 when REVERSAL entry has no liquidity sweep", () => {
    const facts: MarketFacts = {
      ...validFacts,
      entryType: "REVERSAL",
      hasLiquiditySweep: false,
    };
    const result = evaluateRules(facts);
    expect(result.isValid).toBe(false);
    expect(result.violations.some(v => v.rule_id === "GR-08")).toBe(true);
  });

  it("should pass GR-08 when REVERSAL entry has liquidity sweep", () => {
    const facts: MarketFacts = {
      ...validFacts,
      direction: "SHORT",
      htfBias: "BEARISH",
      entryType: "REVERSAL",
      hasLiquiditySweep: true,
    };
    const result = evaluateRules(facts);
    expect(result.isValid).toBe(true);
  });

  it("should return structured violations with rule_id, rule_name, and reason", () => {
    const facts: MarketFacts = {
      ...validFacts,
      hasValidZone: false,
      hasObFvgRetest: false,
    };
    const result = evaluateRules(facts);
    expect(result.isValid).toBe(false);
    expect(result.violations.length).toBeGreaterThan(0);
    
    result.violations.forEach(violation => {
      expect(violation).toHaveProperty("rule_id");
      expect(violation).toHaveProperty("rule_name");
      expect(violation).toHaveProperty("reason");
      expect(typeof violation.rule_id).toBe("string");
      expect(typeof violation.rule_name).toBe("string");
      expect(typeof violation.reason).toBe("string");
    });
  });

  it("should be deterministic - same input produces same output", () => {
    const result1 = evaluateRules(validFacts);
    const result2 = evaluateRules(validFacts);
    expect(result1).toEqual(result2);
  });
});
