/**
 * Deterministic Rule Engine
 * 
 * This engine evaluates market facts against hard rules.
 * - Pure functions only (no side effects)
 * - Deterministic: same input always produces same output
 * - Auditable: all violations are logged with rule_id, rule_name, reason
 */

import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import {
  Rule,
  RuleType,
  Operator,
  RuleCondition,
  ComplexCondition,
  RuleViolation,
  RuleEvaluationResult,
  MarketFacts,
  RulesConfig,
} from "./types.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * Load rules from JSON file
 * Rules are versioned and stored in market_knowledge/rules.json
 */
export function loadRules(): RulesConfig {
  const rulesPath = path.join(__dirname, "../market_knowledge/rules.json");
  
  try {
    const rulesContent = fs.readFileSync(rulesPath, "utf-8");
    const rulesConfig: RulesConfig = JSON.parse(rulesContent);
    return rulesConfig;
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    throw new Error(`Failed to load rules from ${rulesPath}: ${errorMessage}`);
  }
}

/**
 * Evaluate a single condition against market facts
 * Pure function - no side effects
 */
function evaluateCondition(
  condition: RuleCondition | ComplexCondition,
  facts: MarketFacts
): boolean {
  // Handle complex conditions (AND/OR)
  if ("operator" in condition && (condition.operator === "AND" || condition.operator === "OR")) {
    const results = condition.checks.map((check) => evaluateCondition(check, facts));
    
    if (condition.operator === "AND") {
      return results.every((result) => result === true);
    } else {
      // OR
      return results.some((result) => result === true);
    }
  }

  // Handle simple conditions
  const simpleCondition = condition as RuleCondition;
  const fieldValue = (facts as Record<string, unknown>)[simpleCondition.field];

  if (fieldValue === undefined) {
    return false;
  }

  switch (simpleCondition.operator) {
    case Operator.EQUALS:
      return fieldValue === simpleCondition.value;
    case Operator.NOT_EQUALS:
      return fieldValue !== simpleCondition.value;
    case Operator.GREATER_THAN:
      return typeof fieldValue === "number" && typeof simpleCondition.value === "number" && fieldValue > simpleCondition.value;
    case Operator.LESS_THAN:
      return typeof fieldValue === "number" && typeof simpleCondition.value === "number" && fieldValue < simpleCondition.value;
    case Operator.IN:
      return Array.isArray(simpleCondition.value) && simpleCondition.value.includes(fieldValue);
    case Operator.NOT_IN:
      return Array.isArray(simpleCondition.value) && !simpleCondition.value.includes(fieldValue);
    default:
      return false;
  }
}

/**
 * Evaluate a single rule against market facts
 * Returns true if rule passes, false if violated
 */
function evaluateRule(rule: Rule, facts: MarketFacts): boolean {
  const conditionResult = evaluateCondition(rule.condition, facts);

  switch (rule.type) {
    case RuleType.FORBIDDEN:
      // Forbidden conditions: if condition is true, rule is violated
      // conditionResult = true means the forbidden condition is met → violation
      return !conditionResult;
    case RuleType.REQUIRED:
      // Required conditions: if condition is true (meaning the required field is missing/false), rule is violated
      // conditionResult = true means the required field is missing → violation
      return !conditionResult;
    case RuleType.CONDITIONAL:
      // Conditional: if the condition is true, rule is violated
      // For GR-08: if entryType=REVERSAL AND hasLiquiditySweep=false, then violation
      return !conditionResult;
    default:
      return false;
  }
}

/**
 * Main rule evaluation function
 * 
 * Process:
 * 1. Load global hard rules
 * 2. Check forbidden conditions
 * 3. Check required conditions
 * 4. Match valid setups
 * 5. Return VALID or NO_TRADE + violations
 * 
 * This is a PURE function - no side effects, deterministic
 */
export function evaluateRules(facts: MarketFacts): RuleEvaluationResult {
  const rulesConfig = loadRules();
  const violations: RuleViolation[] = [];

  // Evaluate each rule
  for (const rule of rulesConfig.rules) {
    const rulePasses = evaluateRule(rule, facts);

    if (!rulePasses) {
      violations.push({
        rule_id: rule.id,
        rule_name: rule.name,
        reason: rule.violation_message,
      });
    }
  }

  return {
    isValid: violations.length === 0,
    violations,
  };
}

/**
 * Validate market facts structure
 * Ensures all required fields are present
 */
export function validateMarketFacts(facts: unknown): facts is MarketFacts {
  if (typeof facts !== "object" || facts === null) {
    return false;
  }

  const requiredFields: (keyof MarketFacts)[] = [
    "asset",
    "direction",
    "htfBias",
    "entryType",
    "entryPrice",
    "stopLoss",
    "takeProfit",
    "hasValidZone",
    "hasLiquiditySweep",
    "hasObFvgRetest",
  ];

  for (const field of requiredFields) {
    if (!(field in facts)) {
      return false;
    }
  }

  return true;
}
