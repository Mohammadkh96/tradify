/**
 * Knowledge Base System for Teachable AI Assistant
 * Stores and retrieves trading rules, platform guides, and FAQs
 */

export interface KnowledgeItem {
  id: string;
  category: "rule" | "guide" | "faq" | "strategy";
  title: string;
  content: string;
  keywords: string[];
  source?: string;
  updatedAt: Date;
}

export class KnowledgeBase {
  private items: Map<string, KnowledgeItem> = new Map();

  constructor() {
    this.initializeDefaultKnowledge();
  }

  private initializeDefaultKnowledge() {
    // Trading Rules
    this.addItem({
      id: "rule-stop-loss",
      category: "rule",
      title: "Always Set Stop Loss",
      content: `Every trade must have a defined stop-loss level before entry.
        - Never trade without a stop loss
        - Stop loss should be placed at a logical support/resistance level
        - Risk-reward ratio should be at least 1:2 minimum
        - For scalps: 5-10 pips, for swing trades: 20-50 pips typically`,
      keywords: ["stop loss", "risk management", "sl", "protection"],
      source: "Trading Rules - Risk Management",
      updatedAt: new Date(),
    });

    this.addItem({
      id: "rule-position-sizing",
      category: "rule",
      title: "Position Sizing Rules",
      content: `Position sizing must follow these rules:
        - Never risk more than 2% of total account on a single trade
        - Scale position size based on volatility
        - Reduce size during losing streaks (safety protocol)
        - Maximum 5% total exposure across all open trades`,
      keywords: ["position size", "lot size", "risk per trade", "exposure"],
      source: "Trading Rules - Position Sizing",
      updatedAt: new Date(),
    });

    this.addItem({
      id: "rule-daily-loss-limit",
      category: "rule",
      title: "Daily Loss Limit",
      content: `Daily loss limits are enforced:
        - Stop trading if daily loss reaches 5% of account
        - If 3 consecutive losses occur, reduce next 3 trades by 50%
        - Take a break and review trades before resuming
        - Document the reason for the losing streak`,
      keywords: ["daily loss", "loss limit", "stop trading", "drawdown"],
      source: "Trading Rules - Loss Management",
      updatedAt: new Date(),
    });

    this.addItem({
      id: "rule-news-trading",
      category: "rule",
      title: "News Event Trading",
      content: `Trading around news events requires special rules:
        - High-impact news (NFP, Fed decisions, ECB): trade ONLY if you have confirmed direction
        - Avoid 15 minutes before until 5 minutes after major news
        - Volume must be normal (not thin market conditions)
        - Pair volatility must be within normal range`,
      keywords: ["news", "events", "economic calendar", "volatility"],
      source: "Trading Rules - News Trading",
      updatedAt: new Date(),
    });

    // Platform Guides
    this.addItem({
      id: "guide-mt5-connection",
      category: "guide",
      title: "MT5 Connector Setup",
      content: `To connect your MT5 account:
        1. Download the TRADIFY connector from the platform
        2. Run the installer
        3. Enter your MT5 account number and password
        4. Click "Connect" and authorize the bridge
        5. Once connected, your trades will auto-sync to the journal`,
      keywords: ["mt5", "connection", "setup", "bridge", "connector"],
      source: "Platform Guide - MT5",
      updatedAt: new Date(),
    });

    this.addItem({
      id: "guide-journal-entries",
      category: "guide",
      title: "Creating Journal Entries",
      content: `To manually log a trade:
        1. Go to Journal tab
        2. Click "+ New Trade Entry"
        3. Fill in: Entry Price, Target, Stop Loss, Pair, Direction
        4. Add tags (optional): scalp, breakout, reversal, etc.
        5. Write trading thesis (why did you take the trade?)
        6. Add screenshots (chart setup, entry point)
        7. Submit - your entry is now tracked
        8. Update when you exit the trade`,
      keywords: ["journal", "entry", "manual", "logging", "trade"],
      source: "Platform Guide - Journal",
      updatedAt: new Date(),
    });

    // Strategies
    this.addItem({
      id: "strategy-breakout",
      category: "strategy",
      title: "Breakout Strategy Rules",
      content: `The approved breakout strategy:
        - Identify support/resistance level from 4H or Daily
        - Wait for 3+ touches without break
        - Confirmation: candle close + volume above level
        - Entry: On breakout candle close above level + next candle open
        - Target: 2x the breakout distance
        - Stop: Below the level
        - Only trade breakouts during London/NY sessions`,
      keywords: ["breakout", "support", "resistance", "volume"],
      source: "Approved Strategies - Breakout",
      updatedAt: new Date(),
    });

    // FAQs
    this.addItem({
      id: "faq-max-trades",
      category: "faq",
      title: "How many trades can I have open at once?",
      content: `Maximum 3 concurrent open trades across all pairs.
        - Each trade must have independent stop loss
        - Total exposure cannot exceed 5% of account
        - Correlation between pairs must be < 0.7`,
      keywords: ["max trades", "concurrent", "open", "multiple"],
      source: "FAQ - Trading Rules",
      updatedAt: new Date(),
    });

    this.addItem({
      id: "faq-drawdown",
      category: "faq",
      title: "What happens if I hit maximum drawdown?",
      content: `If you reach maximum drawdown (account loses 10%):
        - Trading will be PAUSED automatically
        - Contact support to review your recent trades
        - Complete a refresher on risk management rules
        - Submit a recovery plan before resuming
        - Next 5 trades will be half-size minimum`,
      keywords: ["drawdown", "maximum", "pause", "stop"],
      source: "FAQ - Risk Management",
      updatedAt: new Date(),
    });
  }

  addItem(item: KnowledgeItem) {
    this.items.set(item.id, item);
  }

  getItem(id: string): KnowledgeItem | undefined {
    return this.items.get(id);
  }

  searchByKeywords(query: string): KnowledgeItem[] {
    const queryLower = query.toLowerCase();
    const results: KnowledgeItem[] = [];

    for (const item of this.items.values()) {
      // Search in title
      if (item.title.toLowerCase().includes(queryLower)) {
        results.push(item);
        continue;
      }

      // Search in keywords
      if (item.keywords.some((k) => k.includes(queryLower))) {
        results.push(item);
        continue;
      }

      // Search in content (first 200 chars for relevance)
      if (item.content.substring(0, 200).toLowerCase().includes(queryLower)) {
        results.push(item);
      }
    }

    return results;
  }

  getByCategory(category: KnowledgeItem["category"]): KnowledgeItem[] {
    return Array.from(this.items.values()).filter(
      (item) => item.category === category
    );
  }

  getAllItems(): KnowledgeItem[] {
    return Array.from(this.items.values());
  }

  /**
   * Generate context string for AI system prompt
   */
  generateContextString(): string {
    const rules = this.getByCategory("rule");
    const context = rules
      .map((r) => `[RULE] ${r.title}: ${r.content}`)
      .join("\n\n");
    return context;
  }
}

// Singleton instance
export const knowledgeBase = new KnowledgeBase();
