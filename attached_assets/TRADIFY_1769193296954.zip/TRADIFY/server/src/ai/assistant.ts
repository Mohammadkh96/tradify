/**
 * OpenAI Assistant Integration
 * Teachable AI that's constrained by TRADIFY rules and knowledge base
 */

import OpenAI from "openai";
import { knowledgeBase } from "./knowledgeBase.js";

interface AssistantMessage {
  role: "user" | "assistant";
  content: string;
}

interface AssistantResponse {
  message: string;
  sources?: string[];
  confidence: number;
  refusal: boolean;
  logId: string;
}

export class TradifyAssistant {
  private client: OpenAI;
  private conversationHistory: AssistantMessage[] = [];
  private logs: AssistantLog[] = [];

  constructor(apiKey?: string) {
    const key = apiKey || process.env.OPENAI_API_KEY;
    if (!key) {
      throw new Error(
        "OPENAI_API_KEY not provided. Set it in environment variables."
      );
    }
    this.client = new OpenAI({ apiKey: key });
  }

  /**
   * Main chat interface
   */
  async chat(userMessage: string): Promise<AssistantResponse> {
    const logId = this.generateLogId();

    try {
      // Add user message to history
      this.conversationHistory.push({
        role: "user",
        content: userMessage,
      });

      // Retrieve relevant knowledge
      const relevantKnowledge = knowledgeBase.searchByKeywords(userMessage);
      const context = this.buildContext(relevantKnowledge);

      // Build system prompt
      const systemPrompt = this.buildSystemPrompt(context);

      // Call OpenAI
      const response = await this.client.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: systemPrompt,
          },
          ...this.conversationHistory,
        ],
        temperature: 0.7,
        max_tokens: 500,
      });

      const assistantMessage =
        response.choices[0].message.content || "No response";

      // Add to history
      this.conversationHistory.push({
        role: "assistant",
        content: assistantMessage,
      });

      // Log interaction
      const assistantResponse: AssistantResponse = {
        message: assistantMessage,
        sources: relevantKnowledge.map((k) => k.title),
        confidence: this.calculateConfidence(
          relevantKnowledge.length,
          assistantMessage
        ),
        refusal: false,
        logId,
      };

      this.logInteraction(
        logId,
        userMessage,
        assistantMessage,
        relevantKnowledge.map((k) => k.id)
      );

      return assistantResponse;
    } catch (error) {
      console.error("[AI Error]", error);
      throw error;
    }
  }

  /**
   * Build context from knowledge base
   */
  private buildContext(relevantItems: any[]): string {
    if (relevantItems.length === 0) {
      return "(No directly relevant knowledge found)";
    }

    return relevantItems
      .map((item) => `[${item.category.toUpperCase()}] ${item.title}\n${item.content}`)
      .join("\n\n---\n\n");
  }

  /**
   * Build system prompt with rules and constraints
   */
  private buildSystemPrompt(context: string): string {
    return `You are the TRADIFY AI Assistant - a helpful, rule-based trading guidance system.

YOUR CONSTRAINTS:
1. You ONLY answer questions about trading, TRADIFY platform, and rule compliance
2. Refuse any requests outside these domains politely
3. Never provide guaranteed trading advice or market predictions
4. Always reference the appropriate trading rule when relevant
5. Be concise and actionable in responses
6. If unsure, recommend consulting the platform guides

IMPORTANT DISCLAIMERS:
- Past performance does not guarantee future results
- All trading carries inherent risk, including the risk of complete loss
- Follow all rules strictly - they exist to protect your account
- This assistant is an educational tool, not financial advice

APPROVED KNOWLEDGE BASE:
${context}

CONVERSATION GUIDELINES:
- If the user asks about their specific trades, refer them to the Journal for analysis
- For position sizing questions, always cite the 2% rule
- For entry/exit questions, reference the breakout strategy or applicable rule
- Be encouraging but strict about rule compliance

Respond naturally but always stay grounded in TRADIFY rules and the knowledge base above.`;
  }

  /**
   * Calculate confidence based on knowledge match
   */
  private calculateConfidence(
    matchCount: number,
    _response: string
  ): number {
    // More knowledge matches = higher confidence
    // 0-3 matches: low confidence (0.4)
    // 4-6 matches: medium (0.7)
    // 7+ matches: high (0.95)
    if (matchCount >= 7) return 0.95;
    if (matchCount >= 4) return 0.7;
    if (matchCount >= 2) return 0.5;
    return 0.3;
  }

  /**
   * Clear conversation history (start new session)
   */
  clearHistory() {
    this.conversationHistory = [];
  }

  /**
   * Get conversation history
   */
  getHistory(): AssistantMessage[] {
    return [...this.conversationHistory];
  }

  /**
   * Log interaction for auditing and learning
   */
  private logInteraction(
    logId: string,
    userMessage: string,
    assistantMessage: string,
    knowledgeIds: string[]
  ) {
    const log: AssistantLog = {
      id: logId,
      timestamp: new Date(),
      userMessage,
      assistantMessage,
      knowledgeReferences: knowledgeIds,
      model: "gpt-3.5-turbo",
    };
    this.logs.push(log);
  }

  /**
   * Get all logs
   */
  getLogs(): AssistantLog[] {
    return [...this.logs];
  }

  /**
   * Generate unique log ID
   */
  private generateLogId(): string {
    return `log_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}

interface AssistantLog {
  id: string;
  timestamp: Date;
  userMessage: string;
  assistantMessage: string;
  knowledgeReferences: string[];
  model: string;
}

// Singleton instance
let assistantInstance: TradifyAssistant;

export function getAssistant(): TradifyAssistant {
  if (!assistantInstance) {
    assistantInstance = new TradifyAssistant();
  }
  return assistantInstance;
}
