/**
 * Database Module
 * Exports database connection and schema
 */

export { db, testConnection } from "./connection.js";
export * from "./schema.js";
