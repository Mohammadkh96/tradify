/**
 * Database Connection
 * Handles PostgreSQL connection using Drizzle ORM
 */

import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

const pool = new Pool({
  host: process.env.DB_HOST || "localhost",
  port: parseInt(process.env.DB_PORT || "5432", 10),
  database: process.env.DB_NAME || "tradify_db",
  user: process.env.DB_USER || "postgres",
  password: process.env.DB_PASSWORD || "postgres",
});

export const db = drizzle(pool);

export async function testConnection(): Promise<boolean> {
  try {
    const client = await pool.connect();
    const res = await client.query("SELECT NOW()");
    client.release();
    console.log("✓ Database connected:", res.rows[0]);
    return true;
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("✗ Database connection failed:", errorMessage);
    return false;
  }
}
