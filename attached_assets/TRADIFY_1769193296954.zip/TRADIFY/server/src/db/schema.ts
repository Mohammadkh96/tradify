/**
 * Database Schema
 * Drizzle ORM table definitions
 */

import { pgTable, serial, text, numeric, boolean, timestamp, varchar, integer } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const tradeJournal = pgTable("trade_journal", {
  id: serial("id").primaryKey(),
  asset: varchar("asset", { length: 50 }).notNull(),
  direction: varchar("direction", { length: 10 }).notNull(), // LONG or SHORT
  htfBias: varchar("htf_bias", { length: 20 }).notNull(), // BULLISH, BEARISH, NEUTRAL
  entryType: varchar("entry_type", { length: 20 }).notNull(), // RETEST, REVERSAL, BREAKOUT
  entryPrice: numeric("entry_price", { precision: 12, scale: 5 }).notNull(),
  stopLoss: numeric("stop_loss", { precision: 12, scale: 5 }).notNull(),
  takeProfit: numeric("take_profit", { precision: 12, scale: 5 }).notNull(),
  
  // Rule Compliance
  hasValidZone: boolean("has_valid_zone").notNull().default(false),
  hasLiquiditySweep: boolean("has_liquidity_sweep").notNull().default(false),
  hasObFvgRetest: boolean("has_ob_fvg_retest").notNull().default(false),
  chartImageUrl: text("chart_image_url"),
  
  // Status & Outcome
  status: varchar("status", { length: 20 }).notNull().default("PENDING"), // PENDING, ACTIVE, CLOSED, CANCELLED
  outcome: varchar("outcome", { length: 20 }), // WIN, LOSS, BREAK_EVEN
  closePrice: numeric("close_price", { precision: 12, scale: 5 }),
  
  // Compliance Info
  isRuleCompliant: boolean("is_rule_compliant").notNull().default(false),
  violationReasons: text("violation_reasons"), // JSON array or comma-separated
  
  // Trade Notes
  notes: text("notes"),
  
  // Metadata
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
  exitTime: timestamp("exit_time"),
});

export const userProfile = pgTable("user_profile", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 100 }).unique().notNull(),
  email: varchar("email", { length: 255 }).unique().notNull(),
  passwordHash: text("password_hash").notNull(),
  tradingCapital: numeric("trading_capital", { precision: 15, scale: 2 }).notNull(),
  riskPerTrade: numeric("risk_per_trade", { precision: 5, scale: 2 }).notNull().default("2.0"), // 2% default
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

/**
 * MT5 Connection Schema
 * Stores MetaTrader 5 connection info for each user
 */
export const mt5Connections = pgTable("mt5_connections", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(), // Foreign key to userProfile
  
  // MT5 Account Info
  accountNumber: varchar("account_number", { length: 20 }).notNull(),
  accountName: varchar("account_name", { length: 100 }),
  broker: varchar("broker", { length: 100 }), // e.g., "Exness", "Pepperstone"
  serverName: varchar("server_name", { length: 100 }), // e.g., "Exness-MT5"
  
  // Connection Status
  isConnected: boolean("is_connected").notNull().default(false),
  lastConnectedAt: timestamp("last_connected_at"),
  connectionStatus: varchar("connection_status", { length: 50 }).notNull().default("DISCONNECTED"), // CONNECTING, CONNECTED, DISCONNECTED, ERROR
  
  // Authentication Token (for local connector)
  connectionToken: varchar("connection_token", { length: 255 }).unique(), // One-time token for local connector
  tokenExpiresAt: timestamp("token_expires_at"),
  
  // Local Connector Info
  connectorVersion: varchar("connector_version", { length: 50 }), // Version of local connector app
  localConnectorIP: varchar("local_connector_ip", { length: 45 }), // IPv4 or IPv6
  
  // Account Statistics (synced from MT5)
  accountBalance: numeric("account_balance", { precision: 15, scale: 2 }),
  accountEquity: numeric("account_equity", { precision: 15, scale: 2 }),
  accountMargin: numeric("account_margin", { precision: 15, scale: 2 }),
  accountFreeMargin: numeric("account_free_margin", { precision: 15, scale: 2 }),
  accountProfit: numeric("account_profit", { precision: 15, scale: 2 }),
  
  // Metadata
  isActive: boolean("is_active").notNull().default(true),
  disconnectReason: text("disconnect_reason"), // Why connection ended
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

/**
 * MT5 Synced Trades Schema
 * Stores trades synced from user's MT5 terminal
 */
export const mt5SyncedTrades = pgTable("mt5_synced_trades", {
  id: serial("id").primaryKey(),
  mt5ConnectionId: integer("mt5_connection_id").notNull(), // Foreign key to mt5Connections
  
  // MT5 Trade Ticket Info
  ticket: varchar("ticket", { length: 20 }).notNull().unique(), // MT5 ticket/order number
  symbol: varchar("symbol", { length: 20 }).notNull(), // EURUSD, GBPUSD, etc
  magicNumber: integer("magic_number"), // EA magic number if automated
  
  // Trade Details
  tradeType: varchar("trade_type", { length: 10 }).notNull(), // BUY, SELL, BUY_LIMIT, SELL_LIMIT, etc
  entryTime: timestamp("entry_time").notNull(),
  entryPrice: numeric("entry_price", { precision: 12, scale: 5 }).notNull(),
  
  closeTime: timestamp("close_time"), // NULL if still open
  closePrice: numeric("close_price", { precision: 12, scale: 5 }),
  
  stopLoss: numeric("stop_loss", { precision: 12, scale: 5 }),
  takeProfit: numeric("take_profit", { precision: 12, scale: 5 }),
  
  volume: numeric("volume", { precision: 10, scale: 2 }).notNull(),
  profit: numeric("profit", { precision: 15, scale: 2 }), // Profit/loss in account currency
  
  // Trade Status
  isOpen: boolean("is_open").notNull().default(true),
  
  // Journal Linkage (optional - user can link to TRADIFY journal)
  linkedJournalId: integer("linked_journal_id"), // Foreign key to tradeJournal
  
  // Sync Metadata
  syncedAt: timestamp("synced_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});
