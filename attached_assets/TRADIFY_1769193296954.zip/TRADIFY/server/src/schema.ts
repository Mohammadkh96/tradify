import { pgTable, serial, text, numeric, boolean, timestamp, varchar, integer } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const tradeJournal = pgTable("trade_journal", {
  id: serial("id").primaryKey(),
  asset: varchar("asset", { length: 50 }).notNull(),
  direction: varchar("direction", { length: 10 }).notNull(), // LONG or SHORT
  htfBias: varchar("htf_bias", { length: 20 }).notNull(), // BULLISH, BEARISH, NEUTRAL
  entryType: varchar("entry_type", { length: 20 }).notNull(), // RETEST, REVERSAL, BREAKOUT
  entryPrice: numeric("entry_price", { precision: 12, scale: 5 }).notNull(),
  stopLoss: numeric("stop_loss", { precision: 12, scale: 5 }).notNull(),
  takeProfit: numeric("take_profit", { precision: 12, scale: 5 }).notNull(),
  
  // Rule Compliance
  hasValidZone: boolean("has_valid_zone").notNull().default(false),
  hasLiquiditySweep: boolean("has_liquidity_sweep").notNull().default(false),
  hasObFvgRetest: boolean("has_ob_fvg_retest").notNull().default(false),
  chartImageUrl: text("chart_image_url"),
  
  // Status & Outcome
  status: varchar("status", { length: 20 }).notNull().default("PENDING"), // PENDING, ACTIVE, CLOSED, CANCELLED
  outcome: varchar("outcome", { length: 20 }), // WIN, LOSS, BREAK_EVEN
  closePrice: numeric("close_price", { precision: 12, scale: 5 }),
  
  // Compliance Info
  isRuleCompliant: boolean("is_rule_compliant").notNull().default(false),
  violationReasons: text("violation_reasons"), // JSON array or comma-separated
  
  // Trade Notes
  notes: text("notes"),
  
  // Metadata
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
  exitTime: timestamp("exit_time"),
});

export const userProfile = pgTable("user_profile", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 100 }).unique().notNull(),
  tradingCapital: numeric("trading_capital", { precision: 15, scale: 2 }).notNull(),
  riskPerTrade: numeric("risk_per_trade", { precision: 5, scale: 2 }).notNull().default("2.0"), // 2% default
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

// TRADERS HUB SCHEMA

export const userRole = pgTable("user_role", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id", { length: 100 }).notNull().unique(),
  role: varchar("role", { length: 20 }).notNull(), // "PROVIDER" or "RECEIVER"
  kycVerified: boolean("kyc_verified").notNull().default(false),
  kycVerificationDate: timestamp("kyc_verification_date"),
  termsAccepted: boolean("terms_accepted").notNull().default(false),
  riskAcknowledged: boolean("risk_acknowledged").notNull().default(false),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const signalProviderProfile = pgTable("signal_provider_profile", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id", { length: 100 }).notNull().unique(),
  providerName: varchar("provider_name", { length: 100 }).notNull(),
  bio: text("bio"),
  profileImageUrl: text("profile_image_url"),
  
  // Trading Info
  tradingStyle: varchar("trading_style", { length: 50 }), // "intraday", "swing", "scalping", etc
  marketsTraded: text("markets_traded"), // JSON array: ["EURUSD", "BTCUSD", etc]
  signalType: varchar("signal_type", { length: 50 }), // "intraday", "swing", "crypto", "forex", etc
  yearsOfExperience: integer("years_of_experience"),
  
  // Communication Channels
  telegramHandle: varchar("telegram_handle", { length: 100 }),
  whatsappLink: text("whatsapp_link"),
  discordServer: text("discord_server"),
  customPlatform: text("custom_platform"), // Custom link/platform
  
  // Performance (Self-Reported & Unverified)
  monthlyReturnPercentage: numeric("monthly_return_percentage", { precision: 10, scale: 2 }),
  winRate: numeric("win_rate", { precision: 5, scale: 2 }), // 0-100
  performanceHistory: text("performance_history"), // JSON: [{ month, return, trades }]
  performanceVerified: boolean("performance_verified").notNull().default(false),
  verificationBadgeType: varchar("verification_badge_type", { length: 20 }), // "UNVERIFIED", "IDENTITY_VERIFIED", "PERFORMANCE_AUDITED"
  
  // Pricing & Subscription
  pricingModel: varchar("pricing_model", { length: 50 }), // "FREE", "SUBSCRIPTION", "ONE_TIME", "COMMISSION"
  monthlyPrice: numeric("monthly_price", { precision: 10, scale: 2 }),
  yearlyPrice: numeric("yearly_price", { precision: 10, scale: 2 }),
  priceDescription: text("price_description"),
  
  // Platform Status
  isActive: boolean("is_active").notNull().default(true),
  isVerified: boolean("is_verified").notNull().default(false),
  suspendedUntil: timestamp("suspended_until"),
  suspensionReason: text("suspension_reason"),
  
  // Legal Compliance
  disclaimerAcknowledged: boolean("disclaimer_acknowledged").notNull().default(false),
  noGuaranteeAcknowledged: boolean("no_guarantee_acknowledged").notNull().default(false),
  
  // Metadata
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
  viewCount: integer("view_count").notNull().default(0),
  subscriberCount: integer("subscriber_count").notNull().default(0),
});

export const signalReceiver = pgTable("signal_receiver", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id", { length: 100 }).notNull().unique(),
  receiverName: varchar("receiver_name", { length: 100 }).notNull(),
  bio: text("bio"),
  profileImageUrl: text("profile_image_url"),
  interestedMarkets: text("interested_markets"), // JSON array
  experience: varchar("experience", { length: 20 }), // "beginner", "intermediate", "advanced"
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const providerSubscription = pgTable("provider_subscription", {
  id: serial("id").primaryKey(),
  receiverId: varchar("receiver_id", { length: 100 }).notNull(),
  providerId: varchar("provider_id", { length: 100 }).notNull(),
  subscriptionStatus: varchar("subscription_status", { length: 20 }).notNull(), // "ACTIVE", "INACTIVE", "CANCELLED"
  joinedAt: timestamp("joined_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
  cancelledAt: timestamp("cancelled_at"),
  externalPlatform: varchar("external_platform", { length: 50 }), // "TELEGRAM", "WHATSAPP", "DISCORD", etc
  externalUserId: varchar("external_user_id", { length: 100 }), // User's ID on external platform
});

export const dispute = pgTable("dispute", {
  id: serial("id").primaryKey(),
  reporterId: varchar("reporter_id", { length: 100 }).notNull(),
  reportedProviderId: varchar("reported_provider_id", { length: 100 }).notNull(),
  reason: varchar("reason", { length: 50 }).notNull(), // "FAKE_RESULTS", "SCAM", "ABUSIVE", "MISLEADING_CLAIMS"
  description: text("description").notNull(),
  evidence: text("evidence"), // JSON array of file URLs
  status: varchar("status", { length: 20 }).notNull().default("PENDING"), // "PENDING", "INVESTIGATING", "RESOLVED", "CLOSED"
  resolution: text("resolution"),
  action: varchar("action", { length: 20 }), // "NONE", "WARNING", "SUSPENDED", "BANNED"
  resolvedAt: timestamp("resolved_at"),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
  updatedAt: timestamp("updated_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const platformDisclaimer = pgTable("platform_disclaimer", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id", { length: 100 }).notNull(),
  disclaimerVersion: varchar("disclaimer_version", { length: 10 }).notNull(),
  disclaimerText: text("disclaimer_text").notNull(),
  acceptedAt: timestamp("accepted_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});
