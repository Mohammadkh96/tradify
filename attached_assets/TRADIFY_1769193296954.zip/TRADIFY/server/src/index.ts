/**
 * TRADIFY Server - Main Entry Point
 * 
 * Institutional-grade trading application with deterministic rule engine
 */

import express, { Request, Response, NextFunction } from "express";
import cors from "cors";
import compression from "compression";
import dotenv from "dotenv";
import { testConnection } from "./db/index.js";
import { errorHandler, AppError } from "./api/errors.js";
import { Logger } from "./api/logger.js";
import tradesRouter from "./api/trades.js";
import analyticsRouter from "./api/analytics.js";
import riskRouter from "./api/risk.js";
import mt5Router from "./api/mt5.js";
import authRouter from "./api/auth.js";
import mt5ConnectionRouter from "./api/mt5-connection.js";
import aiRouter from "./api/ai.js";
import tradersHubRouter from "./api/traders-hub.js";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3002;

// Middleware
app.use(compression({ level: 6 }));
app.use(cors());
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

// Serve static files (downloads)
import path from "path";
import { fileURLToPath } from "url";
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(express.static(path.join(__dirname, "../../public")));

// Request logging (development only)
if (process.env.NODE_ENV !== "production") {
  app.use((req: Request, res: Response, next: NextFunction) => {
    Logger.debug(`${req.method} ${req.path}`);
    next();
  });
}

// Health Check
app.get("/api/health", (req: Request, res: Response) => {
  res.json({ 
    status: "ok", 
    timestamp: new Date().toISOString(),
    version: "1.0.0",
    mode: "read-only" // MT5 is read-only/journal mode
  });
});

// Compliance status endpoint (hardcoded rules)
app.get("/api/compliance", (req: Request, res: Response) => {
  res.json({
    status: "compliant",
    rules: [
      { id: "GR-02", name: "HTF Bias Alignment", status: "active" },
      { id: "GR-03", name: "Valid Supply/Demand Zone", status: "active" },
      { id: "GR-05", name: "Entry Confirmation Required", status: "active" },
      { id: "GR-08", name: "Liquidity Sweep Prerequisite", status: "active" }
    ],
    mode: "enforced"
  });
});

// Download routes for connector files
app.get("/tradify_mt5_connector.py", (req: Request, res: Response) => {
  const filePath = path.join(__dirname, "../../tradify_mt5_connector.py");
  res.download(filePath, "tradify_mt5_connector.py");
});

app.get("/run-connector.bat", (req: Request, res: Response) => {
  const filePath = path.join(__dirname, "../../run-connector.bat");
  res.download(filePath, "run-connector.bat");
});

// API Routes
app.use("/api/auth", authRouter);
app.use("/api/trades", tradesRouter);
app.use("/api/analytics", analyticsRouter);
app.use("/api/risk", riskRouter);
app.use("/api/mt5", mt5Router);
app.use("/api/mt5", mt5ConnectionRouter); // MT5 connection endpoints
app.use("/api/ai", aiRouter); // AI Assistant endpoints
app.use("/api/traders-hub", tradersHubRouter); // Traders Hub marketplace endpoints

// Error handling middleware (must be last)
app.use(errorHandler);

// 404 handler
app.use((req: Request, res: Response) => {
  res.status(404).json({
    success: false,
    error: {
      code: "NOT_FOUND",
      message: `Route ${req.path} not found`,
    },
  });
});

// Start server
async function start(): Promise<void> {
  const dbConnected = await testConnection();

  if (!dbConnected) {
    Logger.warn("Database not available. Running in demo mode.");
  }

  app.listen(PORT, () => {
    Logger.info(`TRADIFY Server running on http://localhost:${PORT}`);
    Logger.info(`Health check: http://localhost:${PORT}/api/health`);
    Logger.info(`Mode: Read-only/Journal (no auto-trading)`);
  });
}

start().catch((error) => {
  Logger.error("Fatal error starting server", { error: error instanceof Error ? error.message : "Unknown error" });
  process.exit(1);
});
