#!/usr/bin/env python3
"""
MT5 Bridge - Connects to MetaTrader 5 terminal on the local machine
Provides REST API endpoints to query MT5 account and trade data
"""

import json
import socket
import struct
import time
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, asdict
from datetime import datetime

@dataclass
class MT5AccountInfo:
    account: int
    balance: float
    equity: float
    free_margin: float
    margin_level: float
    account_type: str  # "demo" or "live"
    broker: str
    server: str
    connected: bool
    last_sync: str

@dataclass
class MT5Trade:
    ticket: int
    symbol: str
    direction: str  # "long" or "short"
    volume: float
    entry_price: float
    current_price: float
    floating_pl: float
    risk_reward: Optional[float]
    open_time: str
    order_type: str

class MT5Bridge:
    """Bridge to connect with MetaTrader 5 terminal"""
    
    def __init__(self, port: int = 9090):
        self.port = port
        self.socket = None
        self.connected = False
        self.account_info: Optional[MT5AccountInfo] = None
        self.trades: List[MT5Trade] = []
        
    def connect(self) -> bool:
        """Connect to MT5 terminal via socket"""
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.connect(('127.0.0.1', self.port))
            self.socket.settimeout(5)
            self.connected = True
            return True
        except (ConnectionRefusedError, socket.timeout):
            self.connected = False
            return False
    
    def disconnect(self):
        """Disconnect from MT5 terminal"""
        if self.socket:
            self.socket.close()
        self.connected = False
    
    def send_command(self, command: str) -> Optional[Dict[str, Any]]:
        """Send command to MT5 and receive response"""
        if not self.connected:
            return None
            
        try:
            # Send command
            self.socket.sendall(command.encode() + b'\n')
            
            # Receive response
            response = b''
            while True:
                data = self.socket.recv(1024)
                if not data:
                    break
                response += data
                if b'\n' in response:
                    break
            
            return json.loads(response.decode().strip())
        except Exception as e:
            print(f"Error sending command: {e}")
            self.disconnect()
            return None
    
    def get_account_info(self) -> Optional[MT5AccountInfo]:
        """Get account information from MT5"""
        response = self.send_command("ACCOUNT_INFO")
        if response and response.get("success"):
            data = response.get("data", {})
            self.account_info = MT5AccountInfo(
                account=data.get("account", 0),
                balance=float(data.get("balance", 0)),
                equity=float(data.get("equity", 0)),
                free_margin=float(data.get("free_margin", 0)),
                margin_level=float(data.get("margin_level", 0)),
                account_type=data.get("account_type", "demo"),
                broker=data.get("broker", "Unknown"),
                server=data.get("server", "Unknown"),
                connected=True,
                last_sync=datetime.now().isoformat()
            )
            return self.account_info
        return None
    
    def get_open_trades(self) -> List[MT5Trade]:
        """Get list of open trades from MT5"""
        response = self.send_command("OPEN_TRADES")
        if response and response.get("success"):
            trades_data = response.get("data", [])
            self.trades = []
            for trade_data in trades_data:
                trade = MT5Trade(
                    ticket=trade_data.get("ticket", 0),
                    symbol=trade_data.get("symbol", ""),
                    direction="long" if trade_data.get("direction") == "BUY" else "short",
                    volume=float(trade_data.get("volume", 0)),
                    entry_price=float(trade_data.get("entry_price", 0)),
                    current_price=float(trade_data.get("current_price", 0)),
                    floating_pl=float(trade_data.get("floating_pl", 0)),
                    risk_reward=float(trade_data.get("risk_reward")) if trade_data.get("risk_reward") else None,
                    open_time=trade_data.get("open_time", ""),
                    order_type=trade_data.get("order_type", "")
                )
                self.trades.append(trade)
            return self.trades
        return []
    
    def login(self, account: int, password: str, server: str) -> bool:
        """Attempt to login to MT5 account"""
        command = f'LOGIN|{account}|{password}|{server}'
        response = self.send_command(command)
        return response and response.get("success", False)


# Global MT5 bridge instance
mt5 = MT5Bridge()

def get_mt5_account_info() -> Optional[Dict[str, Any]]:
    """Get MT5 account info, reconnect if needed"""
    if not mt5.connected:
        if not mt5.connect():
            return None
    
    info = mt5.get_account_info()
    return asdict(info) if info else None

def get_mt5_open_trades() -> List[Dict[str, Any]]:
    """Get open trades from MT5"""
    if not mt5.connected:
        if not mt5.connect():
            return []
    
    trades = mt5.get_open_trades()
    return [asdict(t) for t in trades]

def mt5_login(account: int, password: str, server: str) -> bool:
    """Login to MT5"""
    if not mt5.connected:
        if not mt5.connect():
            return False
    
    return mt5.login(account, password, server)

def mt5_is_connected() -> bool:
    """Check if MT5 is connected"""
    if not mt5.connected:
        return mt5.connect()
    return True

if __name__ == "__main__":
    print("MT5 Bridge initialized. Import this module and use the functions above.")
