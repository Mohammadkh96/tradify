# TRADIFY - Complete File Index

## 📋 Root Files

| File | Purpose |
|------|---------|
| `package.json` | Root workspace configuration, npm scripts |
| `README.md` | Complete project documentation |
| `QUICKSTART.md` | 5-minute setup guide |
| `BUILD_SUMMARY.md` | What was built - comprehensive checklist |
| `ARCHITECTURE.md` | System design, data flows, diagrams |
| `CUSTOMIZATION.md` | How to modify and extend TRADIFY |
| `.gitignore` | Git ignore rules |

---

## 📁 Shared Package (`shared/`)

**Purpose**: Type-safe schemas, enums, and validation logic shared between frontend and backend.

| File | Lines | Purpose |
|------|-------|---------|
| `package.json` | 20 | Package metadata |
| `tsconfig.json` | 12 | TypeScript configuration |
| `src/index.ts` | 180+ | Zod schemas, Global Hard Rules, validation functions |

**Key Exports**:
- `TradeEntrySchema` - Zod validation schema
- `GlobalHardRules` - GR-02, GR-03, GR-05, GR-08 rules
- `validateTradeCompliance()` - Rule engine
- `calculatePositionSize()` - Position size calculator
- `calculateRiskRewardRatio()` - R:R calculation
- Enums: Direction, TradeStatus, MarketStructure, EntryType, OutcomeType

---

## 🖥️ Server Package (`server/`)

**Purpose**: Express.js backend with REST API, rule validation, and PostgreSQL database.

### Configuration Files

| File | Purpose |
|------|---------|
| `package.json` | Dependencies (express, drizzle, postgres, zod) |
| `tsconfig.json` | TypeScript compilation settings |
| `.env.local` | Database credentials (ignored by git) |
| `.gitignore` | Ignore node_modules, dist, .env.local |

### Source Files

| File | Lines | Purpose |
|------|-------|---------|
| `src/index.ts` | 300+ | Express server, all API endpoints, error handling |
| `src/db.ts` | 25 | PostgreSQL connection with Drizzle ORM |
| `src/schema.ts` | 60 | Database table definitions (trade_journal, user_profile) |

### API Endpoints

```
GET    /api/health                    Health check
GET    /api/trades                    Get all trades
GET    /api/trades/:id               Get trade by ID
POST   /api/trades                   Create new trade
PUT    /api/trades/:id               Update trade
POST   /api/trades/:id/close         Mark WIN/LOSS/BREAK_EVEN
POST   /api/trades/validate          Real-time validation (no save)
GET    /api/analytics/performance    Get performance metrics
POST   /api/risk/calculate           Calculate position size
```

---

## ⚛️ Client Package (`client/`)

**Purpose**: React + Vite frontend with Stealth Terminal UI/UX.

### Configuration Files

| File | Purpose |
|------|---------|
| `package.json` | Dependencies (React, Vite, TailwindCSS, React Query, etc.) |
| `vite.config.ts` | Vite configuration, dev server, proxy to backend |
| `tailwind.config.js` | Tailwind CSS theme customization |
| `postcss.config.js` | PostCSS/Tailwind pipeline |
| `tsconfig.json` | TypeScript configuration for React |
| `tsconfig.node.json` | TypeScript configuration for Vite config |
| `index.html` | HTML entry point |
| `.gitignore` | Ignore node_modules, dist, .env.local |

### Source Files

#### Main Entry Point

| File | Lines | Purpose |
|------|-------|---------|
| `src/main.tsx` | 10 | React DOM render entry point |
| `src/App.tsx` | 120 | Main app container, 5 tabs, sidebar, navigation |
| `src/index.css` | 100 | Tailwind imports, custom animations, global styles |

#### Components

| File | Lines | Purpose |
|------|-------|---------|
| `src/components/DashboardTab.tsx` | 35 | Performance metrics dashboard |
| `src/components/JournalTab.tsx` | 30 | Chronological trade feed |
| `src/components/NewEntryTab.tsx` | 15 | Trade creation workflow |
| `src/components/KnowledgeBaseTab.tsx` | 90 | 10 accordion modules, rule explanations |
| `src/components/RiskCalculatorTab.tsx` | 80 | Position size calculator |

#### Form & UI Components

| File | Lines | Purpose |
|------|-------|---------|
| `src/components/NewEntryForm.tsx` | 200+ | Complex form with real-time validation |
| `src/components/TradeCard.tsx` | 70 | Trade display card with badges |
| `src/components/PerformanceCards.tsx` | 80 | Metric cards + charts |
| `src/components/HUD.tsx` | 50 | Heads-Up Display (rule violations/valid status) |
| `src/components/RuleToggle.tsx` | 35 | Custom pill switch component |
| `src/components/DirectionButton.tsx` | 35 | LONG/SHORT selector buttons |
| `src/components/InputField.tsx` | 20 | Reusable form input wrapper |

#### API Hooks

| File | Lines | Purpose |
|------|-------|---------|
| `src/api/hooks.ts` | 90 | React Query hooks for all API calls |

**Hooks**:
- `usePerformanceMetrics()` - Get dashboard metrics
- `useValidateTrade()` - Real-time validation
- `useCreateTrade()` - Create new trade
- `useTrades()` - Get all trades
- `useCloseTrade()` - Mark trade as WIN/LOSS
- TypeScript types: `PerformanceMetrics`, `TradeEntry`

---

## 📊 Component Tree

```
App (src/App.tsx)
├── Sidebar
│   ├── Logo
│   ├── Nav Buttons (5)
│   └── Daily Reminder
│
├── DashboardTab
│   ├── PerformanceCards (6 metric cards)
│   │   └── TradeCard[] (recent)
│   └── Pie Chart
│
├── JournalTab
│   └── TradeCard[] (all trades)
│
├── NewEntryTab
│   └── NewEntryForm
│       ├── Form Inputs
│       ├── DirectionButton
│       ├── RuleToggle (3x)
│       └── HUD
│
├── KnowledgeBaseTab
│   ├── AccordionItem[] (10 modules)
│   └── Rules Summary
│
└── RiskCalculatorTab
    ├── Inputs
    └── Results
```

---

## 🗄️ Database Schema

### Table: `trade_journal`

| Column | Type | Purpose |
|--------|------|---------|
| `id` | SERIAL PK | Trade ID |
| `asset` | VARCHAR(50) | Symbol (EURUSD, BTC, AAPL) |
| `direction` | VARCHAR(10) | LONG or SHORT |
| `htfBias` | VARCHAR(20) | BULLISH, BEARISH, NEUTRAL |
| `entryType` | VARCHAR(20) | RETEST, REVERSAL, BREAKOUT |
| `entryPrice` | NUMERIC(12,5) | Entry price |
| `stopLoss` | NUMERIC(12,5) | Stop loss price |
| `takeProfit` | NUMERIC(12,5) | Take profit price |
| `hasValidZone` | BOOLEAN | Zone toggle (GR-03) |
| `hasLiquiditySweep` | BOOLEAN | Liquidity toggle (GR-08) |
| `hasObFvgRetest` | BOOLEAN | OB/FVG toggle (GR-05) |
| `chartImageUrl` | TEXT | Chart image URL/data |
| `status` | VARCHAR(20) | PENDING, ACTIVE, CLOSED, CANCELLED |
| `outcome` | VARCHAR(20) | WIN, LOSS, BREAK_EVEN |
| `closePrice` | NUMERIC(12,5) | Exit price (if closed) |
| `isRuleCompliant` | BOOLEAN | All rules pass? |
| `violationReasons` | TEXT | JSON array of violations |
| `notes` | TEXT | Trade notes |
| `createdAt` | TIMESTAMP | Trade creation time |
| `updatedAt` | TIMESTAMP | Last update time |
| `exitTime` | TIMESTAMP | Trade exit time |

### Table: `user_profile`

| Column | Type | Purpose |
|--------|------|---------|
| `id` | SERIAL PK | User ID |
| `username` | VARCHAR(100) UQ | Username |
| `tradingCapital` | NUMERIC(15,2) | Account balance |
| `riskPerTrade` | NUMERIC(5,2) | Risk % (default 2.0) |
| `createdAt` | TIMESTAMP | Account creation |
| `updatedAt` | TIMESTAMP | Last update |

---

## 🎨 Styling Files

| File | Purpose |
|------|---------|
| `src/index.css` | Global styles, Tailwind imports, custom animations |
| `tailwind.config.js` | Theme colors, fonts, custom keyframes |
| `postcss.config.js` | PostCSS pipeline (Tailwind, AutoPrefixer) |

---

## 📦 Dependencies

### Frontend (`client/package.json`)
```json
{
  "react": "^18.2.0",                           // UI library
  "react-dom": "^18.2.0",                       // DOM rendering
  "react-hook-form": "^7.51.0",                 // Complex forms
  "@tanstack/react-query": "^5.28.0",          // Server state
  "lucide-react": "^0.356.0",                   // Icons
  "recharts": "^2.10.3",                        // Charts
  "framer-motion": "^10.16.16",                 // Animations
  "tailwindcss": "^3.4.1"                       // Styling
}
```

### Backend (`server/package.json`)
```json
{
  "express": "^4.18.2",                         // Web framework
  "cors": "^2.8.5",                             // CORS middleware
  "dotenv": "^16.3.1",                          // Env variables
  "pg": "^8.11.3",                              // PostgreSQL driver
  "drizzle-orm": "^0.29.3",                     // ORM
  "drizzle-kit": "^0.20.13"                     // ORM CLI
}
```

### Shared (`shared/package.json`)
```json
{
  "zod": "^3.22.4"                              // Schema validation
}
```

---

## 🔐 Security & Validation

### Frontend Validation
- React Hook Form + Zod in NewEntryForm
- Real-time HUD feedback

### Backend Validation
- Zod schema parsing in all endpoints
- Rule engine validation in validateTradeCompliance()
- TypeScript type checking

### Database
- Constraints on tables
- Drizzle ORM type safety

---

## 📈 Key Metrics

| Metric | Value |
|--------|-------|
| Total Components | 13 |
| API Endpoints | 9 |
| Database Tables | 2 |
| Global Hard Rules | 4 |
| Application Tabs | 5 |
| TypeScript Files | 20+ |
| Lines of Code | ~2,500+ |
| Design Colors | 7 |
| Custom Animations | 2 |

---

## 🚀 File Deployment

### Build Output

```
After npm run build:
├── client/dist/                    (Frontend build)
│   ├── index.html
│   ├── assets/                     (JS, CSS, images)
│   └── ...
│
└── server/dist/                    (Backend build)
    ├── index.js
    ├── db.js
    ├── schema.js
    └── ...
```

### Deployment Checklist

- [ ] Build frontend: `npm run build`
- [ ] Build server: `npm run build`
- [ ] Set production environment variables
- [ ] Set up PostgreSQL database
- [ ] Deploy frontend (Vercel, Netlify, static server)
- [ ] Deploy backend (Heroku, Railway, VPS)
- [ ] Verify API connectivity
- [ ] Test all endpoints

---

## 📚 Documentation Files

| File | Purpose |
|------|---------|
| `README.md` | Full project documentation (1,000+ lines) |
| `QUICKSTART.md` | 5-minute setup (150 lines) |
| `BUILD_SUMMARY.md` | What was built (500+ lines) |
| `ARCHITECTURE.md` | System design & flows (600+ lines) |
| `CUSTOMIZATION.md` | How to modify (400+ lines) |
| `FILE_INDEX.md` | This file - complete reference |

---

## 🔍 Quick File Lookup

### "How do I...?"

| Question | File |
|----------|------|
| ...install? | `QUICKSTART.md` |
| ...add a new rule? | `shared/src/index.ts` + `CUSTOMIZATION.md` |
| ...add a new tab? | `client/src/App.tsx` + `CUSTOMIZATION.md` |
| ...modify colors? | `client/tailwind.config.js` |
| ...add API endpoint? | `server/src/index.ts` + `CUSTOMIZATION.md` |
| ...understand the rules? | `client/src/components/KnowledgeBaseTab.tsx` |
| ...validate a trade? | `shared/src/index.ts` `validateTradeCompliance()` |
| ...change database? | `server/src/schema.ts` |
| ...learn architecture? | `ARCHITECTURE.md` |

---

## ✅ Completeness Checklist

- ✅ All 13 components implemented
- ✅ All 5 tabs functional
- ✅ All 4 Global Hard Rules enforced
- ✅ All 9 API endpoints working
- ✅ Database schema with 2 tables
- ✅ Stealth Terminal dark theme
- ✅ Real-time HUD validation
- ✅ Performance metrics dashboard
- ✅ Risk calculator
- ✅ Knowledge base with 10 modules
- ✅ Complete documentation
- ✅ Customization guide
- ✅ Architecture documentation

---

**TRADIFY is complete, documented, and ready for deployment!** 🚀
