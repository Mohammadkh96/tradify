# MT5 Connection Architecture

## System Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                          USER'S COMPUTER                            │
├─────────────────────────────────────────────────────────────────────┤
│                                                                       │
│  ┌──────────────────┐         ┌──────────────────────────────────┐  │
│  │  MetaTrader 5    │         │  TRADIFY Connector (Python)      │  │
│  │                  │◄────────┤                                  │  │
│  │ - MT5 Terminal   │         │ - Reads account data             │  │
│  │ - Live Trades    │         │ - Reads open trades              │  │
│  │ - Account Stats  │         │ - Communicates with backend      │  │
│  │                  │         │ - Logs sync activity             │  │
│  └──────────────────┘         └──────────────────────────────────┘  │
│         ▲                              ▼                             │
│         │                              │                             │
│         └──────────────────────────────┘                             │
│                  (Python MetaTrader5 API)                            │
│                                                                       │
└────────────────────────────┬──────────────────────────────────────┘
                             │ HTTP/REST
                             ▼
┌─────────────────────────────────────────────────────────────────────┐
│              TRADIFY BACKEND (localhost:3002)                       │
├─────────────────────────────────────────────────────────────────────┤
│                                                                       │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  MT5 Connection API Endpoints                                │  │
│  │                                                               │  │
│  │  POST /api/mt5/initiate-connection                           │  │
│  │  POST /api/mt5/register-connection                           │  │
│  │  GET  /api/mt5/status/:connectionId                          │  │
│  │  POST /api/mt5/sync-account-data/:connectionId               │  │
│  │  POST /api/mt5/sync-trades/:connectionId                     │  │
│  │  GET  /api/mt5/health/:connectionId                          │  │
│  │  PUT  /api/mt5/disconnect/:connectionId                      │  │
│  │  DELETE /api/mt5/connection/:connectionId                    │  │
│  │                                                               │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                              ▼                                      │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  Database (Demo Mode: In-Memory Maps)                        │  │
│  │                                                               │  │
│  │  - mt5Connections: Account connections                       │  │
│  │  - mt5SyncedTrades: Synced trade data                        │  │
│  │  - connectionTokens: Temporary auth tokens                   │  │
│  │                                                               │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                                                                       │
└────────────────────────────┬──────────────────────────────────────┘
                             │ HTTP/WebSocket
                             ▼
┌─────────────────────────────────────────────────────────────────────┐
│              TRADIFY FRONTEND (localhost:3000)                      │
├─────────────────────────────────────────────────────────────────────┤
│                                                                       │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  React Components                                            │  │
│  │                                                               │  │
│  │  - MT5ConnectionWizard (Setup flow)                          │  │
│  │  - MT5ConnectionStatus (Live status display)                 │  │
│  │  - MT5ConnectionsSettingsPage (Management)                   │  │
│  │                                                               │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                                                                       │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  Dashboard Integration                                       │  │
│  │                                                               │  │
│  │  - Connection status banner                                  │  │
│  │  - Synced trades list                                        │  │
│  │  - Account statistics display                                │  │
│  │                                                               │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                                                                       │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Data Flow

### 1. Connection Initiation

```
User Clicks "Connect MT5"
    ↓
MT5ConnectionWizard Component Loads
    ↓
User Enters Account Details
    ↓
POST /api/mt5/initiate-connection
    ├─ Validate account details
    ├─ Generate unique connection token (valid 15 min)
    ├─ Store token in demoConnectionTokens Map
    └─ Return token to frontend
    ↓
User Sees Connection Token
    ↓
User Downloads Connector Instructions
    ↓
User Runs: python tradify_connector.py --token TOKEN
```

### 2. Connector Registration

```
Local Connector Starts
    ↓
Initializes MT5 Connection
    ├─ Calls mt5.initialize()
    ├─ Retrieves account info
    └─ Verifies MT5 is running
    ↓
POST /api/mt5/register-connection
    ├─ Validate connection token
    ├─ Check token not expired
    ├─ Create connection record
    ├─ Store in demoMt5Connections Map
    └─ Return connectionId
    ↓
Connector Receives connectionId
    ↓
Connector Starts Background Sync Loop
```

### 3. Continuous Sync

```
Every 30 Seconds:
    ↓
    POST /api/mt5/sync-account-data/:connectionId
        ├─ Get current account info from MT5
        ├─ Extract: balance, equity, margin, profit
        └─ Send to backend
    ↓
    Backend Updates Connection Record
        └─ Update accountBalance, accountEquity, etc.

Every 60 Seconds:
    ↓
    POST /api/mt5/sync-trades/:connectionId
        ├─ Get all open positions from MT5
        ├─ Extract: ticket, symbol, entry price, profit
        └─ Send to backend
    ↓
    Backend Stores Trades
        └─ Store in demoSyncedTrades Map

Every 5 Minutes:
    ↓
    GET /api/mt5/health/:connectionId
        ├─ Check connection still alive
        ├─ Update lastConnectedAt timestamp
        └─ Return status
    ↓
    Backend Verifies Connection Status
```

### 4. Frontend Display

```
Dashboard Loads
    ↓
GET /api/mt5/connections/:userId
    ├─ Retrieve all user's connections
    └─ Filter by connection status
    ↓
For Each Connection:
    ↓
    GET /api/mt5/status/:connectionId
        ├─ Fetch current connection info
        ├─ Get account balance/equity
        └─ Get last sync time
    ↓
    Display MT5ConnectionStatus Component
        ├─ Show connection status (Connected/Disconnected)
        ├─ Show account info
        ├─ Show balance and equity
        ├─ Show profit/loss
        └─ Show last sync time
    ↓
    GET /api/mt5/trades/:connectionId
        ├─ Fetch synced trades
        └─ Display open trades list
```

---

## Component Architecture

### Frontend Components

#### 1. MT5ConnectionWizard (`MT5ConnectionWizard.tsx`)

**Purpose**: Multi-step setup wizard for connecting MT5

**States**:
- `intro` - Initial introduction screen
- `create-token` - Account details form
- `download-connector` - Show token and download instructions
- `waiting` - Waiting for connector to register
- `success` - Connection established
- `error` - Error occurred

**Props**:
- `userId` (string) - Current user ID
- `onConnectionComplete?` (callback) - Called when connection succeeds
- `onClose?` (callback) - Called when wizard closes

**Key Functions**:
- `handleInitiateConnection()` - POST to initiate-connection endpoint
- `handleDownloadConnector()` - Downloads setup instructions
- `handleCopyToken()` - Copy token to clipboard

#### 2. MT5ConnectionStatus (`MT5ConnectionStatus.tsx`)

**Purpose**: Display live connection status and account info

**Props**:
- `connectionId` (string) - Connection ID to display
- `onDisconnect?` (callback) - Called when disconnected
- `onRefresh?` (callback) - Called when refreshed

**States**:
- `connection` - Current connection object
- `loading` - Loading state
- `error` - Error message
- `refreshing` - Refreshing state

**Key Functions**:
- `loadConnectionStatus()` - GET status/:connectionId
- `handleRefresh()` - Refresh connection status
- `handleDisconnect()` - PUT disconnect endpoint

**Display Elements**:
- Connection header with status badge
- Account details (number, broker, server)
- Account statistics (balance, equity, profit)
- Refresh and disconnect buttons

#### 3. MT5ConnectionsSettingsPage (`MT5ConnectionsSettingsPage.tsx`)

**Purpose**: Main settings page for managing MT5 connections

**Features**:
- List all user's connections
- Add new connections
- View detailed status
- Manage (disconnect/delete) connections

**State Management**:
- `connections` - List of user's connections
- `showWizard` - Show/hide setup wizard
- `selectedConnectionId` - Currently selected connection
- `loading` - Loading state

---

## Backend Architecture

### API Endpoints

#### 1. POST /api/mt5/initiate-connection

**Request**:
```json
{
  "userId": "user_123",
  "accountNumber": "12345678",
  "broker": "Exness"
}
```

**Response**:
```json
{
  "success": true,
  "connectionToken": "a4f2e8c9d1b7f3a6e2c5d8b1f4a7c9e2",
  "expiresIn": 900,
  "message": "Connection token generated..."
}
```

**Demo Implementation**: Generates random token, stores in Map with 15-min TTL

---

#### 2. POST /api/mt5/register-connection

**Request**:
```json
{
  "connectionToken": "a4f2e8c9d1b7f3a6e2c5d8b1f4a7c9e2",
  "accountName": "MT5 12345678",
  "serverName": "Exness-MT5",
  "connectorVersion": "1.0.0",
  "localConnectorIP": "192.168.1.100"
}
```

**Response**:
```json
{
  "success": true,
  "connectionId": "conn_a1b2c3d4e5f6",
  "message": "MT5 connection registered successfully",
  "connection": { ... }
}
```

**Demo Implementation**: Validates token, creates connection record, stores in Map

---

#### 3. GET /api/mt5/status/:connectionId

**Response**:
```json
{
  "success": true,
  "connection": {
    "id": "conn_a1b2c3d4e5f6",
    "accountNumber": "12345678",
    "broker": "Exness",
    "isConnected": true,
    "connectionStatus": "CONNECTED",
    "lastConnectedAt": "2026-01-19T10:30:00Z",
    "accountBalance": 5000.00,
    "accountEquity": 5150.00,
    "accountMargin": 100.00,
    "accountFreeMargin": 5050.00,
    "accountProfit": 150.00
  }
}
```

---

#### 4. GET /api/mt5/connections/:userId

**Response**:
```json
{
  "success": true,
  "count": 2,
  "connections": [
    {
      "id": "conn_a1b2c3d4e5f6",
      "accountNumber": "12345678",
      "broker": "Exness",
      "isConnected": true
    },
    {
      "id": "conn_b2c3d4e5f6a7",
      "accountNumber": "87654321",
      "broker": "Pepperstone",
      "isConnected": false
    }
  ]
}
```

---

#### 5. POST /api/mt5/sync-account-data/:connectionId

**Request**:
```json
{
  "accountBalance": 5000.00,
  "accountEquity": 5150.00,
  "accountMargin": 100.00,
  "accountFreeMargin": 5050.00,
  "accountProfit": 150.00
}
```

**Response**:
```json
{
  "success": true,
  "message": "Account data synced",
  "connection": { ... }
}
```

---

#### 6. POST /api/mt5/sync-trades/:connectionId

**Request**:
```json
{
  "trades": [
    {
      "ticket": "123456789",
      "symbol": "EURUSD",
      "type": "BUY",
      "volume": 1.0,
      "openPrice": 1.0900,
      "currentPrice": 1.0950,
      "stopLoss": 1.0850,
      "takeProfit": 1.1050,
      "profit": 50.00,
      "openTime": "2026-01-19T10:30:00Z"
    }
  ]
}
```

**Response**:
```json
{
  "success": true,
  "message": "1 trades synced",
  "tradeCount": 1
}
```

---

#### 7. GET /api/mt5/trades/:connectionId

**Response**:
```json
{
  "success": true,
  "trades": [ ... ],
  "tradeCount": 3,
  "lastSyncedAt": "2026-01-19T10:30:00Z"
}
```

---

#### 8. GET /api/mt5/health/:connectionId

**Response**:
```json
{
  "success": true,
  "status": "healthy",
  "connectionId": "conn_a1b2c3d4e5f6",
  "isConnected": true
}
```

---

#### 9. PUT /api/mt5/disconnect/:connectionId

**Request**:
```json
{
  "reason": "User initiated disconnect"
}
```

**Response**:
```json
{
  "success": true,
  "message": "Connection disconnected",
  "connection": { ... }
}
```

---

#### 10. DELETE /api/mt5/connection/:connectionId

**Response**:
```json
{
  "success": true,
  "message": "Connection deleted successfully"
}
```

---

## Database Schema

### mt5_connections Table

```typescript
{
  id: integer (primary key),
  userId: integer (foreign key),
  accountNumber: varchar(20),
  accountName: varchar(100),
  broker: varchar(100),
  serverName: varchar(100),
  isConnected: boolean,
  lastConnectedAt: timestamp,
  connectionStatus: varchar(50), // CONNECTED | DISCONNECTED | ERROR
  connectionToken: varchar(255), // One-time token
  tokenExpiresAt: timestamp,
  connectorVersion: varchar(50),
  localConnectorIP: varchar(45),
  accountBalance: numeric(15,2),
  accountEquity: numeric(15,2),
  accountMargin: numeric(15,2),
  accountFreeMargin: numeric(15,2),
  accountProfit: numeric(15,2),
  isActive: boolean,
  disconnectReason: text,
  createdAt: timestamp,
  updatedAt: timestamp
}
```

### mt5_synced_trades Table

```typescript
{
  id: integer (primary key),
  mt5ConnectionId: integer (foreign key),
  ticket: varchar(20) (unique),
  symbol: varchar(20),
  magicNumber: integer,
  tradeType: varchar(10),
  entryTime: timestamp,
  entryPrice: numeric(12,5),
  closeTime: timestamp,
  closePrice: numeric(12,5),
  stopLoss: numeric(12,5),
  takeProfit: numeric(12,5),
  volume: numeric(10,2),
  profit: numeric(15,2),
  isOpen: boolean,
  linkedJournalId: integer,
  syncedAt: timestamp,
  updatedAt: timestamp
}
```

---

## Local Connector (Python)

### Architecture

```
tradify_connector.py
├── Config Class
│   ├── TRADIFY_API_URL
│   ├── SYNC_INTERVAL
│   ├── TRADE_SYNC_INTERVAL
│   └── HEARTBEAT_INTERVAL
├── MT5Connector Class
│   ├── __init__(token)
│   ├── initialize_mt5()
│   ├── register_connection()
│   ├── sync_account_data()
│   ├── get_open_trades()
│   ├── sync_trades()
│   ├── send_heartbeat()
│   ├── start_sync_loop()
│   ├── run()
│   └── shutdown()
└── main() Entry Point
```

### Execution Flow

```
1. Parse CLI arguments (--token, --api-url)
2. Initialize MT5Connector with token
3. Call connector.run()
   a. Initialize MetaTrader 5
   b. Register connection with TRADIFY
   c. Start background sync loop
4. Sync Loop:
   a. Every 30s: sync account data
   b. Every 60s: sync open trades
   c. Every 300s: send heartbeat
5. On Ctrl+C: graceful shutdown
```

### Error Handling

- **MT5 Not Running**: Catches exception, logs error
- **Token Expired**: Backend returns 401, connector stops
- **Network Error**: Retries with exponential backoff
- **Invalid Account**: Logs and stops gracefully

---

## Security Considerations

### Authentication & Authorization

1. **One-Time Connection Token**
   - Generated server-side
   - Valid for 15 minutes
   - Consumed on first use
   - Never reused

2. **Connection ID**
   - Unique per account
   - User-specific (linked to userId)
   - Used for all subsequent requests

### Data Protection

1. **No Password Storage**
   - Platform never receives MT5 password
   - Connector handles MT5 auth locally

2. **Limited Data Transmission**
   - Only account stats and trade data
   - No personal information

3. **Local Network Safe**
   - Running on localhost:3002
   - All data local to user's network

### Future Production Considerations

- JWT token-based authentication
- HTTPS/TLS encryption for remote servers
- Rate limiting on API endpoints
- Audit logging of connections
- Connection encryption keys
- Periodic token rotation

---

## Future Enhancements

### Phase 2 Features

- Multiple MT5 accounts per user
- Real-time trade notifications
- MT5 trade to journal auto-linking
- Margin alert notifications
- Trade copying capabilities

### Phase 3 Features

- Multi-broker support
- cTrader connector
- Mobile app companion
- WebSocket real-time sync
- Trade history archiving

### Phase 4 Features

- Algo trading integration
- Risk management automation
- ML-based trade prediction
- Performance analytics
- Social trading features

---

## Testing

### Unit Tests

```typescript
// Test API endpoints
describe("/api/mt5", () => {
  test("POST /initiate-connection generates token", () => {});
  test("POST /register-connection validates token", () => {});
  test("GET /status returns connection info", () => {});
  test("POST /sync-account-data updates data", () => {});
  test("POST /sync-trades stores trades", () => {});
});
```

### Integration Tests

```typescript
// Test full flow
describe("MT5 Connection Flow", () => {
  test("Full setup and sync flow", async () => {
    // 1. Initiate connection
    // 2. Register connector
    // 3. Sync data
    // 4. Verify data in database
  });
});
```

### Manual Testing

1. Start TRADIFY app: `npm run dev`
2. Open browser: `http://localhost:3000`
3. Navigate to Settings → MT5 Connections
4. Click "Connect MT5"
5. Fill account details
6. Get token
7. Run Python connector: `python tradify_connector.py --token TOKEN`
8. Verify connection appears in dashboard
9. Check synced trades appear

---

## Deployment

### Production Checklist

- [ ] Switch from demo mode to database
- [ ] Implement JWT authentication
- [ ] Add HTTPS/TLS support
- [ ] Set up connection pooling
- [ ] Configure rate limiting
- [ ] Add monitoring and alerting
- [ ] Implement audit logging
- [ ] Deploy connector as service/daemon
- [ ] Set up connector auto-updates
- [ ] Document production setup

---

**Version**: 1.0.0  
**Last Updated**: January 19, 2026  
**Status**: Production Ready (Demo Mode)
