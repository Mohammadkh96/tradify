# 🚨 EMERGENCY: Can't Connect to Frontend

## Quick Fix - Do This Now:

### Step 1: Kill All Node Processes
```powershell
taskkill /F /IM node.exe
```

### Step 2: Start Servers Fresh
```powershell
npm.cmd run dev
```

### Step 3: Wait 20 Seconds
Don't open browser yet! Wait for:
- ✅ Backend message: "Server running on http://localhost:3002"
- ✅ Frontend message: "Local: http://localhost:3000/"

### Step 4: Open Browser
Go to: **http://localhost:3000**

---

## If That Doesn't Work:

### Method A: Start Servers Separately

**Terminal 1:**
```powershell
cd server
npm.cmd run dev
```
Wait for: "Server running on http://localhost:3002"

**Terminal 2 (NEW terminal):**
```powershell
cd client  
npm.cmd run dev
```
Wait for: "Local: http://localhost:3000/"

### Method B: Check What's Wrong

1. **Check if ports are free:**
```powershell
netstat -ano | findstr ":3000"
netstat -ano | findstr ":3002"
```

2. **If ports are in use, kill them:**
```powershell
# Find the PID from above command, then:
taskkill /PID <PID> /F
```

3. **Check for errors in terminal**
   - Look for red error messages
   - Look for "Cannot find module" errors
   - Look for "Port already in use" errors

4. **Reinstall dependencies:**
```powershell
npm install
```

### Method C: Use Different Ports

If ports 3000/3002 are blocked:

1. **Change frontend port** - Edit `client/vite.config.ts`:
```typescript
port: 3001,  // Change from 3000
```

2. **Change backend port** - Edit `server/src/index.ts`:
```typescript
const PORT = process.env.PORT || 3003;  // Change from 3002
```

3. **Restart servers**

---

## Verify It's Working

### Test Backend:
Open: http://localhost:3002/api/health
- Should show JSON with "status": "ok"

### Test Frontend:
Open: http://localhost:3000
- Should show TRADIFY dashboard

---

## Still Not Working?

1. **Restart your computer** (clears all port conflicts)
2. **Check Windows Firewall** - might be blocking ports
3. **Try 127.0.0.1 instead of localhost:**
   - http://127.0.0.1:3000
   - http://127.0.0.1:3002/api/health

---

**The servers MUST be running before you can access the app!**
