# MT5 Integration into TRADIFY Dashboard

## Overview

This guide shows how to integrate the MT5 connection system into the existing TRADIFY dashboard and components.

---

## 1. Update Dashboard Layout

### Add MT5 Status Banner

In `client/src/layouts/DashboardLayout.tsx`, add at the top:

```typescript
import { MT5ConnectionStatus } from "../components/MT5ConnectionStatus";

export const DashboardLayout: React.FC = () => {
  const [userConnections, setUserConnections] = useState<string[]>([]);

  useEffect(() => {
    // Fetch user's MT5 connections on load
    const fetchConnections = async () => {
      try {
        const response = await fetch(`/api/mt5/connections/${userId}`);
        if (response.ok) {
          const data = await response.json();
          const connectionIds = data.connections.map((c: any) => c.id);
          setUserConnections(connectionIds);
        }
      } catch (error) {
        console.error("Failed to load connections:", error);
      }
    };

    fetchConnections();
  }, []);

  return (
    <div className="flex h-screen bg-gray-950">
      {/* Sidebar */}
      <div className="w-64 bg-gray-900 border-r border-gray-700 p-6 overflow-y-auto">
        {/* Existing sidebar content */}
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        {/* MT5 Connection Status - Show if connected */}
        {userConnections.length > 0 && (
          <div className="bg-gradient-to-r from-blue-900/20 to-emerald-900/20 border-b border-gray-700 p-4">
            <div className="max-w-7xl mx-auto">
              <h3 className="text-sm font-semibold mb-3">Active MT5 Connections</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {userConnections.map((connId) => (
                  <MT5ConnectionStatus
                    key={connId}
                    connectionId={connId}
                    onDisconnect={() => {
                      // Refresh connections
                      setUserConnections(
                        userConnections.filter((id) => id !== connId)
                      );
                    }}
                  />
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Rest of dashboard */}
        {/* Tabs, charts, etc. */}
      </div>
    </div>
  );
};
```

---

## 2. Add MT5 Tab to Dashboard

In the existing `DashboardTab.tsx` or create new `MT5TradesTab.tsx`:

```typescript
import React, { useEffect, useState } from "react";
import { AlertCircle, RefreshCw } from "lucide-react";

interface SyncedTrade {
  ticket: string;
  symbol: string;
  type: string;
  entryPrice: number;
  volume: number;
  profit: number;
  openTime: string;
}

export const MT5TradesTab: React.FC<{ connectionId?: string }> = ({ connectionId }) => {
  const [trades, setTrades] = useState<SyncedTrade[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>("");

  useEffect(() => {
    if (connectionId) {
      fetchTrades();
    }
  }, [connectionId]);

  const fetchTrades = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/mt5/trades/${connectionId}`);

      if (!response.ok) throw new Error("Failed to fetch trades");

      const data = await response.json();
      setTrades(data.trades || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Error loading trades");
    } finally {
      setLoading(false);
    }
  };

  if (!connectionId) {
    return (
      <div className="p-8 text-center">
        <p className="text-gray-400">No MT5 connection active</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="p-8 text-center">
        <RefreshCw className="animate-spin mx-auto mb-2" />
        <p className="text-gray-400">Loading MT5 trades...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-8">
        <div className="bg-red-500/10 border border-red-500 rounded p-4">
          <div className="flex gap-2">
            <AlertCircle size={20} className="text-red-500 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-red-200">Error Loading Trades</h3>
              <p className="text-sm text-red-200">{error}</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">MT5 Synced Trades</h2>
        <button
          onClick={fetchTrades}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 rounded-lg transition"
        >
          <RefreshCw size={18} />
        </button>
      </div>

      {trades.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-400">No open trades in MT5</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {trades.map((trade) => (
            <div
              key={trade.ticket}
              className="bg-gray-900 border border-gray-700 rounded-lg p-4"
            >
              <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
                <div>
                  <p className="text-xs text-gray-400">Ticket</p>
                  <p className="font-mono text-sm">{trade.ticket}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Symbol</p>
                  <p className="font-bold">{trade.symbol}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Type</p>
                  <p
                    className={
                      trade.type === "BUY"
                        ? "text-emerald-400 font-semibold"
                        : "text-red-400 font-semibold"
                    }
                  >
                    {trade.type}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Entry Price</p>
                  <p className="font-mono text-sm">{trade.entryPrice.toFixed(5)}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Volume</p>
                  <p className="font-mono text-sm">{trade.volume}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">P/L</p>
                  <p
                    className={
                      trade.profit >= 0 ? "text-emerald-400" : "text-red-400"
                    }
                  >
                    ${trade.profit.toFixed(2)}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
```

---

## 3. Add Settings Menu Item

In `client/src/pages/DashboardLayout.tsx`, update the navigation:

```typescript
import { Settings } from "lucide-react";
import { Link } from "react-router-dom";

// In the sidebar navigation:
<nav className="space-y-4">
  {/* Existing tabs */}
  <button className="w-full text-left px-4 py-2 rounded hover:bg-gray-800">
    Dashboard
  </button>
  <button className="w-full text-left px-4 py-2 rounded hover:bg-gray-800">
    Journal
  </button>
  {/* ... other tabs ... */}

  {/* Settings with dropdown */}
  <div className="pt-4 border-t border-gray-700">
    <Link
      to="/settings/mt5"
      className="flex items-center gap-2 px-4 py-2 rounded hover:bg-gray-800"
    >
      <Settings size={18} />
      MT5 Connections
    </Link>
  </div>
</nav>
```

---

## 4. Create Settings Route

In your routing configuration:

```typescript
import { MT5ConnectionsSettingsPage } from "../pages/MT5ConnectionsSettingsPage";

export const routes = [
  // ... existing routes ...
  {
    path: "/settings/mt5",
    element: <MT5ConnectionsSettingsPage />,
  },
];
```

---

## 5. Add MT5 Quick Action Card

In the main dashboard, add a quick connection card:

```typescript
export const DashboardOverview: React.FC = () => {
  const [hasConnection, setHasConnection] = useState(false);

  useEffect(() => {
    // Check if user has any MT5 connection
    fetch(`/api/mt5/connections/${userId}`)
      .then((r) => r.json())
      .then((data) => setHasConnection(data.count > 0))
      .catch(() => setHasConnection(false));
  }, []);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {/* Existing cards */}

      {/* MT5 Connection Card */}
      {!hasConnection && (
        <div className="bg-gradient-to-br from-blue-900 to-blue-800 rounded-lg p-6 border border-blue-700">
          <h3 className="text-lg font-bold mb-2">Connect MT5</h3>
          <p className="text-sm text-blue-100 mb-4">
            Sync your MetaTrader 5 trades automatically
          </p>
          <Link
            to="/settings/mt5"
            className="inline-block px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-sm font-semibold transition"
          >
            Set Up Now →
          </Link>
        </div>
      )}

      {/* MT5 Connected Card */}
      {hasConnection && (
        <div className="bg-gradient-to-br from-emerald-900 to-emerald-800 rounded-lg p-6 border border-emerald-700">
          <h3 className="text-lg font-bold mb-2">✓ MT5 Connected</h3>
          <p className="text-sm text-emerald-100 mb-4">
            Your trades are syncing automatically
          </p>
          <Link
            to="/settings/mt5"
            className="inline-block px-4 py-2 bg-emerald-600 hover:bg-emerald-700 rounded-lg text-sm font-semibold transition"
          >
            Manage Connection →
          </Link>
        </div>
      )}
    </div>
  );
};
```

---

## 6. Integration Checklist

- [ ] Import MT5 components in dashboard
- [ ] Add MT5 status banner to top of dashboard
- [ ] Create MT5 trades tab
- [ ] Add settings menu item
- [ ] Create MT5 connection route
- [ ] Add quick action cards
- [ ] Update navigation menu
- [ ] Test all links and buttons
- [ ] Verify API calls work
- [ ] Test with and without connection
- [ ] Check responsive design
- [ ] Verify error states

---

## 7. Example Integrated Dashboard Layout

```typescript
export const DashboardLayout: React.FC = () => {
  const [activeTab, setActiveTab] = useState<"overview" | "journal" | "mt5">("overview");
  const [userConnections, setUserConnections] = useState<any[]>([]);

  return (
    <div className="flex h-screen bg-gray-950">
      {/* Sidebar */}
      <aside className="w-64 bg-gray-900 border-r border-gray-700 p-6">
        <h1 className="text-2xl font-bold mb-8">TRADIFY</h1>

        <nav className="space-y-2">
          <button
            onClick={() => setActiveTab("overview")}
            className={`w-full text-left px-4 py-2 rounded ${
              activeTab === "overview"
                ? "bg-emerald-600 text-white"
                : "hover:bg-gray-800"
            }`}
          >
            Dashboard
          </button>
          <button
            onClick={() => setActiveTab("journal")}
            className={`w-full text-left px-4 py-2 rounded ${
              activeTab === "journal"
                ? "bg-emerald-600 text-white"
                : "hover:bg-gray-800"
            }`}
          >
            Journal
          </button>
          <button
            onClick={() => setActiveTab("mt5")}
            className={`w-full text-left px-4 py-2 rounded ${
              activeTab === "mt5"
                ? "bg-emerald-600 text-white"
                : "hover:bg-gray-800"
            }`}
          >
            MT5 Trades
          </button>

          <div className="pt-6 border-t border-gray-700">
            <Link
              to="/settings/mt5"
              className="flex items-center gap-2 px-4 py-2 rounded hover:bg-gray-800"
            >
              <Settings size={18} />
              MT5 Settings
            </Link>
          </div>
        </nav>

        {/* Logout button at bottom */}
        <div className="absolute bottom-6 left-6 right-6">
          <button className="w-full px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded">
            Logout
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        {/* MT5 Status Banner */}
        {userConnections.length > 0 && (
          <div className="bg-emerald-900/20 border-b border-emerald-700 p-4">
            <div className="max-w-7xl mx-auto">
              <p className="text-sm text-emerald-200">
                ✓ MT5 Connected: {userConnections.length} account(s)
              </p>
            </div>
          </div>
        )}

        {/* Tab Content */}
        {activeTab === "overview" && <DashboardOverview />}
        {activeTab === "journal" && <JournalTab />}
        {activeTab === "mt5" && <MT5TradesTab connectionId={userConnections[0]?.id} />}
      </main>
    </div>
  );
};
```

---

## 8. CSS/Styling Notes

The MT5 components use TailwindCSS dark theme:
- Primary color: `emerald-600` for active/connected state
- Secondary color: `gray-700` for borders
- Background: `gray-900` for cards, `gray-950` for main background
- Text: `text-gray-400` for secondary, `text-white` for primary

All components are responsive and work on mobile.

---

## 9. Testing the Integration

```bash
# 1. Start TRADIFY
npm run dev

# 2. In browser, navigate to dashboard
http://localhost:3000/dashboard

# 3. Should see "Connect MT5" card (if no connections)
# 4. Click "MT5 Settings" in sidebar
# 5. Should open MT5ConnectionsSettingsPage
# 6. Follow setup wizard
# 7. Get token and run connector
# 8. Return to dashboard
# 9. Should see "MT5 Connected" status
# 10. Click "MT5 Trades" tab
# 11. Should see synced trades list
```

---

## 10. Performance Optimization

```typescript
// Memoize components if needed
export const MT5StatusBanner = React.memo(({ connections }) => {
  // ...
});

// Use useCallback for event handlers
const handleConnectionComplete = useCallback((id) => {
  // Refresh connections
}, []);

// Lazy load MT5 components if dashboard gets heavy
const MT5TradesTab = lazy(() => import("./MT5TradesTab"));
```

---

## 11. Error Handling

Make sure to handle:
- No MT5 connection exists
- Connector is not running
- API is unavailable
- Network errors
- Token expired
- Invalid connectionId

All shown with user-friendly error messages and retry buttons.

---

## 12. Next Steps After Integration

1. Test full dashboard flow
2. Verify all API calls work
3. Check error states
4. Test mobile responsiveness
5. Verify logging works
6. Set up analytics if desired
7. Deploy to production
8. Monitor connection stability

---

**Your MT5 integration is now complete and ready to use!** 🚀
