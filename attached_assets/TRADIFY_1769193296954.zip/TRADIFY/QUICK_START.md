# TRADIFY Quick Start Guide

## 🚀 Getting Started

### Prerequisites
- Node.js 18+
- PostgreSQL 14+ (optional - runs in demo mode without DB)
- npm or yarn

### Installation

```bash
# Install all dependencies
npm install
```

### Development Mode

```bash
# Start both frontend and backend
npm run dev

# If you get PowerShell execution policy errors, use:
npm.cmd run dev

# Or use the provided scripts:
# Windows: start-dev.bat
# PowerShell: .\start-dev.ps1
```

**Access the application:**
- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:3002
- **Health Check**: http://localhost:3002/api/health

### Testing

```bash
# Run rule engine tests
cd server
npm run test
```

## 📁 Project Structure

```
TRADIFY/
├── client/                 # React + Vite frontend
│   └── src/
│       ├── components/     # UI components (pure, no logic)
│       └── api/           # API hooks
├── server/                 # Node.js + Express backend
│   └── src/
│       ├── engine/        # Rule evaluation (deterministic)
│       ├── market_knowledge/  # JSON rules (versioned)
│       ├── api/           # API routes & validation
│       └── db/            # Database schema & connection
└── shared/                # Shared types & schemas
```

## 🎯 Key Features

### 1. Deterministic Rule Engine
- Rules loaded from JSON (`server/src/market_knowledge/rules.json`)
- Pure functions (no side effects)
- Same input → same output (deterministic)
- Structured violations: `{ rule_id, rule_name, reason }`

### 2. Read-Only MT5 Integration
- **Mode**: Read-only/Journal (no auto-trading)
- File-based bridge (reliable, offline)
- Status: `GET /api/mt5/status`

### 3. Type Safety
- Strict TypeScript (no `any` types)
- Validated market facts
- Type-safe error handling

### 4. Audit Trail
- All rule evaluations logged
- Structured JSON logs
- Versioned rules

## 🔐 Global Hard Rules

1. **GR-02**: HTF Bias Alignment
   - LONG only in BULLISH markets
   - SHORT only in BEARISH markets

2. **GR-03**: Valid Supply/Demand Zone
   - Entry must be in valid zone

3. **GR-05**: Entry Confirmation Required
   - OB/FVG retest confirmation mandatory

4. **GR-08**: Liquidity Sweep Prerequisite
   - REVERSAL entries require liquidity sweep

## 📡 API Endpoints

### Trades
- `POST /api/trades/validate` - Validate trade (real-time)
- `POST /api/trades` - Create trade (rejects if rules fail)
- `GET /api/trades` - List all trades
- `GET /api/trades/:id` - Get trade by ID

### Analytics
- `GET /api/analytics/performance` - Performance metrics

### Risk
- `POST /api/risk/calculate` - Calculate position size

### MT5 (Read-Only)
- `GET /api/mt5/status` - Connection status
- `GET /api/mt5/account` - Account data
- `GET /api/mt5/open-trades` - Open positions

### Health
- `GET /api/health` - Server health check

## 🧪 Testing the Rule Engine

```typescript
import { evaluateRules } from "./server/src/engine";

const facts = {
  asset: "EURUSD",
  direction: "LONG",
  htfBias: "BULLISH",
  entryType: "RETEST",
  entryPrice: 1.0850,
  stopLoss: 1.0800,
  takeProfit: 1.0950,
  hasValidZone: true,
  hasLiquiditySweep: false,
  hasObFvgRetest: true,
};

const result = evaluateRules(facts);
// Returns: { isValid: boolean, violations: RuleViolation[] }
```

## 🔧 Configuration

### Environment Variables (server/.env.local)

```env
DB_HOST=localhost
DB_PORT=5432
DB_NAME=tradify_db
DB_USER=postgres
DB_PASSWORD=postgres
PORT=3002
NODE_ENV=development
```

### MT5 File Path (optional)

```env
MT5_FILE_PATH=C:\Users\YourName\AppData\Roaming\MetaQuotes\Terminal\Common\Files\tradify_mt5_data.json
```

## 📝 Adding New Rules

Edit `server/src/market_knowledge/rules.json`:

```json
{
  "id": "GR-09",
  "name": "My Custom Rule",
  "type": "required",
  "condition": {
    "field": "myField",
    "operator": "equals",
    "value": true
  },
  "violation_message": "GR-09: Custom rule violation"
}
```

## ⚠️ Important Notes

1. **No Auto-Trading**: MT5 integration is read-only
2. **Rule Enforcement**: Trades cannot be created if rules fail
3. **Deterministic**: Same input always produces same output
4. **Auditable**: All rule evaluations are logged

## 🐛 Troubleshooting

### Database Connection Failed
- App runs in demo mode without DB
- Check `.env.local` for correct credentials

### MT5 Not Detected
- Ensure `TradifyBridge.ex5` is running in MT5
- Check file path in `GET /api/mt5/status`

### Port Already in Use
- Frontend: Change port in `client/vite.config.ts`
- Backend: Change `PORT` in `.env.local`

## 📚 Documentation

- **Architecture**: See `ARCHITECTURE.md`
- **Refactoring Details**: See `REFACTORING_COMPLETE.md`
- **MT5 Setup**: See `MT5_SETUP_GUIDE.md`

---

**Ready to trade?** Start the dev server and visit http://localhost:3000
