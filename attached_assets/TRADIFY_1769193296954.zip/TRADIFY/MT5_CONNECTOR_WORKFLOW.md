# MT5 Connector - Visual Workflow

## User Journey Map

```
┌─────────────────────────────────────────────────────────────────┐
│ TRADIFY WEB APP (Browser)                                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Dashboard → Click "MT5 Connection"                             │
│  ├─ Enter MT5 Account Number                                   │
│  ├─ Select Broker                                              │
│  └─ Click "Generate Connection Token"                          │
│     │                                                           │
│     ▼ (Token generated, user sees)                             │
│  ┌─────────────────────────────────────┐                       │
│  │ One-Time Token: abc123xyz789...     │ ◄─ COPY BUTTON        │
│  │ Expires in ~15 minutes              │                       │
│  │ ⬇️ Download Connector (Windows)     │ ◄─ DOWNLOAD BUTTON    │
│  └─────────────────────────────────────┘                       │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
                          │
                          │ User clicks Download
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│ USER'S DESKTOP                                                   │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  tradify-connector.exe (downloaded)                             │
│  │                                                              │
│  └─► Double-click                                              │
│      │                                                          │
│      ▼                                                          │
│  ┌─────────────────────────────────────┐                       │
│  │ TRADIFY MT5 Connector GUI           │                       │
│  ├─────────────────────────────────────┤                       │
│  │                                     │                       │
│  │ ◀ Registration  Account  Trades ▶  │                       │
│  │                                     │                       │
│  │ API URL: [text field]               │                       │
│  │ Token:   [text field]               │                       │
│  │                                     │                       │
│  │         [Register Button]           │                       │
│  │                                     │                       │
│  │ ✅ Registration successful!         │                       │
│  │ Connection ID: conn_xyz123          │                       │
│  │                                     │                       │
│  └─────────────────────────────────────┘                       │
│                                                                  │
│  User switches to "Account Sync" tab                           │
│  ├─ Account #: [text]                                          │
│  ├─ Balance:   [text]                                          │
│  ├─ Equity:    [text]                                          │
│  └─ [Sync Account]                                             │
│     ▼                                                           │
│  ✅ Account synced successfully!                               │
│                                                                  │
│  User switches to "Trades Sync" tab                            │
│  └─ [Paste trades JSON]                                        │
│     [Sync Trades]                                              │
│     ▼                                                           │
│  ✅ 42 trades synced successfully!                             │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
                          │
                          │ User returns to browser
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│ TRADIFY WEB APP (Back in Browser)                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Dashboard → MT5 Connection (already open)                     │
│  │                                                              │
│  ├─ [Refresh] button                                           │
│  │   ▼                                                          │
│  │  ✅ Connection Status: ACTIVE                              │
│  │  Account: 12345678 @ MetaTrader5                           │
│  │  Balance: $10,000.00                                        │
│  │  Last Sync: Just now                                        │
│  │                                                              │
│  ├─ [Refresh Trades]                                           │
│  │   ▼                                                          │
│  │  ✅ Loaded 42 trades                                        │
│  │  Trade #1: EURUSD BUY +$150.00 ✓                          │
│  │  Trade #2: GBPUSD SELL -$50.00 ✗                          │
│  │  Trade #3: USDJPY BUY +$200.00 ✓                          │
│  │  ...                                                        │
│  │                                                              │
│  └─ Trades automatically appear in Journal!                    │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## Technical Flow

```
                    TRADIFY SERVER
                    ══════════════
                         │
        ┌────────────────┼────────────────┐
        │                │                │
        ▼                ▼                ▼
    /initiate-        /register-       /sync-trades
    connection        connection       (:connectionId)
        │                │                │
        │ Returns        │ Validates       │ Stores
        │ token+expiry   │ token once      │ trades
        │                │ then invalidate │
        │                │                │
        └────────────────┼────────────────┘
                         │
             (Connector makes calls)
                         │
                    CONNECTOR APP
                    ═════════════
                         │
        ┌────────────────┼────────────────┐
        │                │                │
        ▼                ▼                ▼
    1. Register       2. Sync            3. Sync
    with token        account            trades
       │                │                  │
       │                │                  │
    ┌──┴────┐        ┌──┴────┐        ┌───┴────┐
    │ Auth  │        │Data   │        │Journal │
    │ Token │        │Sync   │        │Update  │
    └───────┘        └───────┘        └────────┘
```

## Token State Machine

```
┌─────────────┐
│ Generated   │ ← /initiate-connection called
│ Token       │
└──────┬──────┘
       │ User copies & downloads connector
       ▼
┌─────────────┐
│ Pending     │ ← Waiting for connector to use token
│ Registration│
└──────┬──────┘
       │ User pastes token in connector
       │ Clicks "Register"
       ▼
┌─────────────┐
│ Valid       │ ← /register-connection called with token
│ (1 attempt) │   Server validates and generates connectionId
└──────┬──────┘
       │ Token consumed (invalidated)
       ▼
┌─────────────┐
│ Used        │ ← Connection established
│ (Expired)   │   Connector has connectionId now
└─────────────┘
       │ Can't be reused
       │ New token must be generated for new connection
       ▼
  (If not used within 15 mins, auto-expires)
```

## UI Components

### Token Display (Before - After)

**Before:**
```
One-Time Token
abc123xyz789def456ghi789jkl012mno345

Paste this token into the desktop connector app.
```

**After (New):**
```
One-Time Token          Expires in ~15 min
┌──────────────────────────────────────────┐ ┌────────┐
│ abc123xyz789def456ghi789jkl012mno345pqr │ │ 📋 Copy │
└──────────────────────────────────────────┘ └────────┘

📥 Download the connector app below, paste this 
token, and it will auto-register your MT5 connection.

┌────────────────────────────────────────────────┐
│  ⬇️ Download Connector (Windows)               │
└────────────────────────────────────────────────┘
```

### Copy Button States

```
State 1: Initial
  ┌─────────┐
  │ 📋 Copy │  ← Hover shows tooltip "Copy token"
  └─────────┘

State 2: Clicked (for 2 seconds)
  ┌──────────┐
  │ ✅ Check │  ← Green icon shows success
  └──────────┘

State 3: Back to Initial (after 2 seconds)
  ┌─────────┐
  │ 📋 Copy │
  └─────────┘
```

## Folder Structure

```
TRADIFY/
├── client/
│   └── src/components/
│       └── MT5ConnectionModal.tsx ← Copy button added
│
├── server/
│   └── src/index.ts ← Static file serving added
│
├── public/
│   └── downloads/
│       └── tradify-connector.exe ← Auto-downloaded here
│
├── tradify_mt5_connector.py ← Desktop connector app
├── run-connector.bat ← Windows launcher
├── build_connector.py ← Builds .exe
│
└── docs/
    ├── CONNECTOR_QUICK_START.md
    ├── MT5_CONNECTOR_USER_GUIDE.md
    └── MT5_CONNECTOR_IMPLEMENTATION.md
```

## Security Boundaries

```
┌─────────────────────────────────┐
│  TRADIFY WEB APP (User Browser) │
│  ✅ Secure: HTTPS in production │
│  ✅ No MT5 credentials here     │
└─────────────────────────────────┘
              │
         (One-time token)
              │
              ▼
┌─────────────────────────────────┐
│  TRADIFY SERVER                 │
│  ✅ Validates token once        │
│  ✅ Generates connectionId      │
│  ✅ Stores account data         │
│  ✅ Receives trades only        │
└─────────────────────────────────┘
              │
         (connectionId)
              │
              ▼
┌─────────────────────────────────┐
│  CONNECTOR APP (Local Desktop)  │
│  ✅ No MT5 passwords stored     │
│  ✅ No credentials transmitted  │
│  ✅ Local-only file operations  │
│  ⚠️ User responsible for security│
└─────────────────────────────────┘
```

## Timeline

```
[User starts] ──► [5 sec] → [Paste token]
                            │
                            ▼ [1 min]
                        [Registered]
                            │
                            ▼ [2 min]
                        [Account synced]
                            │
                            ▼ [3 min]
                        [Trades synced]
                            │
                            ▼ [Connector closes]
                        [Ready to view in TRADIFY]
                            │
                            ▼
                    ✅ Total: 5 minutes
```

---
**For detailed steps, see: `CONNECTOR_QUICK_START.md` or `MT5_CONNECTOR_USER_GUIDE.md`**
