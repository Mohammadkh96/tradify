#!/usr/bin/env python3
"""
TRADIFY MT5 Connector - Desktop Application
Registers with TRADIFY backend using one-time token and syncs MT5 account data.
"""

import json
import sys
import time
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
from datetime import datetime
import threading
import requests
from pathlib import Path

# Configuration
API_BASE = "http://localhost:3000/api/mt5"  # Change to your server URL
CONFIG_FILE = Path.home() / ".tradify_connector.json"

class MT5Connector:
    def __init__(self):
        self.token = None
        self.connection_id = None
        self.config = self.load_config()
        self.account_data = None
        self.trades_data = None
        
    def load_config(self):
        """Load saved configuration."""
        if CONFIG_FILE.exists():
            try:
                with open(CONFIG_FILE, 'r') as f:
                    return json.load(f)
            except:
                return {}
        return {}
    
    def save_config(self):
        """Save configuration to file."""
        with open(CONFIG_FILE, 'w') as f:
            json.dump(self.config, f, indent=2)
    
    def register_connection(self, token, api_url=None):
        """Register with TRADIFY backend using token."""
        if api_url:
            global API_BASE
            API_BASE = api_url
        
        try:
            self.log("🔌 Registering with TRADIFY backend...")
            response = requests.post(
                f"{API_BASE}/register-connection",
                json={"connectionToken": token},
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                self.connection_id = data.get("connectionId")
                self.config["connection_id"] = self.connection_id
                self.config["token_used"] = datetime.now().isoformat()
                self.save_config()
                self.log(f"✅ Registration successful! Connection ID: {self.connection_id}")
                return True
            else:
                error = response.json().get("error", "Unknown error")
                self.log(f"❌ Registration failed: {error}")
                return False
        except Exception as e:
            self.log(f"❌ Registration error: {str(e)}")
            return False
    
    def sync_account_data(self, account_number=None, balance=None, equity=None):
        """Sync MT5 account data with TRADIFY."""
        try:
            if not self.connection_id:
                self.log("❌ Not registered. Please register with token first.")
                return False
            
            self.log("📊 Syncing account data...")
            payload = {
                "connectionId": self.connection_id,
                "accountNumber": account_number or "DEMO123",
                "broker": "MetaTrader 5",
                "balance": balance or 10000.00,
                "equity": equity or 10000.00,
                "currency": "USD"
            }
            
            response = requests.post(
                f"{API_BASE}/sync-account-data/{self.connection_id}",
                json=payload,
                timeout=10
            )
            
            if response.status_code == 200:
                self.account_data = response.json()
                self.log(f"✅ Account synced: {self.account_data}")
                return True
            else:
                error = response.json().get("error", "Unknown error")
                self.log(f"❌ Sync failed: {error}")
                return False
        except Exception as e:
            self.log(f"❌ Sync error: {str(e)}")
            return False
    
    def sync_trades(self, trades=None):
        """Sync trades with TRADIFY."""
        try:
            if not self.connection_id:
                self.log("❌ Not registered. Please register with token first.")
                return False
            
            self.log("📈 Syncing trades...")
            payload = {
                "connectionId": self.connection_id,
                "trades": trades or [
                    {
                        "ticket": 12345,
                        "symbol": "EURUSD",
                        "type": "BUY",
                        "volume": 1.0,
                        "openPrice": 1.0900,
                        "closePrice": 1.0950,
                        "openTime": datetime.now().isoformat(),
                        "profit": 50.00
                    }
                ]
            }
            
            response = requests.post(
                f"{API_BASE}/sync-trades/{self.connection_id}",
                json=payload,
                timeout=10
            )
            
            if response.status_code == 200:
                self.trades_data = response.json()
                self.log(f"✅ Trades synced: {len(payload['trades'])} trades")
                return True
            else:
                error = response.json().get("error", "Unknown error")
                self.log(f"❌ Sync failed: {error}")
                return False
        except Exception as e:
            self.log(f"❌ Sync error: {str(e)}")
            return False
    
    def log(self, message):
        """Print log message (override in GUI)."""
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {message}")


class MT5ConnectorGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("TRADIFY MT5 Connector")
        self.root.geometry("700x600")
        self.root.resizable(True, True)
        
        self.connector = MT5Connector()
        self.connector.log = self.log_message
        
        self.setup_ui()
        self.log_message("🚀 TRADIFY MT5 Connector initialized")
        if self.connector.connection_id:
            self.log_message(f"ℹ️ Existing connection found: {self.connector.connection_id}")
    
    def setup_ui(self):
        """Create GUI elements."""
        # Tab control
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Tab 1: Registration
        self.reg_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.reg_frame, text="Registration")
        self.setup_registration_tab()
        
        # Tab 2: Account Sync
        self.account_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.account_frame, text="Account Sync")
        self.setup_account_tab()
        
        # Tab 3: Trades Sync
        self.trades_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.trades_frame, text="Trades Sync")
        self.setup_trades_tab()
        
        # Tab 4: Logs
        self.logs_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.logs_frame, text="Logs")
        self.setup_logs_tab()
    
    def setup_registration_tab(self):
        """Registration tab UI."""
        frame = ttk.LabelFrame(self.reg_frame, text="Token Registration", padding=15)
        frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # API URL
        ttk.Label(frame, text="API URL:").pack(anchor=tk.W, pady=(0, 5))
        self.api_url_var = tk.StringVar(value="http://localhost:3000/api/mt5")
        api_entry = ttk.Entry(frame, textvariable=self.api_url_var, width=50)
        api_entry.pack(anchor=tk.W, fill=tk.X, pady=(0, 15))
        
        # Token input
        ttk.Label(frame, text="One-Time Token (from TRADIFY app):").pack(anchor=tk.W, pady=(0, 5))
        self.token_var = tk.StringVar()
        token_entry = ttk.Entry(frame, textvariable=self.token_var, width=50, show="*")
        token_entry.pack(anchor=tk.W, fill=tk.X, pady=(0, 15))
        
        # Buttons
        btn_frame = ttk.Frame(frame)
        btn_frame.pack(anchor=tk.W, fill=tk.X, pady=10)
        
        ttk.Button(
            btn_frame,
            text="Register",
            command=self.register_clicked
        ).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            btn_frame,
            text="Clear Saved Token",
            command=self.clear_token
        ).pack(side=tk.LEFT, padx=5)
        
        # Status
        frame2 = ttk.LabelFrame(self.reg_frame, text="Status", padding=10)
        frame2.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.status_var = tk.StringVar(value="Not registered")
        if self.connector.connection_id:
            self.status_var.set(f"✅ Registered - ID: {self.connector.connection_id}")
        
        ttk.Label(frame2, textvariable=self.status_var).pack(anchor=tk.W)
    
    def setup_account_tab(self):
        """Account sync tab UI."""
        frame = ttk.LabelFrame(self.account_frame, text="Account Details", padding=15)
        frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        ttk.Label(frame, text="Account Number:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.account_var = tk.StringVar(value="12345678")
        ttk.Entry(frame, textvariable=self.account_var, width=30).grid(row=0, column=1, sticky=tk.W, padx=10)
        
        ttk.Label(frame, text="Balance (USD):").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.balance_var = tk.StringVar(value="10000.00")
        ttk.Entry(frame, textvariable=self.balance_var, width=30).grid(row=1, column=1, sticky=tk.W, padx=10)
        
        ttk.Label(frame, text="Equity (USD):").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.equity_var = tk.StringVar(value="10000.00")
        ttk.Entry(frame, textvariable=self.equity_var, width=30).grid(row=2, column=1, sticky=tk.W, padx=10)
        
        ttk.Button(
            frame,
            text="Sync Account",
            command=self.sync_account_clicked
        ).grid(row=3, column=0, columnspan=2, pady=20)
    
    def setup_trades_tab(self):
        """Trades sync tab UI."""
        frame = ttk.LabelFrame(self.trades_frame, text="Trades (JSON Format)", padding=15)
        frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        ttk.Label(frame, text="Paste trades JSON array:").pack(anchor=tk.W, pady=(0, 5))
        
        self.trades_text = scrolledtext.ScrolledText(frame, height=15, width=80)
        self.trades_text.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        sample = [
            {
                "ticket": 12345,
                "symbol": "EURUSD",
                "type": "BUY",
                "volume": 1.0,
                "openPrice": 1.0900,
                "closePrice": 1.0950,
                "openTime": datetime.now().isoformat(),
                "profit": 50.00
            }
        ]
        self.trades_text.insert(tk.END, json.dumps(sample, indent=2))
        
        ttk.Button(
            frame,
            text="Sync Trades",
            command=self.sync_trades_clicked
        ).pack(pady=10)
    
    def setup_logs_tab(self):
        """Logs tab UI."""
        frame = ttk.Frame(self.logs_frame, padding=10)
        frame.pack(fill=tk.BOTH, expand=True)
        
        self.logs_text = scrolledtext.ScrolledText(frame, height=25, width=80)
        self.logs_text.pack(fill=tk.BOTH, expand=True)
        
        btn_frame = ttk.Frame(frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        ttk.Button(
            btn_frame,
            text="Clear Logs",
            command=lambda: self.logs_text.delete(1.0, tk.END)
        ).pack(side=tk.LEFT, padx=5)
    
    def log_message(self, message):
        """Add message to logs."""
        timestamp = datetime.now().strftime('%H:%M:%S')
        full_msg = f"[{timestamp}] {message}\n"
        self.logs_text.insert(tk.END, full_msg)
        self.logs_text.see(tk.END)
        self.root.update()
    
    def register_clicked(self):
        """Handle register button."""
        token = self.token_var.get().strip()
        api_url = self.api_url_var.get().strip()
        
        if not token:
            messagebox.showerror("Error", "Please enter the token from TRADIFY app")
            return
        
        def register_thread():
            if self.connector.register_connection(token, api_url):
                self.status_var.set(f"✅ Registered - ID: {self.connector.connection_id}")
                messagebox.showinfo("Success", "Registration successful!")
            else:
                messagebox.showerror("Failed", "Registration failed. Check logs.")
        
        threading.Thread(target=register_thread, daemon=True).start()
    
    def clear_token(self):
        """Clear saved token."""
        self.connector.config.clear()
        self.connector.save_config()
        self.status_var.set("Not registered")
        self.log_message("ℹ️ Saved token cleared")
    
    def sync_account_clicked(self):
        """Handle sync account button."""
        if not self.connector.connection_id:
            messagebox.showerror("Error", "Please register with token first")
            return
        
        account = self.account_var.get()
        balance = float(self.balance_var.get() or 0)
        equity = float(self.equity_var.get() or 0)
        
        def sync_thread():
            self.connector.sync_account_data(account, balance, equity)
        
        threading.Thread(target=sync_thread, daemon=True).start()
    
    def sync_trades_clicked(self):
        """Handle sync trades button."""
        if not self.connector.connection_id:
            messagebox.showerror("Error", "Please register with token first")
            return
        
        try:
            trades = json.loads(self.trades_text.get(1.0, tk.END))
            if not isinstance(trades, list):
                trades = [trades]
        except json.JSONDecodeError:
            messagebox.showerror("Error", "Invalid JSON format")
            return
        
        def sync_thread():
            self.connector.sync_trades(trades)
        
        threading.Thread(target=sync_thread, daemon=True).start()


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "--cli":
        # CLI mode
        connector = MT5Connector()
        
        if len(sys.argv) > 2:
            token = sys.argv[2]
            api_url = sys.argv[3] if len(sys.argv) > 3 else API_BASE
            connector.register_connection(token, api_url)
            connector.sync_account_data()
            connector.sync_trades()
    else:
        # GUI mode
        root = tk.Tk()
        app = MT5ConnectorGUI(root)
        root.mainloop()


if __name__ == "__main__":
    main()
