# TRADIFY MT5 Connector - User Guide

## Overview
The TRADIFY MT5 Connector is a desktop application that connects your MetaTrader 5 account to the TRADIFY trading journal system using a one-time security token.

## Installation

### Prerequisites
- **Python 3.8+** installed on your computer
- **MetaTrader 5** terminal running (for live trading)
- **TRADIFY Web App** account created

### Step 1: Install Python
1. Download Python from https://www.python.org/downloads/
2. Run the installer
3. **IMPORTANT**: Check the box "Add Python to PATH" before clicking Install
4. Click Install

### Step 2: Install Required Packages
Double-click `run-connector.bat` - it will automatically install Python dependencies on first run.

## Usage

### Step 1: Generate Token in TRADIFY App
1. Open TRADIFY web app (http://localhost:3000 or your deployed URL)
2. Log in to your account
3. Go to Dashboard → Click "MT5 Connection" button
4. Enter your MT5 account number
5. Select your broker
6. Click "Generate Connection Token"
7. **Copy the token** (click the copy button next to the token)

### Step 2: Register Connector with Token
1. Double-click `run-connector.bat` to launch the connector
2. GUI window opens with 4 tabs: Registration, Account Sync, Trades Sync, Logs
3. Go to **Registration** tab
4. Paste the token from TRADIFY app into the "One-Time Token" field
5. Verify API URL (should be http://localhost:3000/api/mt5 for local, or your server)
6. Click **Register**
7. ✅ You should see "Registration successful!" message

### Step 3: Sync Account Data
1. Go to **Account Sync** tab
2. Enter your MT5 Account Number (8 digits)
3. Enter your Account Balance (in USD)
4. Enter your Equity (in USD)
5. Click **Sync Account**
6. Check **Logs** tab to verify success

### Step 4: Sync Trades
1. Go to **Trades Sync** tab
2. The default JSON shows a sample trade format
3. Modify or replace with your actual MT5 trades in JSON format
4. Each trade should include:
   - `ticket`: Trade ticket number
   - `symbol`: Currency pair (EURUSD, GBPUSD, etc.)
   - `type`: BUY or SELL
   - `volume`: Lot size
   - `openPrice`: Entry price
   - `closePrice`: Exit price (or current price if still open)
   - `openTime`: Trade open timestamp
   - `profit`: Trade profit/loss in USD
5. Click **Sync Trades**
6. Check **Logs** tab to confirm sync completed

### Step 5: Verify in TRADIFY App
1. Return to TRADIFY web app
2. Go to Dashboard → MT5 Connection
3. Click "Refresh" to see your connection listed
4. Select your connection and click "Refresh Trades"
5. Your MT5 trades should now appear in the Trade Journal

## Command Line Usage

You can also run the connector from command line:

```bash
python tradify_mt5_connector.py --cli YOUR_TOKEN http://localhost:3000/api/mt5
```

## Troubleshooting

### "Python is not installed"
- Ensure Python is installed and added to PATH
- Restart your computer after installing Python
- Try opening Command Prompt and typing `python --version`

### "Connection failed - Invalid token"
- Verify token is copied exactly from TRADIFY app
- Check that your TRADIFY account is logged in
- Tokens expire after ~15 minutes - generate a new one

### "API URL not accessible"
- If using localhost: Ensure TRADIFY server is running (`npm run dev`)
- If using remote server: Check internet connection and firewall
- Verify the API URL is correct (no trailing slash)

### Trades not syncing
- Ensure JSON format is valid (use JSON validator: https://jsonlint.com/)
- Check that all required fields are present
- Make sure connection was registered successfully first

### Security Warnings
The connector uses only:
- **One-time tokens** (expires quickly, valid only once)
- **No MT5 credentials** stored or transmitted
- **Local connection** to TRADIFY server (encrypted HTTPS if remote)

All account data is only sent through the connector to TRADIFY - your MT5 terminal remains isolated.

## File Locations

- **Connector App**: `tradify_mt5_connector.py`
- **Launcher**: `run-connector.bat`
- **Config File**: `~/.tradify_connector.json` (saved connection info)
- **Logs**: Available in Logs tab of connector GUI

## Support

For issues or questions:
1. Check the **Logs** tab in the connector application
2. Verify all steps in "Usage" section above
3. Ensure TRADIFY server is running and API URL is correct
4. Contact TRADIFY support with error messages from logs

## Version
v1.0.0 - January 2026
