#!/usr/bin/env python3
"""
Build script to create standalone connector executable
Usage: python build_connector.py
"""

import os
import sys
import shutil
from pathlib import Path

def build_connector():
    """Build standalone connector executable."""
    try:
        import PyInstaller.__main__
    except ImportError:
        print("❌ PyInstaller not installed")
        print("📦 Installing PyInstaller...")
        os.system(f"{sys.executable} -m pip install PyInstaller -q")
        import PyInstaller.__main__
    
    print("\n🔨 Building TRADIFY MT5 Connector...\n")
    
    # Build parameters
    spec_args = [
        "tradify_mt5_connector.py",
        "--onefile",
        "--windowed",
        "--icon=tradify_icon.ico" if Path("tradify_icon.ico").exists() else "",
        "--add-data=.:.tradify",
        "-n=tradify-connector",
        "--distpath=./dist",
        "--clean",
    ]
    
    # Filter out empty strings
    spec_args = [arg for arg in spec_args if arg]
    
    try:
        PyInstaller.__main__.run(spec_args)
        
        exe_path = Path("dist/tradify-connector.exe")
        if exe_path.exists():
            print(f"\n✅ Build successful!")
            print(f"📦 Executable: {exe_path.absolute()}")
            print(f"📊 Size: {exe_path.stat().st_size / 1024 / 1024:.1f} MB")
            
            # Copy to public/downloads
            downloads_dir = Path("public/downloads")
            downloads_dir.mkdir(parents=True, exist_ok=True)
            
            dest = downloads_dir / "tradify-connector.exe"
            shutil.copy(exe_path, dest)
            print(f"📥 Copied to: {dest.absolute()}")
            print("\n🚀 Ready for distribution!")
            return True
        else:
            print("\n❌ Build failed - executable not created")
            return False
    except Exception as e:
        print(f"\n❌ Build error: {str(e)}")
        return False


if __name__ == "__main__":
    success = build_connector()
    sys.exit(0 if success else 1)
