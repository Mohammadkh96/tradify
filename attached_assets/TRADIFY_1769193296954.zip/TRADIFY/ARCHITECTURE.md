# TRADIFY - Technical Architecture

## System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                          TRADIFY APP                             │
└─────────────────────────────────────────────────────────────────┘

FRONTEND (React + Vite)
┌────────────────────────────────────┐
│      App.tsx (Main Container)      │
│   - Sidebar Navigation (Desktop)   │
│   - Bottom Tab Bar (Mobile)        │
└────────────────────────────────────┘
              │
    ┌─────────┴─────────┬────────────┬────────────┬────────────┐
    │                   │            │            │            │
    ▼                   ▼            ▼            ▼            ▼
┌────────────┐    ┌──────────┐  ┌────────┐  ┌─────────────┐  ┌────────┐
│ Dashboard  │    │ Journal  │  │  New   │  │ Knowledge   │  │ Risk   │
│    Tab     │    │   Tab    │  │ Entry  │  │   Base Tab  │  │ Calc   │
│            │    │          │  │  Tab   │  │             │  │ Tab    │
│ • Metrics  │    │ • Feed   │  │        │  │ • 10        │  │ • Calc │
│ • Charts   │    │ • Cards  │  │• Form  │  │   Modules   │  │• Output│
│ • Stats    │    │ • Filter │  │• HUD   │  │ • Rules     │  │        │
└────────────┘    └──────────┘  └────────┘  └─────────────┘  └────────┘
    │                │              │             │              │
    └────────────────┴──────────────┴─────────────┴──────────────┘
                        │
                        │ React Query
                        │ (API calls)
                        ▼
BACKEND (Express.js)
┌────────────────────────────────────────────────────────────────┐
│                   Express Server (Port 3001)                   │
│                                                                │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │          Route Handlers (REST API)                      │  │
│  │                                                         │  │
│  │  GET /api/trades              (Fetch all trades)       │  │
│  │  GET /api/trades/:id          (Get single trade)       │  │
│  │  POST /api/trades             (Create trade)           │  │
│  │  PUT /api/trades/:id          (Update trade)           │  │
│  │  POST /api/trades/:id/close   (Mark WIN/LOSS)          │  │
│  │  POST /api/trades/validate    (Real-time validation)   │  │
│  │  GET /api/analytics/performance (Get metrics)          │  │
│  │  POST /api/risk/calculate     (Position size calc)     │  │
│  │  GET /api/health              (Health check)           │  │
│  └─────────────────────────────────────────────────────────┘  │
│                        │                                       │
│  ┌────────────────────┴────────────────────┐                  │
│  │                                         │                  │
│  ▼                                         ▼                  │
│  ┌──────────────────────┐    ┌──────────────────────────┐    │
│  │ Rule Validation      │    │ Database Operations      │    │
│  │ Engine               │    │ (Drizzle ORM)            │    │
│  │                      │    │                          │    │
│  │ • validateTrade()    │    │ • db.insert()            │    │
│  │ • checkGR02()        │    │ • db.select()            │    │
│  │ • checkGR03()        │    │ • db.update()            │    │
│  │ • checkGR05()        │    │ • db.delete()            │    │
│  │ • checkGR08()        │    │                          │    │
│  │                      │    │ • calculateMetrics()     │    │
│  └──────────────────────┘    └──────────────────────────┘    │
│                                         │                     │
└────────────────────────────┬────────────┼─────────────────────┘
                             │            │
                             ▼            ▼
SHARED (TypeScript Types & Schemas)
┌────────────────────────────────────────────────────────────────┐
│              Zod Schemas & Enums                               │
│                                                                │
│  • TradeEntrySchema (validation)                              │
│  • GlobalHardRules (rule definitions)                         │
│  • Direction enum (LONG, SHORT)                               │
│  • TradeStatus enum (PENDING, ACTIVE, CLOSED, CANCELLED)      │
│  • MarketStructure enum (BULLISH, BEARISH, NEUTRAL)           │
│  • EntryType enum (RETEST, REVERSAL, BREAKOUT)                │
│  • OutcomeType enum (WIN, LOSS, BREAK_EVEN)                   │
│                                                                │
│  • validateTradeCompliance() → { isValid, violations }         │
│  • calculatePositionSize() → positionSize                      │
│  • calculateRiskRewardRatio() → rrRatio                        │
└────────────────────────────────────────────────────────────────┘
                             │
                             ▼
DATABASE (PostgreSQL)
┌────────────────────────────────────────────────────────────────┐
│                     Database Schema                            │
│                                                                │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │ trade_journal (Main trades table)                       │  │
│  │                                                         │  │
│  │ Columns:                                                │  │
│  │ • id (PRIMARY KEY)                                      │  │
│  │ • asset (VARCHAR)                                       │  │
│  │ • direction (LONG/SHORT)                                │  │
│  │ • htfBias (BULLISH/BEARISH/NEUTRAL)                     │  │
│  │ • entryType (RETEST/REVERSAL/BREAKOUT)                  │  │
│  │ • entryPrice (NUMERIC)                                  │  │
│  │ • stopLoss (NUMERIC)                                    │  │
│  │ • takeProfit (NUMERIC)                                  │  │
│  │ • hasValidZone (BOOLEAN)                                │  │
│  │ • hasLiquiditySweep (BOOLEAN)                           │  │
│  │ • hasObFvgRetest (BOOLEAN)                              │  │
│  │ • status (PENDING/ACTIVE/CLOSED/CANCELLED)              │  │
│  │ • outcome (WIN/LOSS/BREAK_EVEN)                         │  │
│  │ • isRuleCompliant (BOOLEAN)                             │  │
│  │ • violationReasons (JSON TEXT)                          │  │
│  │ • createdAt (TIMESTAMP)                                 │  │
│  │ • updatedAt (TIMESTAMP)                                 │  │
│  └─────────────────────────────────────────────────────────┘  │
│                                                                │
│  ┌─────────────────────────────────────────────────────────┐  │
│  │ user_profile (User settings)                            │  │
│  │                                                         │  │
│  │ • id (PRIMARY KEY)                                      │  │
│  │ • username (VARCHAR UNIQUE)                             │  │
│  │ • tradingCapital (NUMERIC)                              │  │
│  │ • riskPerTrade (NUMERIC)                                │  │
│  │ • createdAt (TIMESTAMP)                                 │  │
│  └─────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────┘
```

---

## Data Flow Diagram

### Creating a Trade (Happy Path)

```
User fills form in New Entry Tab
           │
           ▼
React Hook Form captures input
           │
           ▼
Watch listeners trigger real-time validation
           │
           ▼
Call: POST /api/trades/validate
           │
           ▼
Server: TradeEntrySchema.parse() (Zod validation)
           │
           ▼
Server: validateTradeCompliance() (Check GR-02, GR-03, GR-05, GR-08)
           │
           ▼
Return: { isValid: boolean, violations: string[] }
           │
           ▼
Frontend HUD updates:
- Green if isValid = true
- Red + list violations if isValid = false
           │
           ▼
User clicks Submit (only active if isValid = true)
           │
           ▼
Call: POST /api/trades (with all form data)
           │
           ▼
Server validates again (defense in depth)
           │
           ▼
Server: Insert into trade_journal table
           │
           ▼
Return: { success: true, trade, compliance }
           │
           ▼
Frontend: Invalidate queries (trades, metrics)
           │
           ▼
React Query refetch triggers
           │
           ▼
Dashboard, Journal, Performance Cards update
```

---

## Component Hierarchy

```
App (Main)
├── Sidebar
│   ├── Logo
│   ├── Nav Tabs (5)
│   └── Daily Reminder Card
│
└── Main Content (Tabs)
    ├── DashboardTab
    │   ├── PerformanceCards (6 metric cards + pie chart)
    │   └── Recent Closed Trades (TradeCard list)
    │
    ├── JournalTab
    │   └── TradeCard[] (all trades)
    │
    ├── NewEntryTab
    │   ├── Form Left Column
    │   │   ├── InputField (asset)
    │   │   ├── DirectionButton (LONG/SHORT toggle)
    │   │   ├── HTF Bias selector
    │   │   ├── Entry Type selector
    │   │   ├── InputField (entry price)
    │   │   ├── InputField (stop loss)
    │   │   ├── InputField (take profit)
    │   │   ├── R:R Display
    │   │   ├── RuleToggle[] (3 execution checklist items)
    │   │   ├── Chart upload area
    │   │   ├── Notes textarea
    │   │   └── Submit button
    │   │
    │   └── HUD Right Column
    │       ├── Status indicator (green/red)
    │       └── Violations list or success message
    │
    ├── KnowledgeBaseTab
    │   ├── AccordionItem[] (10 modules)
    │   └── Rules Summary Box
    │
    └── RiskCalculatorTab
        ├── InputField (capital)
        ├── InputField (risk %)
        ├── InputField (SL pips)
        ├── Results boxes (Risk Amount, Position Size)
        └── Quick Reference
```

---

## State Management Flow

```
React Query (Server State)
├── usePerformanceMetrics()
│   └── Fetches: GET /api/analytics/performance
│       └── Displayed in: Dashboard, PerformanceCards
│
├── useTrades()
│   └── Fetches: GET /api/trades
│       └── Displayed in: Journal, Dashboard (recent)
│
├── useValidateTrade()
│   └── Calls: POST /api/trades/validate
│       └── Updates HUD in real-time
│
└── useCreateTrade()
    └── Calls: POST /api/trades
        └── Triggers refetch of usePerformanceMetrics() & useTrades()

React Hook Form (Form State)
├── watch() → Real-time form value monitoring
├── register() → Input binding
├── formState.errors → Error messages
└── setValue() → Programmatic updates

Framer Motion (Animation State)
└── animate, initial, exit → Smooth tab transitions

Local React State
├── activeTab → Current tab
├── sidebarOpen → Desktop sidebar toggle
├── validationState → HUD violations
└── chartFile → Uploaded chart preview
```

---

## Global Hard Rules Implementation

```
GR-02: HTF Bias Alignment
┌─────────────────────────────────┐
│ Check(direction, htfBias)       │
│                                 │
│ if (direction === LONG) {       │
│   if (htfBias !== BULLISH)      │
│     return VIOLATION            │
│ }                               │
│                                 │
│ if (direction === SHORT) {      │
│   if (htfBias !== BEARISH)      │
│     return VIOLATION            │
│ }                               │
│                                 │
│ return VALID                    │
└─────────────────────────────────┘
           │
           └─→ Checked in: NewEntryForm & Server

GR-03: Valid Supply/Demand Zone
┌─────────────────────────────────┐
│ Check(hasValidZone)             │
│                                 │
│ if (!hasValidZone)              │
│   return VIOLATION              │
│                                 │
│ return VALID                    │
└─────────────────────────────────┘
           │
           └─→ Toggle: "Zone" checkbox

GR-05: Entry Confirmation (OB/FVG)
┌─────────────────────────────────┐
│ Check(hasObFvgRetest)           │
│                                 │
│ if (!hasObFvgRetest)            │
│   return VIOLATION              │
│                                 │
│ return VALID                    │
└─────────────────────────────────┘
           │
           └─→ Toggle: "OB/FVG Retest" checkbox

GR-08: Liquidity Sweep
┌─────────────────────────────────┐
│ Check(entryType, hasLiqSwp)     │
│                                 │
│ if (entryType === REVERSAL) {   │
│   if (!hasLiquiditySweep)       │
│     return VIOLATION            │
│ }                               │
│                                 │
│ return VALID                    │
└─────────────────────────────────┘
           │
           └─→ Toggle: "Liquidity Sweep" checkbox
```

---

## Theme & Styling Architecture

```
Colors
├── Backgrounds
│   ├── #020617 (slate-950) - Primary BG
│   ├── #0f172a (slate-900) - Cards
│   └── #1e293b (slate-800) - Elevated
│
├── Sentiments
│   ├── #10b981 (emerald-500) - Bullish/Valid
│   ├── #f43f5e (rose-500) - Bearish/Invalid
│   └── #94a3b8 (slate-400) - Neutral
│
└── Accents
    ├── #f59e0b (amber-500) - Warning
    └── #ec4899 (pink-500) - Secondary

Typography
├── Inter → UI text (buttons, labels)
└── JetBrains Mono → Prices, ratios, data

Components
├── Buttons
│   ├── btn-primary (emerald)
│   ├── btn-secondary (slate)
│   └── btn-danger (rose)
│
├── Cards
│   ├── card-surface
│   └── card-elevated
│
├── Inputs
│   └── input-field
│
├── Animations
│   ├── pulse-red (2s infinite)
│   └── glow-emerald (2s ease-in-out)
│
└── Utilities
    ├── shadow-emerald-glow
    ├── shadow-rose-glow
    └── border-left-4 (accent borders)
```

---

## API Request/Response Flow

### Creating a Trade - Full Sequence

```
REQUEST: POST /api/trades
┌─────────────────────────────────────┐
│ {                                   │
│   "asset": "EURUSD",                │
│   "direction": "LONG",              │
│   "htfBias": "BULLISH",             │
│   "entryType": "RETEST",            │
│   "entryPrice": 1.0900,             │
│   "stopLoss": 1.0880,               │
│   "takeProfit": 1.0930,             │
│   "hasValidZone": true,             │
│   "hasObFvgRetest": true,           │
│   "hasLiquiditySweep": false,       │
│   "chartImageUrl": "data:image...",│
│   "notes": "Breakout from zone..."  │
│ }                                   │
└─────────────────────────────────────┘
           │
           ▼
[Server] Zod.parse() validates schema
           │
           ▼
[Server] validateTradeCompliance() checks all 4 GR
           │
           ▼
RESPONSE: 201 Created
┌─────────────────────────────────────┐
│ {                                   │
│   "success": true,                  │
│   "trade": {                        │
│     "id": 42,                       │
│     "asset": "EURUSD",              │
│     "direction": "LONG",            │
│     ...all fields...                │
│   },                                │
│   "compliance": {                   │
│     "isValid": true,                │
│     "violations": []                │
│   }                                 │
│ }                                   │
└─────────────────────────────────────┘
           │
           ▼
[Frontend] queryClient.invalidateQueries()
           │
           ├─ Refetch: /api/trades
           ├─ Refetch: /api/analytics/performance
           │
           ▼
[Frontend] React Query triggers
           │
           ├─ DashboardTab refetches metrics
           ├─ JournalTab refetches all trades
           │
           ▼
[UI] Updates: Cards, charts, metrics
```

---

## Deployment Architecture

```
Development
├── Frontend: http://localhost:5173 (Vite dev server)
├── Backend: http://localhost:3001 (Express)
└── Database: PostgreSQL local (optional)

Production
├── Frontend
│   ├── Build: npm run build → dist/
│   └── Deploy: Vercel, Netlify, or static server
│
├── Backend
│   ├── Build: npm run build → dist/
│   └── Deploy: Heroku, Railway, AWS, or VPS
│
└── Database
    └── PostgreSQL on managed service (AWS RDS, Heroku, Railway)
```

---

## Security & Validation Layers

```
Frontend Validation (UX)
└── React Hook Form + Zod
    └── Catches basic user errors

Server Validation (Security)
├── Zod Schema parsing
├── Rule engine checks
└── Database constraints

Defense in Depth
├── Frontend validates for UX
├── Server validates for security
└── Database enforces final constraints
```

---

This architecture ensures TRADIFY is scalable, maintainable, and deterministic. All validation happens server-side (secure), with client-side validation for responsiveness (UX).
