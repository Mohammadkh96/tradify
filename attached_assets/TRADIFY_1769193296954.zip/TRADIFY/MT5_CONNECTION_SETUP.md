# 🔌 TRADIFY MT5 Connection Setup Guide

## Overview

This guide walks you through connecting your local MetaTrader 5 (MT5) terminal to the TRADIFY platform. The process is secure, straightforward, and maintains full control of your data.

---

## 🎯 What You Need

### Prerequisites

- **MetaTrader 5** installed on your computer (Windows, Mac, or Linux)
- **Python 3.8 or higher** installed
- **Active MT5 Account** (Demo or Live)
- **Internet Connection**
- **TRADIFY Account** (already logged in)

### System Requirements

| Component | Requirement |
|-----------|-------------|
| OS | Windows 10+ / macOS 10.15+ / Linux (Ubuntu 18.04+) |
| RAM | 512 MB minimum |
| Disk Space | 100 MB |
| Network | Stable internet connection |
| Python | 3.8, 3.9, 3.10, 3.11, 3.12 |

---

## 📋 Step-by-Step Setup

### Step 1: Install Python (if needed)

**Windows:**
1. Go to https://www.python.org/downloads/
2. Download "Python 3.11" (or latest)
3. Run the installer
4. ✅ **Check "Add Python to PATH"** during installation
5. Click "Install Now"

**macOS:**
```bash
# Using Homebrew (recommended)
brew install python3

# Or download from https://www.python.org/downloads/
```

**Linux (Ubuntu):**
```bash
sudo apt update
sudo apt install python3 python3-pip
```

**Verify Installation:**
```bash
python --version
# Should show: Python 3.x.x
```

---

### Step 2: Install Required Python Packages

Open a terminal/command prompt and run:

```bash
pip install MetaTrader5 requests
```

**What this installs:**
- `MetaTrader5`: Python API to connect to your MT5 terminal
- `requests`: HTTP library for communicating with TRADIFY

**Expected output:**
```
Successfully installed MetaTrader5-5.0.x requests-2.31.x
```

---

### Step 3: Get Your Connection Token

1. **Log in to TRADIFY** at http://localhost:3000
2. Go to **Settings → MT5 Connection** (or click "Connect MT5" from dashboard)
3. Click **"Start Setup"**
4. Fill in your details:
   - **MT5 Account Number**: Find in MetaTrader 5 → Tools → Options → Account
   - **Broker**: Select your broker (Exness, Pepperstone, etc.)
5. Click **"Continue"**
6. You'll see a **Connection Token** (valid for 15 minutes)
7. **Copy and save** this token

**Token looks like:** `a4f2e8c9d1b7f3a6e2c5d8b1f4a7c9e2`

---

### Step 4: Download and Run the Connector

**Option A: Automated (Recommended)**

1. Click **"Download Setup Instructions"** in TRADIFY
2. This downloads `tradify_connector_instructions.txt`
3. Follow the instructions in that file

**Option B: Manual Setup**

Create a folder for the connector:
```bash
mkdir tradify-connector
cd tradify-connector
```

Copy the Python connector script into this folder, then run:

```bash
# Windows
python tradify_connector.py --token YOUR_CONNECTION_TOKEN

# macOS / Linux
python3 tradify_connector.py --token YOUR_CONNECTION_TOKEN
```

Replace `YOUR_CONNECTION_TOKEN` with the token from Step 3.

---

### Step 5: First Run - What to Expect

When you run the connector for the first time:

```
2026-01-19 10:30:45,123 | INFO     | ==============================
2026-01-19 10:30:45,234 | INFO     | TRADIFY MT5 CONNECTOR
2026-01-19 10:30:45,345 | INFO     | ==============================
2026-01-19 10:30:45,456 | INFO     | Initializing MetaTrader 5 connection...
2026-01-19 10:30:46,567 | INFO     | ✓ MetaTrader 5 initialized successfully
2026-01-19 10:30:46,678 | INFO     | ✓ Connected to account: 12345678
2026-01-19 10:30:46,789 | INFO     |   Broker: Exness-MT5
2026-01-19 10:30:46,890 | INFO     |   Balance: $5,000.00
2026-01-19 10:30:46,901 | INFO     |   Equity: $5,150.00
2026-01-19 10:30:47,012 | INFO     | ✓ Connection registered: conn_a1b2c3d4e5f6
2026-01-19 10:30:47,123 | INFO     | ✓ Connector ready! Running background sync...
2026-01-19 10:30:47,234 | INFO     |   Press Ctrl+C to stop
2026-01-19 10:30:52,567 | INFO     | ✓ Account data synced
2026-01-19 10:30:57,890 | INFO     | ✓ Synced 3 trades
```

✅ **If you see this, the connector is working!**

---

## ⚙️ Configuration

### Default Settings

| Setting | Default | Purpose |
|---------|---------|---------|
| Sync Interval | 30 seconds | How often account data updates |
| Trade Sync | 60 seconds | How often trades are synced |
| Heartbeat | 5 minutes | Keep-alive signal to TRADIFY |
| Timeout | 10 seconds | HTTP request timeout |

### Custom Configuration

Run with custom sync interval:

```bash
python tradify_connector.py --token YOUR_TOKEN --sync-interval 60
```

Or specify custom TRADIFY API URL:

```bash
python tradify_connector.py --token YOUR_TOKEN --api-url http://192.168.1.100:3002/api/mt5
```

---

## 🔍 Troubleshooting

### ❌ "MT5 initialization failed"

**Problem**: MetaTrader 5 is not running or not installed

**Solution:**
1. **Start MetaTrader 5** on your computer
2. Make sure you're logged into an account
3. Run the connector again

### ❌ "Connection token expired"

**Problem**: More than 15 minutes passed since generating token

**Solution:**
1. Return to TRADIFY Settings → MT5 Connection
2. Click "Start Setup" again to generate a new token
3. Copy the new token and run the connector immediately

### ❌ "Registration failed: 401"

**Problem**: Invalid or expired connection token

**Solution:**
1. Generate a fresh token in TRADIFY
2. Make sure TRADIFY server is running (http://localhost:3002)
3. Run the connector with the new token

### ❌ "ModuleNotFoundError: No module named 'MetaTrader5'"

**Problem**: Python packages not installed

**Solution:**
```bash
pip install MetaTrader5 requests
```

If this fails, try:
```bash
pip install --upgrade MetaTrader5 requests
```

### ❌ "Connection refused"

**Problem**: Can't reach TRADIFY backend

**Solution:**
1. Make sure TRADIFY server is running: `npm run dev`
2. Verify backend is on http://localhost:3002
3. If TRADIFY is on different machine, use `--api-url`:
   ```bash
   python tradify_connector.py --token TOKEN --api-url http://YOUR_IP:3002/api/mt5
   ```

### ❌ "No MT5 account found"

**Problem**: MetaTrader 5 isn't properly initialized

**Solution:**
1. Open MetaTrader 5 directly
2. Wait for it to fully load (30 seconds)
3. Make sure you're logged in (should show account number in top right)
4. Close MetaTrader 5 completely
5. Run the connector again

---

## ✅ Verification Checklist

After setup, verify everything works:

- [ ] Connector shows "✓ MetaTrader 5 initialized successfully"
- [ ] You see your account number: `✓ Connected to account: XXXXXXXX`
- [ ] You see your balance displayed
- [ ] Account data syncs every 30 seconds: `✓ Account data synced`
- [ ] Trades are synced: `✓ Synced X trades`
- [ ] TRADIFY dashboard shows "Connected" status
- [ ] Your account balance appears in the dashboard
- [ ] Your open trades appear in the dashboard

---

## 🔒 Security & Privacy

### What TRADIFY Does NOT Access

❌ Your MT5 password
❌ Your trading platform login
❌ Your broker account credentials
❌ Your personal information beyond what you share

### What the Connector Sends

✅ Account statistics (balance, equity, profit)
✅ Open trade information (symbol, entry price, profit)
✅ Connection status (connected/disconnected)
✅ Your IP address (for logging purposes)

### Data Flow

```
Your Computer
    ↓
MetaTrader 5 Terminal
    ↓
Tradify Connector (Python)
    ↓
TRADIFY Backend (localhost:3002)
    ↓
TRADIFY Dashboard
```

**All data stays on your local network (unless TRADIFY is hosted remotely)**

---

## 🚀 Running in Background

### Windows

**Option 1: Batch File (Recommended)**

Create `start-connector.bat`:
```batch
@echo off
cd path\to\tradify-connector
python tradify_connector.py --token YOUR_TOKEN
pause
```

**Option 2: Task Scheduler**

1. Open Task Scheduler
2. Create Basic Task
3. Set trigger to "At log on"
4. Set action to run the batch file
5. Check "Run with highest privileges"

### macOS / Linux

Create a systemd service file at `~/.config/systemd/user/tradify-connector.service`:

```ini
[Unit]
Description=TRADIFY MT5 Connector
After=network-online.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 /path/to/tradify_connector.py --token YOUR_TOKEN
Restart=on-failure
RestartSec=10

[Install]
WantedBy=default.target
```

Enable and start:
```bash
systemctl --user enable tradify-connector
systemctl --user start tradify-connector
```

Check status:
```bash
systemctl --user status tradify-connector
```

---

## 📊 Monitoring

### Connector Logs

Logs are saved to `tradify_connector.log` in the connector directory.

**View recent logs:**
```bash
# Windows
type tradify_connector.log | tail -50

# macOS / Linux
tail -50 tradify_connector.log

# Follow logs in real-time
tail -f tradify_connector.log
```

### TRADIFY Dashboard

Once connected, check:

1. **Dashboard** → Connection Status shows "✓ Connected"
2. **Account Info** displays your broker and account number
3. **Synced Trades** shows your open MT5 trades
4. **Account Statistics** show real-time balance and equity

---

## 🔄 Disconnecting

### To Stop the Connector

Simply close the terminal/command window or press **Ctrl+C**

```
Shutting down...
✓ MT5 connection closed
```

### To Remove Connection from TRADIFY

1. Log in to TRADIFY
2. Go to Settings → MT5 Connections
3. Click the trash/delete icon next to your connection
4. Confirm disconnection

---

## 📞 Getting Help

### Common Issues

| Issue | Solution |
|-------|----------|
| Connector won't start | Check Python is installed: `python --version` |
| MT5 not connecting | Start MT5 and log in, then run connector |
| Token expired | Generate new token in TRADIFY (valid 15 min) |
| Trades not syncing | Check MT5 has open trades, wait 60 seconds |
| Network error | Verify TRADIFY server is running on :3002 |

### Logs to Check

1. **Connector terminal output** - Shows real-time status
2. **tradify_connector.log** - Detailed error messages
3. **Browser console** - Dashboard errors (F12 in browser)
4. **TRADIFY server logs** - Backend errors

---

## 🎓 What Happens Next

### After Successful Connection

1. ✅ Your MT5 trades appear in TRADIFY dashboard
2. ✅ Account balance syncs every 30 seconds
3. ✅ New trades appear automatically
4. ✅ Closed trades move to history
5. ✅ You can link MT5 trades to your trading journal

### One-Click Trade Linking

When you see a synced MT5 trade:

1. Click the trade in the synced trades list
2. Click "Link to Journal Entry"
3. Select or create a journal entry
4. All metrics auto-populate from MT5

---

## 🚀 Advanced Usage

### Multiple MT5 Accounts

1. Get connection token for each account
2. Run separate connector instances:
   ```bash
   # Terminal 1
   python tradify_connector.py --token TOKEN_1

   # Terminal 2
   python tradify_connector.py --token TOKEN_2
   ```
3. Each will appear as separate connection in TRADIFY

### Custom API Endpoint

If TRADIFY is hosted on different machine:

```bash
python tradify_connector.py \
  --token YOUR_TOKEN \
  --api-url http://192.168.1.100:3002/api/mt5
```

### Sync Interval Tuning

Balance between freshness and network usage:

```bash
# Update every 10 seconds (aggressive)
python tradify_connector.py --token YOUR_TOKEN --sync-interval 10

# Update every 5 minutes (conservative)
python tradify_connector.py --token YOUR_TOKEN --sync-interval 300
```

---

## ✨ Best Practices

1. **Keep Connector Running**: Start it in background for continuous syncing
2. **Monitor Logs**: Regularly check for errors or disconnections
3. **Backup Token**: Save connection tokens securely
4. **Network Stability**: Run on stable internet connection
5. **MT5 Updates**: Keep MetaTrader 5 updated to latest version
6. **Python Updates**: Keep Python packages updated with `pip install --upgrade MetaTrader5`

---

## 📝 Example Setup Scenario

### User: Jane (Exness Live Account)

```
1. Jane logs in to TRADIFY
2. Clicks "Connect MT5" on dashboard
3. Enters account number: 12345678
4. Selects broker: Exness
5. Gets token: a4f2e8c9d1b7f3a6e2c5d8b1f4a7c9e2
6. Downloads instructions
7. Opens terminal and runs:
   python tradify_connector.py --token a4f2e8c9d1b7f3a6e2c5d8b1f4a7c9e2
8. Sees "✓ Connection registered"
9. Returns to TRADIFY
10. Dashboard now shows:
    - ✓ Connection: Connected
    - Account: 12345678 (Exness)
    - Balance: $5,000.00
    - Equity: $5,150.00
    - Open Trades: 3
11. Her EURUSD, GBPUSD, and GBPJPY trades appear in the trades list
12. She can click any trade to link it to her journal
```

---

## 🎉 You're All Set!

Your MT5 terminal is now connected to TRADIFY. All your trades will sync automatically, and you can focus on trading with the discipline and risk management tools TRADIFY provides.

**Happy Trading! 📈**

---

## 📚 Additional Resources

- [MetaTrader 5 Official Documentation](https://www.metatrader5.com/)
- [TRADIFY Dashboard Guide](./DASHBOARD.md)
- [Trading Journal Setup](./JOURNAL.md)
- [Risk Calculator](./RISK_CALCULATOR.md)

---

**Last Updated:** January 19, 2026  
**Connector Version:** 1.0.0  
**Python Support:** 3.8 - 3.12
