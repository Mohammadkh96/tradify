# 🚀 TRADIFY MT5 Connector - Quick Start

## What is this?
The **TRADIFY MT5 Connector** is a desktop app that connects your MetaTrader 5 account to TRADIFY using a secure one-time token. It syncs your trades, account balance, and equity.

## Download & Install (30 seconds)

### 1. Download Python
- Go to https://www.python.org/downloads/
- Download Python 3.9+
- **Important**: Check "Add Python to PATH" during install
- Restart your computer

### 2. Run Connector
- Double-click `run-connector.bat` in your TRADIFY folder
- A window will open automatically

## How to Connect (2 minutes)

### In TRADIFY Web App:
1. Click **"MT5 Connection"** button (on Dashboard)
2. Enter your **MT5 Account Number**
3. Select your **Broker** name
4. Click **"Generate Connection Token"**
5. **Copy the token** (click copy icon)

### In Connector App:
1. **Registration** tab → Paste token
2. Click **Register**
3. ✅ You'll see "Registration successful!"

## Sync Your Data (1 minute)

### Account Data:
1. **Account Sync** tab
2. Enter your account number, balance, equity
3. Click **Sync Account**

### Trades:
1. **Trades Sync** tab
2. Copy your MT5 trades as JSON (or use sample)
3. Click **Sync Trades**

## Verify in TRADIFY:
- Dashboard → MT5 Connection
- Click **Refresh** → Your connection appears
- Select it → Click "Refresh Trades" → Trades sync automatically

## ✨ That's It!
Your MT5 account is now synced to TRADIFY. The connector runs in the background and can be reopened anytime.

## Troubleshooting

| Problem | Solution |
|---------|----------|
| "Python not found" | Reinstall Python with "Add to PATH" checked; restart computer |
| Token not working | Generate a new token in TRADIFY app (tokens expire in ~15 mins) |
| Connection failed | Make sure TRADIFY server is running (`npm run dev`) |
| Trades not syncing | Check JSON format is valid; ensure account is synced first |

## Security
✅ One-time tokens (expire quickly)  
✅ No MT5 passwords stored  
✅ Encrypted connection to server  
✅ Local data only sent during sync  

## Support
- Check **Logs** tab in connector for detailed errors
- Ensure TRADIFY server is running
- Verify API URL is correct (localhost for dev, your server for production)

---
**Version 1.0 | TRADIFY © 2026**
