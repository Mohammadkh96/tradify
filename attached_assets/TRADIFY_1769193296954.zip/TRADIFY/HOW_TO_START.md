# 🚀 How to Start TRADIFY - Step by Step

## The Problem
You're seeing "ERR_CONNECTION_REFUSED" because the dev server isn't running yet.

## Solution: Start the Dev Server

### Method 1: Double-Click Batch File (Easiest)
1. Navigate to the TRADIFY folder in File Explorer
2. Double-click `start-dev.bat`
3. Wait for both servers to start (you'll see output in the window)
4. Open browser to: **http://localhost:3000**

### Method 2: PowerShell Command
1. Open PowerShell in the TRADIFY folder
2. Run:
```powershell
npm.cmd run dev
```
3. Wait for servers to start
4. Open browser to: **http://localhost:3000**

### Method 3: Command Prompt
1. Open Command Prompt (cmd.exe) in the TRADIFY folder
2. Run:
```cmd
npm run dev
```
3. Wait for servers to start
4. Open browser to: **http://localhost:3000**

## What You Should See

When servers start successfully:

**Backend Output:**
```
🚀 TRADIFY Server running on http://localhost:3002
📊 API docs available at http://localhost:3002/api
```

**Frontend Output:**
```
  VITE v5.x.x  ready in xxx ms

  ➜  Local:   http://localhost:3000/
```

## Verify It's Working

1. **Check Backend:** Open http://localhost:3002/api/health
   - Should show: `{"status":"ok","timestamp":"...","version":"1.0.0","mode":"read-only"}`

2. **Check Frontend:** Open http://localhost:3000
   - Should show the TRADIFY dashboard

## Important Notes

- **Keep the terminal window open** - Closing it stops the servers
- **Wait 10-15 seconds** after starting for servers to fully initialize
- **Don't close the terminal** while using the app

## If Ports Are Already in Use

If you see "port already in use" errors:

1. Find what's using the port:
```powershell
netstat -ano | findstr ":3000"
netstat -ano | findstr ":3002"
```

2. Kill the process (replace PID):
```powershell
taskkill /PID <PID> /F
```

3. Or restart your computer

## Still Not Working?

1. Make sure you're in the TRADIFY folder
2. Make sure Node.js is installed: `node --version` (should show 18+)
3. Install dependencies: `npm install`
4. Check `TROUBLESHOOTING.md` for more help

---

**Remember:** The servers must be running for the app to work. Keep the terminal window open!
