# TRADIFY Development Server Startup Script
# This script bypasses PowerShell execution policy issues

Write-Host "🚀 Starting TRADIFY Development Server..." -ForegroundColor Green
Write-Host ""

# Use npm.cmd to bypass PowerShell script execution issues
& npm.cmd run dev
