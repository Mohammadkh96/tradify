import { Plus, AlertCircle, TrendingUp, TrendingDown } from 'lucide-react'

interface Trade {
  id: number
  asset: string
  direction: 'LONG' | 'SHORT'
  entryPrice: number
  stopLoss: number
  takeProfit: number
  outcome?: 'WIN' | 'LOSS' | 'BREAK_EVEN'
  pnl?: number
  riskReward?: number
}

const mockTrades: Trade[] = [
  {
    id: 1,
    asset: 'EURUSD',
    direction: 'LONG',
    entryPrice: 1.0900,
    stopLoss: 1.0880,
    takeProfit: 1.0930,
    outcome: 'WIN',
    pnl: 150,
    riskReward: 2.5,
  }
]

export default function JournalTab() {
  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-emerald-400">Trade Journal</h1>
        <span className="text-sm text-slate-400">{mockTrades.length} trade(s)</span>
      </div>

      {mockTrades.length === 0 ? (
        <div className="bg-slate-900 border-2 border-dashed border-slate-700 rounded-xl p-12 text-center">
          <AlertCircle className="w-12 h-12 text-slate-500 mx-auto mb-4" />
          <p className="text-slate-400 text-lg mb-2">No trades yet</p>
          <p className="text-slate-500 text-sm">Start by creating your first trade in the "New Entry" tab</p>
        </div>
      ) : (
        <div className="space-y-4">
          {mockTrades.map(trade => (
            <div 
              key={trade.id}
              className={`border-l-4 ${trade.outcome === 'WIN' ? 'border-l-emerald-500 bg-emerald-500/5' : 'border-l-rose-500 bg-rose-500/5'} bg-slate-900 border border-slate-800 rounded-lg p-6 hover:border-slate-700 transition`}
            >
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <p className="text-slate-400 text-xs font-medium mb-1">ASSET</p>
                  <p className="text-xl font-bold text-white">{trade.asset}</p>
                </div>
                <div>
                  <p className="text-slate-400 text-xs font-medium mb-1">DIRECTION</p>
                  <div className="flex items-center gap-2">
                    {trade.direction === 'LONG' ? (
                      <>
                        <TrendingUp className="w-5 h-5 text-emerald-500" />
                        <span className="font-bold text-emerald-500">LONG</span>
                      </>
                    ) : (
                      <>
                        <TrendingDown className="w-5 h-5 text-rose-500" />
                        <span className="font-bold text-rose-500">SHORT</span>
                      </>
                    )}
                  </div>
                </div>
                <div>
                  <p className="text-slate-400 text-xs font-medium mb-1">PRICES</p>
                  <div className="space-y-1 font-mono text-sm">
                    <p className="text-emerald-400">Entry: {trade.entryPrice}</p>
                    <p className="text-rose-400">SL: {trade.stopLoss}</p>
                    <p className="text-cyan-400">TP: {trade.takeProfit}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-slate-400 text-xs font-medium mb-1">RESULT</p>
                  <div>
                    <p className={`text-lg font-bold font-mono ${trade.outcome === 'WIN' ? 'text-emerald-500' : 'text-rose-500'}`}>
                      {trade.outcome}
                    </p>
                    {trade.pnl && <p className={`text-sm ${trade.pnl > 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      ${trade.pnl.toFixed(0)}
                    </p>}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
