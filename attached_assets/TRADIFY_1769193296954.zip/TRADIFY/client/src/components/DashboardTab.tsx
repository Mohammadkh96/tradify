import { useQuery } from '@tanstack/react-query'
import { TrendingUp, TrendingDown, Target, Award, DollarSign, PieChart } from 'lucide-react'
import { BarChart, Bar, PieChart as RechartsChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

interface PerformanceMetrics {
  winRate: number
  profitFactor: number
  avgRR: number
  totalProfit: number
  totalTrades: number
  compliantTrades: number
}

export default function DashboardTab() {
  const { data: metrics } = useQuery({
    queryKey: ['analytics', 'performance'],
    queryFn: async () => {
      const res = await fetch('/api/analytics/performance')
      if (!res.ok) throw new Error('Failed to fetch metrics')
      return res.json()
    }
  })

  const chartData = [
    { name: 'Win', value: Math.round(metrics?.winRate || 0) },
    { name: 'Loss', value: Math.max(0, Math.round(100 - (metrics?.winRate || 0))) },
  ]

  const COLORS = ['#10b981', '#f43f5e']

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">Dashboard</h1>
        <div className="text-xs text-slate-400">
          Updated • {new Date().toLocaleTimeString()}
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <MetricCard
          icon={<Award className="w-8 h-8 text-emerald-500" />}
          label="Win Rate"
          value={`${Math.round(metrics?.winRate || 0)}%`}
          subtext={`${metrics?.totalTrades || 0} total trades`}
          trend={metrics?.winRate > 50 ? 'up' : 'down'}
        />
        <MetricCard
          icon={<Target className="w-8 h-8 text-cyan-500" />}
          label="Profit Factor"
          value={`${(metrics?.profitFactor || 0).toFixed(2)}x`}
          subtext="Wins / Losses ratio"
          trend={metrics?.profitFactor > 1.5 ? 'up' : 'neutral'}
        />
        <MetricCard
          icon={<TrendingUp className="w-8 h-8 text-purple-500" />}
          label="Avg Risk:Reward"
          value={`1:${(metrics?.avgRR || 0).toFixed(2)}`}
          subtext="Risk per trade"
        />
        <MetricCard
          icon={<DollarSign className="w-8 h-8 text-emerald-500" />}
          label="Total P&L"
          value={`$${(metrics?.totalProfit || 0).toFixed(2)}`}
          subtext="Account return"
          trend={(metrics?.totalProfit || 0) > 0 ? 'up' : 'down'}
        />
        <MetricCard
          icon={<PieChart className="w-8 h-8 text-amber-500" />}
          label="Compliant"
          value={`${Math.round(metrics?.compliantTrades || 0)}%`}
          subtext="Rule-compliant trades"
          trend={metrics?.compliantTrades > 80 ? 'up' : 'neutral'}
        />
        <MetricCard
          icon={<TrendingDown className="w-8 h-8 text-rose-500" />}
          label="Max Drawdown"
          value="12.5%"
          subtext="Peak-to-trough decline"
        />
      </div>

      {/* Charts */}
      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-6">
          <h2 className="text-lg font-semibold mb-4 text-emerald-400">Trade Distribution</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="name" stroke="#94a3b8" />
              <YAxis stroke="#94a3b8" />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }}
                labelStyle={{ color: '#e2e8f0' }}
              />
              <Bar dataKey="value" fill="#10b981" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <h2 className="text-lg font-semibold mb-4 text-emerald-400">Win/Loss Ratio</h2>
          <ResponsiveContainer width="100%" height={300}>
            <RechartsChart>
              <Pie data={chartData} cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={5} dataKey="value">
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
            </RechartsChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
        <h2 className="text-lg font-semibold mb-4 text-emerald-400">Recent Trades</h2>
        <div className="text-slate-400 text-center py-8">
          No trades yet. Create your first trade in the "New Entry" tab.
        </div>
      </div>
    </div>
  )
}

function MetricCard({ icon, label, value, subtext, trend }: {
  icon: React.ReactNode
  label: string
  value: string
  subtext: string
  trend?: 'up' | 'down' | 'neutral'
}) {
  return (
    <div className="bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 hover:border-emerald-500/50 rounded-xl p-6 transition">
      <div className="flex items-center justify-between mb-4">
        <div>{icon}</div>
        {trend && (
          <div className={`text-sm font-medium ${
            trend === 'up' ? 'text-emerald-500' : trend === 'down' ? 'text-rose-500' : 'text-slate-500'
          }`}>
            {trend === 'up' ? '↑' : trend === 'down' ? '↓' : '→'}
          </div>
        )}
      </div>
      <p className="text-slate-400 text-sm mb-1 font-medium">{label}</p>
      <p className="text-3xl font-bold font-mono text-white mb-2">{value}</p>
      <p className="text-xs text-slate-500">{subtext}</p>
    </div>
  )
}
