import { useState } from 'react'
import { PlusCircle, TrendingUp, TrendingDown } from 'lucide-react'

export default function NewEntryTab() {
  const [asset, setAsset] = useState('')
  const [direction, setDirection] = useState<'LONG' | 'SHORT'>('LONG')
  const [htfBias, setHtfBias] = useState<'BULLISH' | 'BEARISH'>('BULLISH')
  const [entryType, setEntryType] = useState<'RETEST' | 'REVERSAL' | 'BREAKOUT'>('RETEST')
  const [entryPrice, setEntryPrice] = useState('')
  const [stopLoss, setStopLoss] = useState('')
  const [takeProfit, setTakeProfit] = useState('')
  const [hasValidZone, setHasValidZone] = useState(false)
  const [hasObFvgRetest, setHasObFvgRetest] = useState(false)
  const [hasLiquiditySweep, setHasLiquiditySweep] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    const trade = {
      asset,
      direction,
      htfBias,
      entryType,
      entryPrice: parseFloat(entryPrice),
      stopLoss: parseFloat(stopLoss),
      takeProfit: parseFloat(takeProfit),
      hasValidZone,
      hasLiquiditySweep,
      hasObFvgRetest,
      status: 'PENDING',
    }

    setSubmitting(true)
    setError('')

    try {
      const res = await fetch('/api/trades', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(trade),
      })

      if (!res.ok) {
        const body = await res.json().catch(() => ({}))
        const message = body?.error?.message || body?.error || 'Failed to create trade'
        throw new Error(message)
      }

      alert('Trade created successfully!')
      setAsset('')
      setEntryPrice('')
      setStopLoss('')
      setTakeProfit('')
      setHasValidZone(false)
      setHasObFvgRetest(false)
      setHasLiquiditySweep(false)
      setEntryType('RETEST')
      setDirection('LONG')
      setHtfBias('BULLISH')
    } catch (err) {
      console.error('Error creating trade:', err)
      setError(err instanceof Error ? err.message : 'Error creating trade')
    } finally {
      setSubmitting(false)
    }
  }

  const rr = entryPrice && stopLoss && takeProfit
    ? ((parseFloat(takeProfit) - parseFloat(entryPrice)) / (parseFloat(entryPrice) - parseFloat(stopLoss))).toFixed(2)
    : '—'

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center gap-3 mb-8">
        <PlusCircle className="w-8 h-8 text-emerald-500" />
        <h1 className="text-3xl font-bold">New Trade Entry</h1>
      </div>

      <form onSubmit={handleSubmit} className="bg-slate-900 border border-slate-800 rounded-lg p-8">
        {/* Asset */}
        <div className="mb-6">
          <label className="block text-slate-300 mb-2 font-medium">Asset / Symbol</label>
          <input
            type="text"
            value={asset}
            onChange={(e) => setAsset(e.target.value)}
            placeholder="e.g., EURUSD, GBPUSD"
            className="w-full px-4 py-3 bg-slate-950 border border-slate-700 rounded-lg text-white focus:border-emerald-500 focus:outline-none"
            required
          />
        </div>

        {/* Direction & Bias */}
        <div className="grid md:grid-cols-2 gap-6 mb-6">
          <div>
            <label className="block text-slate-300 mb-2 font-medium">Direction</label>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setDirection('LONG')}
                className={`flex-1 py-3 rounded-lg font-semibold flex items-center justify-center gap-2 transition ${
                  direction === 'LONG'
                    ? 'bg-emerald-500 text-white'
                    : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                }`}
              >
                <TrendingUp className="w-5 h-5" />
                LONG
              </button>
              <button
                type="button"
                onClick={() => setDirection('SHORT')}
                className={`flex-1 py-3 rounded-lg font-semibold flex items-center justify-center gap-2 transition ${
                  direction === 'SHORT'
                    ? 'bg-rose-500 text-white'
                    : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                }`}
              >
                <TrendingDown className="w-5 h-5" />
                SHORT
              </button>
            </div>
          </div>

          <div>
            <label className="block text-slate-300 mb-2 font-medium">HTF Bias</label>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setHtfBias('BULLISH')}
                className={`flex-1 py-3 rounded-lg font-semibold transition ${
                  htfBias === 'BULLISH'
                    ? 'bg-emerald-500 text-white'
                    : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                }`}
              >
                BULLISH
              </button>
              <button
                type="button"
                onClick={() => setHtfBias('BEARISH')}
                className={`flex-1 py-3 rounded-lg font-semibold transition ${
                  htfBias === 'BEARISH'
                    ? 'bg-rose-500 text-white'
                    : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                }`}
              >
                BEARISH
              </button>
            </div>
          </div>
        </div>

        {/* Entry Type */}
        <div className="mb-6">
          <label className="block text-slate-300 mb-2 font-medium">Entry Type</label>
          <div className="flex gap-2">
            {(['RETEST', 'REVERSAL', 'BREAKOUT'] as const).map(option => (
              <button
                key={option}
                type="button"
                onClick={() => setEntryType(option)}
                className={`flex-1 py-3 rounded-lg font-semibold transition ${
                  entryType === option
                    ? 'bg-cyan-500 text-white'
                    : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                }`}
              >
                {option}
              </button>
            ))}
          </div>
        </div>

        {/* Prices */}
        <div className="grid md:grid-cols-3 gap-6 mb-6">
          <div>
            <label className="block text-slate-300 mb-2 font-medium">Entry Price</label>
            <input
              type="number"
              step="0.00001"
              value={entryPrice}
              onChange={(e) => setEntryPrice(e.target.value)}
              className="w-full px-4 py-3 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono focus:border-emerald-500 focus:outline-none"
              required
            />
          </div>
          <div>
            <label className="block text-slate-300 mb-2 font-medium">Stop Loss</label>
            <input
              type="number"
              step="0.00001"
              value={stopLoss}
              onChange={(e) => setStopLoss(e.target.value)}
              className="w-full px-4 py-3 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono focus:border-rose-500 focus:outline-none"
              required
            />
          </div>
          <div>
            <label className="block text-slate-300 mb-2 font-medium">Take Profit</label>
            <input
              type="number"
              step="0.00001"
              value={takeProfit}
              onChange={(e) => setTakeProfit(e.target.value)}
              className="w-full px-4 py-3 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono focus:border-emerald-500 focus:outline-none"
              required
            />
          </div>
        </div>

        {/* Rule Toggles */}
        <div className="grid md:grid-cols-3 gap-4 mb-6">
          <Toggle
            label="Valid Supply/Demand Zone (GR-03)"
            value={hasValidZone}
            onChange={setHasValidZone}
          />
          <Toggle
            label="OB/FVG Retest Confirmed (GR-05)"
            value={hasObFvgRetest}
            onChange={setHasObFvgRetest}
          />
          <Toggle
            label="Liquidity Sweep Happened (GR-08)"
            value={hasLiquiditySweep}
            onChange={setHasLiquiditySweep}
          />
        </div>

        {/* R:R Display */}
        <div className="mb-6 p-4 bg-slate-950 border border-slate-700 rounded-lg">
          <p className="text-slate-400 text-sm mb-1">Risk:Reward Ratio</p>
          <p className="text-2xl font-bold font-mono text-emerald-500">1:{rr}</p>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-rose-500/10 border border-rose-500/50 rounded text-rose-400 text-sm">
            {error}
          </div>
        )}

        {/* Submit */}
        <button
          type="submit"
          disabled={submitting}
          className="w-full py-4 bg-emerald-500 hover:bg-emerald-600 disabled:bg-slate-700 disabled:cursor-not-allowed rounded-lg text-white font-semibold text-lg transition glow-green"
        >
          {submitting ? 'Creating...' : 'Create Trade'}
        </button>
      </form>
    </div>
  )
}

function Toggle({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!value)}
      className={`w-full text-left p-4 rounded-lg border transition ${
        value
          ? 'bg-emerald-500/10 border-emerald-500/60 text-emerald-200'
          : 'bg-slate-900 border-slate-700 text-slate-300 hover:border-slate-600'
      }`}
    >
      <div className="flex items-center justify-between">
        <span className="font-semibold text-sm">{label}</span>
        <span className={`px-2 py-1 text-xs font-semibold rounded ${
          value ? 'bg-emerald-600 text-white' : 'bg-slate-700 text-slate-200'
        }`}>
          {value ? 'Yes' : 'No'}
        </span>
      </div>
    </button>
  )
}
