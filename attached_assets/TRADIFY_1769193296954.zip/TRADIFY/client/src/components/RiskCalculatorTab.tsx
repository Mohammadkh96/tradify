import { useState } from 'react'
import { Calculator } from 'lucide-react'

export default function RiskCalculatorTab() {
  const [accountBalance, setAccountBalance] = useState('')
  const [riskPercent, setRiskPercent] = useState('1')
  const [entryPrice, setEntryPrice] = useState('')
  const [stopLoss, setStopLoss] = useState('')

  const calculatePositionSize = () => {
    if (!accountBalance || !entryPrice || !stopLoss) return '—'
    
    const balance = parseFloat(accountBalance)
    const risk = parseFloat(riskPercent)
    const entry = parseFloat(entryPrice)
    const sl = parseFloat(stopLoss)
    
    const riskAmount = balance * (risk / 100)
    const pipRisk = Math.abs(entry - sl)
    
    if (pipRisk === 0) return '—'
    
    const positionSize = riskAmount / pipRisk
    return positionSize.toFixed(2)
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center gap-3 mb-8">
        <Calculator className="w-8 h-8 text-emerald-500" />
        <h1 className="text-3xl font-bold">Risk Calculator</h1>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-lg p-8">
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div>
            <label className="block text-slate-300 mb-2 font-medium">Account Balance ($)</label>
            <input
              type="number"
              value={accountBalance}
              onChange={(e) => setAccountBalance(e.target.value)}
              placeholder="10000"
              className="w-full px-4 py-3 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono focus:border-emerald-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-slate-300 mb-2 font-medium">Risk Per Trade (%)</label>
            <input
              type="number"
              value={riskPercent}
              onChange={(e) => setRiskPercent(e.target.value)}
              placeholder="1"
              step="0.1"
              className="w-full px-4 py-3 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono focus:border-emerald-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-slate-300 mb-2 font-medium">Entry Price</label>
            <input
              type="number"
              value={entryPrice}
              onChange={(e) => setEntryPrice(e.target.value)}
              placeholder="1.0900"
              step="0.00001"
              className="w-full px-4 py-3 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono focus:border-emerald-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-slate-300 mb-2 font-medium">Stop Loss</label>
            <input
              type="number"
              value={stopLoss}
              onChange={(e) => setStopLoss(e.target.value)}
              placeholder="1.0880"
              step="0.00001"
              className="w-full px-4 py-3 bg-slate-950 border border-slate-700 rounded-lg text-white font-mono focus:border-rose-500 focus:outline-none"
            />
          </div>
        </div>

        <div className="p-6 bg-slate-950 border border-emerald-500/50 rounded-lg">
          <p className="text-slate-400 mb-2">Recommended Position Size</p>
          <p className="text-4xl font-bold font-mono text-emerald-500">{calculatePositionSize()} lots</p>
        </div>
      </div>
    </div>
  )
}
