import { Database } from 'lucide-react'

export default function KnowledgeBaseTab() {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center gap-3 mb-8">
        <Database className="w-8 h-8 text-emerald-500" />
        <h1 className="text-3xl font-bold">Knowledge Base</h1>
      </div>

      <div className="space-y-4">
        <RuleCard
          title="GR-02: HTF Bias Alignment"
          description="Your trade direction must align with the Higher Timeframe (HTF) market bias."
          status="active"
        />
        <RuleCard
          title="GR-03: Valid Supply/Demand Zone"
          description="Entry must be from a confirmed supply or demand zone on the chart."
          status="active"
        />
        <RuleCard
          title="GR-05: Entry Confirmation Required"
          description="Wait for entry confirmation signal before executing the trade."
          status="active"
        />
        <RuleCard
          title="GR-08: Liquidity Sweep Prerequisite"
          description="Prefer entries after liquidity has been swept from key levels."
          status="active"
        />
      </div>
    </div>
  )
}

function RuleCard({ title, description, status }: { title: string; description: string; status: string }) {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg p-6">
      <div className="flex items-start justify-between mb-2">
        <h3 className="text-lg font-semibold text-emerald-500">{title}</h3>
        <span className="px-3 py-1 bg-emerald-500/10 text-emerald-500 text-xs font-medium rounded-full border border-emerald-500/50">
          {status}
        </span>
      </div>
      <p className="text-slate-400">{description}</p>
    </div>
  )
}
