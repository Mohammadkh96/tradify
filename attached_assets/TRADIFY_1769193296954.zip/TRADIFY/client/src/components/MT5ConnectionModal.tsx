import { Network, RefreshCw, Clock3, Link2, Lock, Copy, Check } from 'lucide-react'
import { useState } from 'react'
import { useAuth } from '../context/AuthContext'

export default function MT5ConnectionModal({ onClose }: { onClose: () => void }) {
  const { user } = useAuth()
  const DOWNLOAD_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3002'
  const [accountNumber, setAccountNumber] = useState('')
  const [broker, setBroker] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [token, setToken] = useState<string | null>(null)
  const [expiresIn, setExpiresIn] = useState<number | null>(null)
  const [connections, setConnections] = useState<any[]>([])
  const [selectedConnection, setSelectedConnection] = useState<any | null>(null)
  const [trades, setTrades] = useState<any[] | null>(null)
  const [copied, setCopied] = useState(false)

  const generateToken = async () => {
    if (!user?.id) {
      setError('You must be logged in to generate a token.')
      return
    }
    setLoading(true)
    setError('')
    try {
      const res = await fetch('/api/mt5/initiate-connection', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, accountNumber, broker }),
      })

      if (!res.ok) {
        const data = await res.json().catch(() => ({}))
        throw new Error(data.error || 'Failed to generate token')
      }

      const data = await res.json()
      setToken(data.connectionToken)
      setExpiresIn(data.expiresIn)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate token')
    } finally {
      setLoading(false)
    }
  }

  const refreshConnections = async () => {
    if (!user?.id) return
    setLoading(true)
    setError('')
    try {
      const res = await fetch(`/api/mt5/connections/${user.id}`)
      if (!res.ok) {
        const data = await res.json().catch(() => ({}))
        throw new Error(data.error || 'Failed to load connections')
      }
      const data = await res.json()
      setConnections(data.connections || [])
      setSelectedConnection((data.connections || [])[0] || null)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load connections')
    } finally {
      setLoading(false)
    }
  }

  const loadTrades = async (connectionId: string) => {
    setLoading(true)
    setError('')
    try {
      const res = await fetch(`/api/mt5/trades/${connectionId}`)
      if (!res.ok) {
        const data = await res.json().catch(() => ({}))
        throw new Error(data.error || 'Failed to load trades')
      }
      const data = await res.json()
      setTrades(data.trades || [])
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load trades')
    } finally {
      setLoading(false)
    }
  }

  const copyToken = async () => {
    if (!token) return
    try {
      await navigator.clipboard.writeText(token)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error('Failed to copy:', err)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-xl shadow-2xl max-w-2xl w-full p-8 relative">
        <div className="flex items-center gap-3 mb-6">
          <Network className="w-8 h-8 text-cyan-500" />
          <div>
            <h2 className="text-2xl font-bold">MT5 Connector (Token)</h2>
            <p className="text-slate-400 text-sm">Generate a one-time token, paste it in the desktop connector, then refresh status.</p>
          </div>
        </div>

        {error && (
          <div className="p-3 mb-4 bg-rose-500/10 border border-rose-500/50 rounded-lg text-sm text-rose-400">
            {error}
          </div>
        )}

        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Account Number</label>
              <input
                type="text"
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value)}
                placeholder="e.g., 12345678"
                className="w-full px-4 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white focus:border-cyan-500 focus:outline-none"
                disabled={loading}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Broker / Server</label>
              <input
                type="text"
                value={broker}
                onChange={(e) => setBroker(e.target.value)}
                placeholder="e.g., Exness-MT5"
                className="w-full px-4 py-2 bg-slate-950 border border-slate-700 rounded-lg text-white focus:border-cyan-500 focus:outline-none"
                disabled={loading}
              />
            </div>

            <button
              onClick={generateToken}
              disabled={loading || !accountNumber || !broker}
              className="w-full py-2 bg-cyan-500 hover:bg-cyan-600 disabled:bg-slate-700 disabled:cursor-not-allowed rounded-lg font-semibold transition"
            >
              {loading ? 'Working...' : 'Generate Connection Token'}
            </button>

            {token && (
              <div className="p-4 bg-slate-800/80 border border-cyan-500/40 rounded-lg text-sm text-slate-200 space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-semibold text-cyan-300">One-Time Token</span>
                  {expiresIn && (
                    <span className="flex items-center gap-1 text-xs text-slate-400">
                      <Clock3 className="w-4 h-4" />
                      Expires in ~{Math.round(expiresIn / 60)} min
                    </span>
                  )}
                </div>
                <div className="flex gap-2 items-center">
                  <div className="flex-1 font-mono break-all text-sm bg-slate-900 border border-slate-700 rounded p-2">{token}</div>
                  <button
                    onClick={copyToken}
                    className="flex items-center justify-center px-3 py-2 bg-slate-700 hover:bg-slate-600 rounded transition whitespace-nowrap"
                    title="Copy token"
                  >
                    {copied ? (
                      <Check className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <Copy className="w-4 h-4 text-slate-300" />
                    )}
                  </button>
                </div>
                <p className="text-xs text-slate-400">
                  📥 Download the connector below, run with Python, paste this token, and it will auto-register your MT5 connection.
                </p>
                <div className="flex gap-2">
                  <a
                    href={`${DOWNLOAD_BASE}/tradify_mt5_connector.py`}
                    download="tradify_mt5_connector.py"
                    className="flex-1 text-center px-3 py-2 bg-cyan-600 hover:bg-cyan-500 rounded font-semibold text-xs transition"
                  >
                    ⬇️ Download Connector (Python)
                  </a>
                  <a
                    href={`${DOWNLOAD_BASE}/run-connector.bat`}
                    download="run-connector.bat"
                    className="flex-1 text-center px-3 py-2 bg-slate-700 hover:bg-slate-600 rounded font-semibold text-xs transition"
                  >
                    ⬇️ Launcher Script
                  </a>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  💡 Run: <code className="bg-slate-800 px-1 rounded">python tradify_mt5_connector.py</code> or double-click the .bat file
                </p>
              </div>
            )}

            <p className="text-xs text-slate-500 flex items-center gap-1">
              <Lock className="w-3 h-3" /> Token is one-time and expires quickly. No MT5 credentials are stored.
            </p>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-emerald-400">Connections</h3>
              <button
                onClick={refreshConnections}
                className="flex items-center gap-2 text-sm text-cyan-300 hover:text-cyan-200"
                disabled={loading}
              >
                <RefreshCw className="w-4 h-4" /> Refresh
              </button>
            </div>

            {connections.length === 0 ? (
              <div className="p-4 bg-slate-800/60 border border-slate-700 rounded-lg text-sm text-slate-300">
                No active connections yet. Generate a token and register via the connector.
              </div>
            ) : (
              <div className="space-y-3">
                {connections.map((conn) => (
                  <button
                    key={conn.id}
                    onClick={() => {
                      setSelectedConnection(conn)
                      loadTrades(conn.id)
                    }}
                    className={`w-full text-left p-3 rounded-lg border transition ${
                      selectedConnection?.id === conn.id
                        ? 'border-emerald-500/60 bg-emerald-500/10'
                        : 'border-slate-700 bg-slate-900 hover:border-slate-600'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-semibold text-white">{conn.accountNumber}</p>
                        <p className="text-xs text-slate-400">{conn.broker}</p>
                      </div>
                      <span className={`px-2 py-1 text-xs font-semibold rounded ${
                        conn.isConnected ? 'bg-emerald-600 text-white' : 'bg-slate-700 text-slate-200'
                      }`}>
                        {conn.connectionStatus}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-1">Last seen: {conn.lastConnectedAt ? new Date(conn.lastConnectedAt).toLocaleString() : '—'}</p>
                  </button>
                ))}
              </div>
            )}

            {selectedConnection && (
              <div className="p-4 bg-slate-800/70 border border-slate-700 rounded-lg text-sm text-slate-200 space-y-2">
                <div className="flex items-center gap-2 text-cyan-300">
                  <Link2 className="w-4 h-4" /> Connection ID: {selectedConnection.id}
                </div>
                <p>Status: {selectedConnection.connectionStatus}</p>
                <p>Balance: {selectedConnection.accountBalance ?? '—'} | Equity: {selectedConnection.accountEquity ?? '—'}</p>
                <button
                  onClick={() => loadTrades(selectedConnection.id)}
                  className="mt-2 px-3 py-2 bg-slate-700 hover:bg-slate-600 rounded text-xs font-semibold"
                  disabled={loading}
                >
                  Refresh Trades
                </button>
              </div>
            )}
          </div>
        </div>

        {trades && (
          <div className="mt-6">
            <h4 className="text-sm font-semibold text-emerald-300 mb-2">Synced Trades ({trades.length})</h4>
            <div className="max-h-48 overflow-auto space-y-2 text-xs text-slate-200">
              {trades.length === 0 && <p className="text-slate-500">No trades synced yet.</p>}
              {trades.map((t, idx) => (
                <div key={idx} className="p-2 rounded border border-slate-700 bg-slate-900">
                  <div className="flex justify-between">
                    <span className="font-mono">{t.symbol || t.asset || '—'}</span>
                    <span className="text-emerald-400">{t.direction || t.tradeType || '—'}</span>
                  </div>
                  {t.entryPrice && <p className="text-slate-400">Entry: {t.entryPrice}</p>}
                  {t.stopLoss && <p className="text-slate-400">SL: {t.stopLoss}</p>}
                  {t.takeProfit && <p className="text-slate-400">TP: {t.takeProfit}</p>}
                </div>
              ))}
            </div>
          </div>
        )}

        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white"
        >
          ✕
        </button>
      </div>
    </div>
  )
}
