import { Zap, Users, TrendingUp, Award, Shield } from 'lucide-react'
import { useState } from 'react'

export default function TradersHubTab() {
  const [providers] = useState([
    {
      id: 1,
      name: 'Alpha Trading Pro',
      winRate: 68,
      followers: 1240,
      verified: true,
      tier: 'elite',
    },
    {
      id: 2,
      name: 'Swing Master',
      winRate: 62,
      followers: 850,
      verified: true,
      tier: 'pro',
    },
    {
      id: 3,
      name: 'Momentum Trader',
      winRate: 58,
      followers: 340,
      verified: false,
      tier: 'basic',
    },
  ])

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex items-center gap-3 mb-8">
        <Zap className="w-8 h-8 text-yellow-500" />
        <h1 className="text-3xl font-bold text-white">Traders Hub Marketplace</h1>
      </div>

      <div className="grid lg:grid-cols-3 gap-6 mb-8">
        <StatCard icon={<Users className="w-6 h-6" />} label="Signal Providers" value="2,840" />
        <StatCard icon={<TrendingUp className="w-6 h-6" />} label="Avg Win Rate" value="62.4%" />
        <StatCard icon={<Award className="w-6 h-6" />} label="Verified Traders" value="1,240" />
      </div>

      <div className="space-y-4">
        <h2 className="text-xl font-bold text-emerald-400 mb-4">Featured Signal Providers</h2>
        
        {providers.map(provider => (
          <div
            key={provider.id}
            className="bg-gradient-to-r from-slate-900 to-slate-950 border border-slate-800 rounded-xl p-6 hover:border-emerald-500/50 transition"
          >
            <div className="flex justify-between items-start mb-4">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <h3 className="text-lg font-bold text-white">{provider.name}</h3>
                  {provider.verified && (
                    <span className="px-2 py-1 bg-emerald-500/20 text-emerald-400 text-xs font-medium rounded-full border border-emerald-500/50">
                      ✓ Verified
                    </span>
                  )}
                  <span className={`px-2 py-1 text-xs font-medium rounded-full border ${
                    provider.tier === 'elite' ? 'bg-purple-500/20 text-purple-400 border-purple-500/50' :
                    provider.tier === 'pro' ? 'bg-cyan-500/20 text-cyan-400 border-cyan-500/50' :
                    'bg-slate-700/50 text-slate-300 border-slate-600'
                  }`}>
                    {provider.tier.toUpperCase()}
                  </span>
                </div>
              </div>
              <button className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 rounded-lg font-semibold transition">
                Subscribe
              </button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <p className="text-slate-400 text-xs font-medium mb-1">WIN RATE</p>
                <p className="text-2xl font-bold text-emerald-400">{provider.winRate}%</p>
              </div>
              <div>
                <p className="text-slate-400 text-xs font-medium mb-1">FOLLOWERS</p>
                <p className="text-2xl font-bold text-cyan-400">{provider.followers.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-slate-400 text-xs font-medium mb-1">RATING</p>
                <p className="text-2xl font-bold text-yellow-400">4.8★</p>
              </div>
              <div>
                <p className="text-slate-400 text-xs font-medium mb-1">SIGNALS/MONTH</p>
                <p className="text-2xl font-bold text-purple-400">24</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
        <div className="flex gap-3">
          <Shield className="w-6 h-6 text-cyan-400 flex-shrink-0 mt-1" />
          <div>
            <h3 className="font-bold text-white mb-2">Platform Safety</h3>
            <p className="text-sm text-slate-400">
              Traders Hub is a technology marketplace for discovering trading signals. We do not execute trades, hold funds, or provide financial advice. All signal providers are independently verified. Trade at your own risk.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

function StatCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 rounded-xl p-6">
      <div className="flex items-center gap-4">
        <div className="text-emerald-500">{icon}</div>
        <div>
          <p className="text-slate-400 text-sm font-medium">{label}</p>
          <p className="text-2xl font-bold text-white">{value}</p>
        </div>
      </div>
    </div>
  )
}
