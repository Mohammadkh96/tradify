import { Link } from 'react-router-dom'
import { TrendingUp, Shield, Target, Zap } from 'lucide-react'

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white">
      <nav className="container mx-auto px-6 py-6 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <TrendingUp className="w-8 h-8 text-emerald-500" />
          <span className="text-2xl font-bold">TRADIFY</span>
        </div>
        <div className="flex gap-4">
          <Link to="/login" className="px-6 py-2 text-slate-300 hover:text-white transition">
            Login
          </Link>
          <Link to="/signup" className="px-6 py-2 bg-emerald-500 hover:bg-emerald-600 rounded-lg transition">
            Get Started
          </Link>
        </div>
      </nav>

      <main className="container mx-auto px-6 py-20">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-6xl font-bold mb-6 bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
            Deterministic Trading Journal
          </h1>
          <p className="text-xl text-slate-300 mb-12">
            Rule-based trading validation. No AI. No probabilistic guessing. Just pure, deterministic rules.
          </p>
          <Link 
            to="/signup" 
            className="inline-block px-8 py-4 bg-emerald-500 hover:bg-emerald-600 rounded-lg text-lg font-semibold transition glow-green"
          >
            Start Trading Now →
          </Link>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mt-20">
          <FeatureCard 
            icon={<Shield className="w-8 h-8" />}
            title="Rule Enforcement"
            description="Global Hard Rules ensure compliance on every trade"
          />
          <FeatureCard 
            icon={<Target className="w-8 h-8" />}
            title="Real-Time Validation"
            description="Instant feedback as you fill out trade entries"
          />
          <FeatureCard 
            icon={<Zap className="w-8 h-8" />}
            title="Lightning Fast"
            description="Built with React + Vite for instant interactions"
          />
          <FeatureCard 
            icon={<TrendingUp className="w-8 h-8" />}
            title="MT5 Integration"
            description="Connect to MetaTrader 5 for live data"
          />
        </div>
      </main>
    </div>
  )
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="p-6 bg-slate-800/50 rounded-lg border border-slate-700 hover:border-emerald-500 transition">
      <div className="text-emerald-500 mb-4">{icon}</div>
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-slate-400 text-sm">{description}</p>
    </div>
  )
}
