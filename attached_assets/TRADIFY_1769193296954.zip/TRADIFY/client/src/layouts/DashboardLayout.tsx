import { useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { LayoutDashboard, BookOpen, PlusCircle, Network, Calculator, LogOut, Menu, X, Zap } from 'lucide-react'
import DashboardTab from '../components/DashboardTab'
import JournalTab from '../components/JournalTab'
import NewEntryTab from '../components/NewEntryTab'
import KnowledgeBaseTab from '../components/KnowledgeBaseTab'
import RiskCalculatorTab from '../components/RiskCalculatorTab'
import MT5ConnectionModal from '../components/MT5ConnectionModal'
import TradersHubTab from '../components/TradersHubTab'

type TabId = 'dashboard' | 'journal' | 'new-entry' | 'knowledge' | 'risk-calc' | 'traders-hub'

interface Tab {
  id: TabId
  label: string
  icon: React.ReactNode
}

const tabs: Tab[] = [
  { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-5 h-5" /> },
  { id: 'journal', label: 'Journal', icon: <BookOpen className="w-5 h-5" /> },
  { id: 'new-entry', label: 'New Entry', icon: <PlusCircle className="w-5 h-5" /> },
  { id: 'knowledge', label: 'Knowledge Base', icon: <Network className="w-5 h-5" /> },
  { id: 'risk-calc', label: 'Risk Calculator', icon: <Calculator className="w-5 h-5" /> },
  { id: 'traders-hub', label: 'Traders Hub', icon: <Zap className="w-5 h-5" /> },
]

export default function DashboardLayout() {
  const [activeTab, setActiveTab] = useState<TabId>('dashboard')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [showMT5Modal, setShowMT5Modal] = useState(false)
  const { user, logout } = useAuth()

  const renderTab = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardTab />
      case 'journal':
        return <JournalTab />
      case 'new-entry':
        return <NewEntryTab />
      case 'knowledge':
        return <KnowledgeBaseTab />
      case 'risk-calc':
        return <RiskCalculatorTab />
      case 'traders-hub':
        return <TradersHubTab />
      default:
        return <DashboardTab />
    }
  }

  return (
    <div className="min-h-screen bg-slate-950 text-white flex">
      {/* Sidebar */}
      <aside className={`
        fixed lg:static inset-y-0 left-0 z-50 w-64 bg-gradient-to-b from-slate-900 to-slate-950 border-r border-slate-800
        transform transition-transform duration-300 lg:transform-none
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        <div className="p-6 border-b border-slate-800 flex justify-between items-center sticky top-0 bg-slate-900/95 backdrop-blur">
          <div className="flex items-center gap-2">
            <LayoutDashboard className="w-8 h-8 text-emerald-500" />
            <span className="text-xl font-bold">TRADIFY</span>
          </div>
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-4 space-y-4 overflow-y-auto">
          <div className="p-4 bg-gradient-to-r from-slate-800 to-slate-900 rounded-lg border border-slate-700">
            <p className="text-xs text-slate-400 font-medium">LOGGED IN</p>
            <p className="text-sm font-bold text-emerald-400 truncate">{user?.username}</p>
            <p className="text-xs text-slate-500 mt-1">Email: {user?.email}</p>
          </div>

          <nav className="space-y-1">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id)
                  setSidebarOpen(false)
                }}
                className={`
                  w-full flex items-center gap-3 px-4 py-3 rounded-lg transition font-medium
                  ${activeTab === tab.id
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/50 shadow-lg shadow-emerald-500/20'
                    : 'text-slate-400 hover:bg-slate-800/50 hover:text-white'
                  }
                `}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            ))}
          </nav>

          <div className="pt-4 border-t border-slate-800">
            <button
              onClick={() => setShowMT5Modal(true)}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-cyan-400 hover:bg-cyan-500/10 hover:border hover:border-cyan-500/50 transition font-medium"
            >
              <Network className="w-5 h-5" />
              <span>MT5 Connection</span>
            </button>
          </div>

          <button
            onClick={logout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-rose-400 hover:bg-rose-500/10 hover:border hover:border-rose-500/50 transition font-medium"
          >
            <LogOut className="w-5 h-5" />
            <span>Logout</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile Header */}
        <header className="lg:hidden bg-gradient-to-r from-slate-900 to-slate-800 border-b border-slate-700 p-4 flex items-center justify-between">
          <button onClick={() => setSidebarOpen(true)} className="hover:bg-slate-800 p-2 rounded">
            <Menu className="w-6 h-6" />
          </button>
          <span className="font-bold text-emerald-400">TRADIFY</span>
          <button onClick={() => setShowMT5Modal(true)} className="hover:bg-slate-800 p-2 rounded">
            <Network className="w-5 h-5 text-cyan-400" />
          </button>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-auto p-6">
          {renderTab()}
        </div>
      </main>

      {/* MT5 Modal */}
      {showMT5Modal && <MT5ConnectionModal onClose={() => setShowMT5Modal(false)} />}

      {/* Overlay for mobile */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  )
}
