# TRADIFY - Trading Journal Application

**Deterministic Rule-Based Trading Journal with Real-Time Validation**

## 🎯 Overview

TRADIFY is a full-stack trading journal application designed with a **"Stealth Terminal"** aesthetic. It enforces trading methodology through hard-coded rules, preventing emotional trading by requiring traders to declare market observations and validating them against a deterministic ruleset.

### Key Philosophy
- **Zero AI Policy**: No probabilistic guessing—traders declare "What" and TRADIFY enforces "How"
- **Rule-Based Validation**: 4 Global Hard Rules (GR-02 through GR-08) enforced in real-time
- **Deterministic**: Same input always produces same validation result

### 🔌 MT5 Integration (v2.0)
- **Local file-based bridge** - Production-ready, bulletproof reliability
- Real-time account monitoring (balance, equity, margin, leverage)
- Open positions tracking with live P&L
- No network complexity, works 100% offline
- See [MT5_SETUP_GUIDE.md](MT5_SETUP_GUIDE.md) for setup

---

## 📊 Technology Stack

### Frontend
- **React 18** + **Vite** (blazing fast dev server)
- **TypeScript** for type safety
- **Tailwind CSS** for the Stealth Terminal dark theme
- **Framer Motion** for smooth animations
- **Recharts** for performance metrics visualization
- **React Query** (@tanstack/react-query) for server state management
- **React Hook Form** for complex trade form handling
- **Lucide React** for crisp icon system

### Backend
- **Node.js** with **Express.js**
- **PostgreSQL** with **Drizzle ORM**
- **Zod** for schema validation
- **TypeScript** for type-safe backend logic

### Database Schema
- `trade_journal`: 25+ fields including compliance status and violation reasons
- `user_profile`: Account settings and risk parameters

---

## 🎨 Design System (Stealth Terminal Aesthetic)

### Color Palette
| Color | Hex | Usage |
|-------|-----|-------|
| Background | #020617 | App primary background |
| Surface | #0f172a | Cards and panels |
| Elevated | #1e293b | Modal overlays |
| Bullish/Success | #10b981 | Valid setups, wins, Long buttons |
| Bearish/Danger | #f43f5e | Violations, losses, Short buttons |
| Neutral | #94a3b8 | Secondary info, ranges |
| Warning | #f59e0b | Pending trades, alerts |

### Typography
- **Inter**: Primary UI text
- **JetBrains Mono**: All numerical data (prices, R:R ratios) for alignment

### Interactive Elements
- Buttons: `rounded-xl` with `active:scale-95` tactile feedback
- Toggles: Custom emerald pill switches for rule checklists
- Inputs: `font-mono` for price/numeric fields
- Cards: Left-accent borders (emerald=win, rose=loss)

---

## 📱 Application Structure (5 Tabs)

### 1. Dashboard
- **Performance Cards**: Win Rate, Profit Factor, Avg R:R, Total P&L, Total Trades, Compliance Rate
- **Charts**: Pie chart for win/loss distribution
- **Recent Closed Trades**: Last 5 completed trades with outcome badges

### 2. Trade Journal
- Chronological feed of all trades
- Each card displays:
  - Direction (LONG/SHORT) with color coding
  - Entry/SL/TP prices in monospace font
  - R:R ratio
  - Rule compliance badges (Zone ✓, OB/FVG ✓, Liquidity ✓)
  - Trade notes and chart thumbnail

### 3. New Entry (The Rule Engine)
- **Left Column**:
  - Asset input
  - Direction toggle (LONG/SHORT)
  - HTF Bias selector (BULLISH/BEARISH/NEUTRAL)
  - Entry Type (RETEST/REVERSAL/BREAKOUT)
  - Price inputs (Entry, SL, TP)
  - Execution Checklist (3 toggles)
  - Chart upload (dashed border, green highlight on drop)

- **Right Column (HUD)**:
  - Sticky panel with real-time validation
  - Green + valid indicator when rules pass
  - Red + violation list when rules fail
  - Pulses red on violations

### 4. Knowledge Base
- 10 accordion modules:
  1. Market Structure
  2. Supply & Demand Zones
  3. Order Blocks & Fair Value Gaps
  4. Change of Character (CHOCH)
  5. Entry Types
  6. Risk Management
  7-10. Global Hard Rules (GR-02, GR-03, GR-05, GR-08)

### 5. Risk Calculator
- Input: Trading capital, risk %, stop loss pips
- Output: Risk amount, Position size
- Quick reference for conservative/standard/aggressive risk levels

---

## 🔐 Global Hard Rules (GR)

### GR-02: HTF Bias Alignment
```
IF Direction = LONG AND HTFBias ≠ BULLISH → VIOLATION
IF Direction = SHORT AND HTFBias ≠ BEARISH → VIOLATION
```
- Longs only in bullish markets
- Shorts only in bearish markets

### GR-03: Valid Supply/Demand Zone
```
IF hasValidZone = FALSE → VIOLATION
```
- Entry price must be within a confirmed supply or demand zone

### GR-05: Entry Confirmation (OB/FVG Retest)
```
IF hasObFvgRetest = FALSE → VIOLATION
```
- Entry must be confirmed by a retest of an Order Block or Fair Value Gap

### GR-08: Liquidity Sweep Prerequisite
```
IF EntryType = REVERSAL AND hasLiquiditySweep = FALSE → VIOLATION
```
- Reversal entries require prior liquidity sweep to trap traders

---

## � MT5 Integration (MetaTrader 5 Bridge)

### Overview
TRADIFY connects to MetaTrader 5 via the **TradifyBridge Expert Advisor**, which exports real-time account and position data in JSON format.

### Architecture
```
┌─────────────────────────────────────────┐
│     MetaTrader 5 Terminal               │
│  (TradifyBridge.mq5 Expert Advisor)    │
│                                         │
│  Every 2 seconds:                       │
│  → Account snapshot (balance, equity)  │
│  → Open positions (entry, profit)      │
│  → Market data (bid/ask, spread)       │
└────────────────┬────────────────────────┘
                 │
                 ↓ (JSON export)
         TRADIFY_bridge_data.json
                 │
                 ↓ (periodic read)
┌─────────────────────────────────────────┐
│   Tradify Backend (Node.js/Express)    │
│   /api/mt5/snapshot endpoint           │
└────────────────┬────────────────────────┘
                 │
                 ↓ (REST API)
┌─────────────────────────────────────────┐
│   Tradify Frontend (React/Vite)        │
│   Live Dashboard                        │
└─────────────────────────────────────────┘
```

### Quick Start
1. **Copy EA files** to MT5:
   - `tradify-bridge/ea/TradifyBridge.mq5` → `MQL5/Experts/`
   - `tradify-bridge/ea/config.mqh` → `MQL5/Experts/Include/`

2. **Compile in MT5:**
   - Right-click EA → Modify → Compile (F7)

3. **Enable permissions:**
   - Tools → Options → Expert Advisors
   - ✅ Allow automated trading
   - ✅ Allow file operations

4. **Run EA:**
   - Attach to any chart
   - Look for smiley 😊 = running successfully

5. **Verify data:**
   - File → Open Data Folder
   - Find `TRADIFY_bridge_data.json`
   - Should update every 2 seconds

### Full Setup Guide
📖 **See [tradify-bridge/docs/setup.md](tradify-bridge/docs/setup.md)** for:
- Detailed installation steps
- Permission configuration
- File location verification
- Backend integration
- Troubleshooting

### API Contract
📋 **See [tradify-bridge/api/contract.json](tradify-bridge/api/contract.json)** for:
- JSON schema definition
- All exported fields
- Data types and formats
- Example payload

### Data Export (MVP - File-Based)
**Current Implementation:** File-based JSON export
- ✅ Reliable and simple
- ✅ Works offline
- ✅ Zero networking complexity
- ⏭️ **Future:** HTTP server for real-time streaming

---

## �🚀 Getting Started

### Prerequisites
- Node.js 18+
- PostgreSQL 14+ (optional for demo mode)
- npm or yarn

### Installation

```bash
# Clone/extract the project
cd TRADIFY

# Install dependencies for all workspaces
npm install

# Configure environment (optional for demo mode)
# Edit server/.env.local with your PostgreSQL credentials
```

### Development Mode

```bash
# Start frontend (port 3000) and backend (port 3002) concurrently
npm run dev

# If you encounter PowerShell execution policy errors, use:
npm.cmd run dev

# Or use the provided startup scripts:
# Windows: start-dev.bat
# PowerShell: .\start-dev.ps1
```

Open http://localhost:3000 in your browser.

### Build for Production

```bash
npm run build

# Start server
npm start
```

---

## 📡 API Endpoints

### Trades
- `GET /api/trades` - Get all trades
- `GET /api/trades/:id` - Get trade by ID
- `POST /api/trades` - Create new trade
- `PUT /api/trades/:id` - Update trade
- `POST /api/trades/:id/close` - Close trade (mark WIN/LOSS)
- `POST /api/trades/validate` - Real-time validation

### Analytics
- `GET /api/analytics/performance` - Get performance metrics

### Risk
- `POST /api/risk/calculate` - Calculate position size

### Health
- `GET /api/health` - Server health check

---

## 🗂 Project Structure

```
TRADIFY/
├── client/                 # React Vite frontend
│   └── src/
│       ├── components/    # Pure UI components (no logic)
│       └── api/           # API hooks
├── server/                 # Node.js Express backend
│   └── src/
│       ├── engine/        # Rule evaluation (deterministic, pure)
│       │   ├── types.ts
│       │   ├── rule-engine.ts
│       │   └── rule-engine.test.ts
│       ├── market_knowledge/  # JSON/YAML rules (versioned)
│       │   └── rules.json
│       ├── api/           # API routes & validation
│       │   ├── trades.ts
│       │   ├── analytics.ts
│       │   ├── risk.ts
│       │   ├── mt5.ts
│       │   ├── errors.ts
│       │   └── logger.ts
│       ├── db/            # Database layer
│       │   ├── connection.ts
│       │   └── schema.ts
│       └── index.ts       # Main server entry point
├── shared/                # Shared types & schemas
│   └── src/
│       └── index.ts
└── package.json           # Root workspace config
```

> 📖 **Refactoring Details**: See [REFACTORING_COMPLETE.md](REFACTORING_COMPLETE.md) for architecture changes.

---

## 🔧 Configuration

### Frontend (.env.local - optional)
```
VITE_API_URL=http://localhost:3002
```

### Backend (.env.local)
```
DB_HOST=localhost
DB_PORT=5432
DB_NAME=tradify_db
DB_USER=postgres
DB_PASSWORD=postgres
PORT=3002
NODE_ENV=development
```

### Database Setup (Optional)

```sql
-- Create database
CREATE DATABASE tradify_db;

-- Tables are auto-created by Drizzle on first run
```

---

## 🎯 Feature Walkthrough

### Creating a Trade
1. Click **New Entry** tab
2. Fill in: Asset, Direction, HTF Bias, Entry Type, Prices
3. Toggle the 3 execution checklist items
4. Upload chart (optional)
5. Watch the HUD turn green (valid) or red (violations)
6. Submit only when valid

### Viewing Performance
- **Dashboard** shows Win Rate, Profit Factor, R:R, Total P&L
- **Journal** shows chronological trades with compliance badges
- Click trade cards to view details

### Learning Your Methodology
- **Knowledge Base** has 10 modules explaining each rule
- Each module is expandable (accordion)
- Global Hard Rules are summarized at the bottom

### Calculating Position Size
- **Risk Calculator** takes capital, risk %, and stop loss
- Outputs position size for risk management
- Quick reference for conservative to aggressive settings

---

## 🧪 Testing

### Demo Mode (No Database)
Run `npm run dev` without PostgreSQL—the app will run in demo mode with mock data.

### With Database
1. Set up PostgreSQL
2. Configure `.env.local` in server folder
3. Run `npm run dev`

---

## 📈 Future Enhancements

- Chart integration (TradingView lightweights embedded)
- Backtesting module
- Signal alerts
- Multi-account support
- Trade export (CSV, PDF)
- Equity curve overlay
- Heat maps for zone performance

---

## 📄 License

Proprietary - TRADIFY by Mohammad

---

## 🤝 Support

For issues or feature requests, check the in-app Knowledge Base or review the API documentation.

---

**Remember: Follow the rules. Emotions lead to losses. The HUD prevents emotional trading. Trust the process.**
