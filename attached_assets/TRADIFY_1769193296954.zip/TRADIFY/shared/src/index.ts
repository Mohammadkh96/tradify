import { z } from "zod";

// Enums
export enum Direction {
  LONG = "LONG",
  SHORT = "SHORT",
}

export enum TradeStatus {
  PENDING = "PENDING",
  ACTIVE = "ACTIVE",
  CLOSED = "CLOSED",
  CANCELLED = "CANCELLED",
}

export enum MarketStructure {
  BULLISH = "BULLISH",
  BEARISH = "BEARISH",
  NEUTRAL = "NEUTRAL",
}

export enum EntryType {
  RETEST = "RETEST",
  REVERSAL = "REVERSAL",
  BREAKOUT = "BREAKOUT",
}

export enum OutcomeType {
  WIN = "WIN",
  LOSS = "LOSS",
  BREAK_EVEN = "BREAK_EVEN",
}

// Zod Schemas for Validation
export const TradeEntrySchema = z.object({
  id: z.string().optional(),
  asset: z.string().min(1, "Asset required"),
  direction: z.enum([Direction.LONG, Direction.SHORT]),
  htfBias: z.enum([MarketStructure.BULLISH, MarketStructure.BEARISH]),
  entryType: z.enum([EntryType.RETEST, EntryType.REVERSAL, EntryType.BREAKOUT]),
  entryPrice: z.number().positive("Entry price must be positive"),
  stopLoss: z.number().positive("Stop loss must be positive"),
  takeProfit: z.number().positive("Take profit must be positive"),
  
  // Rule Compliance
  hasValidZone: z.boolean().default(false),
  hasLiquiditySweep: z.boolean().default(false),
  hasObFvgRetest: z.boolean().default(false),
  chartImageUrl: z.string().optional(),
  
  status: z.enum([TradeStatus.PENDING, TradeStatus.ACTIVE, TradeStatus.CLOSED, TradeStatus.CANCELLED]).default(TradeStatus.PENDING),
  
  // Outcome (if closed)
  outcome: z.enum([OutcomeType.WIN, OutcomeType.LOSS, OutcomeType.BREAK_EVEN]).optional(),
  closePrice: z.number().optional(),
  exitTime: z.string().datetime().optional(),
  notes: z.string().optional(),
  
  createdAt: z.string().datetime().default(() => new Date().toISOString()),
  updatedAt: z.string().datetime().default(() => new Date().toISOString()),
});

export type TradeEntry = z.infer<typeof TradeEntrySchema>;

// Global Hard Rules
export const GlobalHardRules = {
  GR02: {
    id: "GR-02",
    name: "HTF Bias Alignment",
    description: "Longs only in Bullish markets, Shorts only in Bearish markets",
    check: (direction: Direction, htfBias: MarketStructure): boolean => {
      if (direction === Direction.LONG && htfBias !== MarketStructure.BULLISH) return false;
      if (direction === Direction.SHORT && htfBias !== MarketStructure.BEARISH) return false;
      return true;
    },
  },
  GR03: {
    id: "GR-03",
    name: "Valid Supply/Demand Zone",
    description: "Entry price must be within a valid supply/demand zone",
    check: (hasValidZone: boolean): boolean => hasValidZone,
  },
  GR05: {
    id: "GR-05",
    name: "Entry Confirmation Required",
    description: "OB/FVG retest confirmation is mandatory before entry",
    check: (hasObFvgRetest: boolean): boolean => hasObFvgRetest,
  },
  GR08: {
    id: "GR-08",
    name: "Liquidity Sweep Prerequisite",
    description: "Reversal entries require prior liquidity sweep",
    check: (entryType: EntryType, hasLiquiditySweep: boolean): boolean => {
      if (entryType === EntryType.REVERSAL && !hasLiquiditySweep) return false;
      return true;
    },
  },
};

// Validation function
export const validateTradeCompliance = (trade: TradeEntry): {
  isValid: boolean;
  violations: string[];
} => {
  const violations: string[] = [];

  if (!GlobalHardRules.GR02.check(trade.direction, trade.htfBias)) {
    violations.push(`${GlobalHardRules.GR02.id}: ${GlobalHardRules.GR02.description}`);
  }

  if (!GlobalHardRules.GR03.check(trade.hasValidZone)) {
    violations.push(`${GlobalHardRules.GR03.id}: ${GlobalHardRules.GR03.description}`);
  }

  if (!GlobalHardRules.GR05.check(trade.hasObFvgRetest)) {
    violations.push(`${GlobalHardRules.GR05.id}: ${GlobalHardRules.GR05.description}`);
  }

  if (!GlobalHardRules.GR08.check(trade.entryType, trade.hasLiquiditySweep)) {
    violations.push(`${GlobalHardRules.GR08.id}: ${GlobalHardRules.GR08.description}`);
  }

  return {
    isValid: violations.length === 0,
    violations,
  };
};

// Risk Calculator
export const calculatePositionSize = (
  capital: number,
  riskPercent: number,
  stopLossPips: number,
  pipsValue: number = 1
): number => {
  const riskAmount = capital * (riskPercent / 100);
  const positionSize = riskAmount / (stopLossPips * pipsValue);
  return Math.round(positionSize * 100) / 100;
};

// R:R Ratio Calculation
export const calculateRiskRewardRatio = (
  entryPrice: number,
  stopLoss: number,
  takeProfit: number
): number => {
  const risk = Math.abs(entryPrice - stopLoss);
  const reward = Math.abs(takeProfit - entryPrice);
  return risk > 0 ? Number((reward / risk).toFixed(2)) : 0;
};

export default {
  Direction,
  TradeStatus,
  MarketStructure,
  EntryType,
  OutcomeType,
  TradeEntrySchema,
  GlobalHardRules,
  validateTradeCompliance,
  calculatePositionSize,
  calculateRiskRewardRatio,
};
