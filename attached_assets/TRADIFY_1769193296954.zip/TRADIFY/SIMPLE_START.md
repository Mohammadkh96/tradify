# 🎯 SIMPLE START GUIDE

## The servers aren't running. Here's how to start them:

### EASIEST WAY:

1. **Double-click this file:** `start-servers-visible.bat`
2. **Wait for servers to start** (you'll see messages)
3. **Open browser:** http://localhost:3000

---

## OR Use PowerShell:

1. **Open PowerShell** in the TRADIFY folder
2. **Run this command:**
   ```powershell
   npm.cmd run dev
   ```
3. **Wait 20 seconds** - Look for these messages:
   - ✅ `🚀 TRADIFY Server running on http://localhost:3002`
   - ✅ `➜  Local:   http://localhost:3000/`
4. **Open browser:** http://localhost:3000

---

## What You'll See When It Works:

**In the terminal:**
```
🚀 TRADIFY Server running on http://localhost:3002
📊 API docs available at http://localhost:3002/api

  VITE v5.x.x  ready in xxx ms
  ➜  Local:   http://localhost:3000/
```

**In your browser:**
- http://localhost:3000 → Shows TRADIFY dashboard

---

## If You See Errors:

### "Port already in use"
→ Something else is using ports 3000 or 3002
→ **Fix:** Close other programs or restart computer

### "Cannot find module"
→ Dependencies not installed
→ **Fix:** Run `npm install` first

### "npm is not recognized"
→ Node.js not installed
→ **Fix:** Install Node.js from nodejs.org

### Nothing happens / Blank terminal
→ Check if you're in the right folder
→ **Fix:** Make sure you're in the TRADIFY folder

---

## IMPORTANT:

- ✅ **Keep the terminal window OPEN** - Closing it stops servers
- ✅ **Wait 20 seconds** after starting before opening browser
- ✅ **Both servers must start** - Frontend AND Backend

---

## Test It's Working:

1. **Backend test:** http://localhost:3002/api/health
   - Should show: `{"status":"ok",...}`

2. **Frontend test:** http://localhost:3000
   - Should show: TRADIFY dashboard

---

**Start the servers first, THEN open the browser!**
