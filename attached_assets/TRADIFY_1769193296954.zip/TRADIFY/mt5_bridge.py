#!/usr/bin/env python3
"""
MT5 Bridge - Connects to local MetaTrader 5 terminal and exposes data via REST API
Run this alongside the backend server
"""

import MetaTrader5 as mt5
import json
from flask import Flask, jsonify, request
from flask_cors import CORS
import logging
from datetime import datetime
import threading
import time

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# MT5 connection state
mt5_state = {
    "connected": False,
    "account": None,
    "balance": 0,
    "equity": 0,
    "free_margin": 0,
    "margin_level": 0,
    "open_trades": [],
    "last_sync": None,
}


def connect_to_mt5(login: int, password: str, server: str) -> bool:
    """Connect to MT5 terminal"""
    try:
        # Initialize MT5
        if not mt5.initialize():
            logger.error(f"MT5 init failed: {mt5.last_error()}")
            return False

        # Login
        authorized = mt5.login(login, password, server)
        if not authorized:
            logger.error(f"Login failed: {mt5.last_error()}")
            mt5.shutdown()
            return False

        logger.info(f"Connected to MT5 - Account: {login}")
        mt5_state["connected"] = True
        mt5_state["account"] = login
        
        # Start sync thread
        threading.Thread(target=sync_mt5_data, daemon=True).start()
        
        return True
    except Exception as e:
        logger.error(f"MT5 connection error: {e}")
        return False


def sync_mt5_data():
    """Continuously sync MT5 account data"""
    while mt5_state["connected"]:
        try:
            # Get account info
            account_info = mt5.account_info()
            if account_info:
                mt5_state["balance"] = account_info.balance
                mt5_state["equity"] = account_info.equity
                mt5_state["free_margin"] = account_info.margin_free
                mt5_state["margin_level"] = account_info.margin_level

            # Get open positions
            positions = mt5.positions_get()
            if positions:
                open_trades = []
                for pos in positions:
                    open_trades.append({
                        "id": str(pos.ticket),
                        "symbol": pos.symbol,
                        "direction": "long" if pos.type == mt5.ORDER_TYPE_BUY else "short",
                        "lot_size": pos.volume,
                        "entry_price": pos.price_open,
                        "current_price": pos.price_current,
                        "floating_pl": pos.profit,
                        "comment": pos.comment,
                    })
                mt5_state["open_trades"] = open_trades
            else:
                mt5_state["open_trades"] = []

            mt5_state["last_sync"] = datetime.now().isoformat()
            time.sleep(2)  # Sync every 2 seconds
        except Exception as e:
            logger.error(f"Sync error: {e}")
            time.sleep(5)


def disconnect_mt5():
    """Disconnect from MT5"""
    try:
        mt5.shutdown()
        mt5_state["connected"] = False
        mt5_state["account"] = None
        logger.info("Disconnected from MT5")
        return True
    except Exception as e:
        logger.error(f"Disconnect error: {e}")
        return False


@app.route("/api/mt5/connect", methods=["POST"])
def connect_endpoint():
    """Connect to MT5"""
    try:
        data = request.json
        login = data.get("account")
        password = data.get("password")
        server = data.get("server")

        if not all([login, password, server]):
            return jsonify({"error": "Missing required fields"}), 400

        success = connect_to_mt5(int(login), password, server)
        
        if success:
            return jsonify({
                "success": True,
                "message": "Connected to MT5",
                "connection": {
                    "account": mt5_state["account"],
                    "balance": mt5_state["balance"],
                }
            })
        else:
            return jsonify({"error": "Failed to connect to MT5"}), 500
    except Exception as e:
        logger.error(f"Connect endpoint error: {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/mt5/disconnect", methods=["POST"])
def disconnect_endpoint():
    """Disconnect from MT5"""
    try:
        disconnect_mt5()
        return jsonify({"success": True, "message": "Disconnected from MT5"})
    except Exception as e:
        logger.error(f"Disconnect endpoint error: {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/mt5/status", methods=["GET"])
def status_endpoint():
    """Get MT5 connection status"""
    return jsonify({
        "connected": mt5_state["connected"],
        "account": mt5_state["account"],
        "balance": mt5_state["balance"],
        "equity": mt5_state["equity"],
        "free_margin": mt5_state["free_margin"],
        "margin_level": mt5_state["margin_level"],
        "last_sync": mt5_state["last_sync"],
    })


@app.route("/api/mt5/account", methods=["GET"])
def account_endpoint():
    """Get account data"""
    return jsonify({
        "success": True,
        "account": {
            "balance": mt5_state["balance"],
            "equity": mt5_state["equity"],
            "freeMargin": mt5_state["free_margin"],
            "marginLevel": mt5_state["margin_level"],
            "unrealizedPL": mt5_state["equity"] - mt5_state["balance"],
            "dailyPL": 0,  # Would need trade history to calculate
        }
    })


@app.route("/api/mt5/open-trades", methods=["GET"])
def open_trades_endpoint():
    """Get open trades"""
    return jsonify({
        "success": True,
        "trades": mt5_state["open_trades"]
    })


if __name__ == "__main__":
    logger.info("Starting MT5 Bridge on http://localhost:5001")
    logger.info("Install MetaTrader5 Python module: pip install MetaTrader5")
    app.run(host="0.0.0.0", port=5001, debug=False)
