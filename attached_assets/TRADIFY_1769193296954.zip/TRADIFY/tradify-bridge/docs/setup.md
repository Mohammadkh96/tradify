# MT5 Bridge Setup Guide

## Overview

The TRADIFY Bridge connects MetaTrader 5 (MT5) to the Tradify application using a **file-based JSON export** system. The EA (Expert Advisor) automatically exports real-time account and position data that Tradify reads and displays in the dashboard.

### Architecture

```
MT5 (TradifyBridge.mq5)
    ↓ (exports JSON every 2 seconds)
TRADIFY_bridge_data.json (local file)
    ↓ (Tradify reads periodically)
Tradify Backend (server)
    ↓ (serves to frontend)
Tradify Dashboard (UI)
```

## Installation Steps

### Step 1: Install the EA in MT5

1. **Open MetaTrader 5**
2. **Navigate to the EA folder:**
   - File → Open Data Folder
   - Navigate to: `MQL5/Experts`
3. **Copy Files:**
   - Copy `TradifyBridge.mq5` to `MQL5/Experts/`
   - Copy `config.mqh` to `MQL5/Experts/Include/`

4. **Refresh EA List:**
   - In MT5, press F5 or right-click → Refresh

### Step 2: Compile the EA

1. **Open Navigator** (Ctrl+N in MT5)
2. **Find "TradifyBridge"** in Expert Advisors
3. **Right-click → Modify**
4. **Compile** (F7 or Tools → Compile)
5. **Verify no errors** in the Errors tab
6. **Close the Editor**

### Step 3: Enable Permissions

**Critical:** MT5 requires explicit permission for file operations.

1. **Open MT5 Settings:**
   - Tools → Options → Expert Advisors

2. **Check the following boxes:**
   - ✅ `Allow automated trading`
   - ✅ `Allow DLL imports`
   - ✅ `Allow external input` (optional but recommended)

3. **If EA runs but produces no output:**
   - Tools → Options → Expert Advisors
   - Add "TRADIFY_bridge_data.json" to the file access whitelist
   - Restart MT5

### Step 4: Run the EA

1. **Create a New Chart:**
   - Open any symbol chart (EURUSD recommended for testing)
   - Set timeframe to M5 or H1

2. **Attach the EA:**
   - Right-click chart → Expert Advisors → Attach Expert Advisor
   - Select "TradifyBridge"
   - Keep default settings
   - Click OK

3. **Verify Running:**
   - Look for the smiley face 😊 in top-right of chart
   - If you see sad face 😔 or no face, EA has an error
   - Check the "Experts" tab in the Terminal for error messages

4. **Monitor Output:**
   - Terminal → Experts tab
   - Should see: `=== TRADIFY BRIDGE INITIALIZED ===`
   - Should see periodic: `Data exported successfully. Count: X`

### Step 5: Verify File Export

1. **Find the Data File:**
   - In MT5: File → Open Data Folder
   - Look for `TRADIFY_bridge_data.json`
   - If not there, the EA doesn't have file permissions (see Step 3)

2. **Verify Content:**
   - Open with any text editor
   - Should see valid JSON with account and position data
   - Timestamp should update every 2 seconds

3. **Test Data:**
   ```json
   {
     "timestamp": 1642258800,
     "account": {
       "balance": 10000.00,
       "equity": 10250.50,
       ...
     },
     "positions": [
       {
         "ticket": 1001,
         "symbol": "EURUSD",
         ...
       }
     ]
   }
   ```

## Connecting to Tradify

### Configure Server to Read MT5 Data

1. **Update Tradify Backend:**
   - Edit `/server/src/index.ts`
   - Add MT5 data reader function:

```typescript
import fs from 'fs';

function readMT5Data() {
  try {
    const dataPath = 'C:\\Users\\YourUsername\\AppData\\Roaming\\MetaQuotes\\Terminal\\[TerminalID]\\Files\\TRADIFY_bridge_data.json';
    const data = fs.readFileSync(dataPath, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error reading MT5 data:', error);
    return null;
  }
}
```

2. **Create API Endpoint:**
```typescript
app.get('/api/mt5/snapshot', (req, res) => {
  const data = readMT5Data();
  res.json(data);
});
```

3. **Restart Server:**
   ```bash
   npm run dev
   ```

### Connect Frontend to Backend

1. **Update Dashboard Component:**
   - Edit `/client/src/components/AccountSnapshot.tsx`
   - Add MT5 data fetching:

```typescript
useEffect(() => {
  const fetchMT5Data = async () => {
    try {
      const response = await fetch('http://localhost:3001/api/mt5/snapshot');
      const data = await response.json();
      setAccountData(data.account);
      setPositions(data.positions);
    } catch (error) {
      console.error('Error fetching MT5 data:', error);
    }
  };

  const interval = setInterval(fetchMT5Data, 2000); // Update every 2 seconds
  return () => clearInterval(interval);
}, []);
```

2. **Test Connection:**
   - Start Tradify server: `npm run dev -w server`
   - Start Tradify frontend: `npm run dev -w client`
   - Dashboard should show live account data from MT5

## Configuration

Edit `config.mqh` to customize behavior:

```mql5
// Export interval (seconds) - higher = lower CPU usage
#define EXPORT_INTERVAL_SECONDS 2

// Debug logging
#define DEBUG_MODE true

// Which data to export
#define EXPORT_ACCOUNT_DATA true
#define EXPORT_POSITIONS true
#define EXPORT_MARKET_DATA true
```

## Troubleshooting

### EA Won't Run (Sad Face 😔)

**Possible Causes:**

1. **File Permission Denied:**
   - Check Tools → Options → Expert Advisors
   - Ensure file operations are enabled
   - Restart MT5

2. **Compilation Error:**
   - Open EA editor (right-click → Modify)
   - Check for red error messages
   - Verify `config.mqh` is in correct location
   - Recompile (F7)

3. **Terminal Not Running:**
   - Close MT5 completely
   - Reopen MT5
   - Attach EA again

### No Data File Created

**Solutions:**

1. **Check file permissions:**
   ```
   Tools → Options → Expert Advisors
   ✅ Allow automated trading
   ✅ Allow file access
   ```

2. **Verify terminal data folder path:**
   - File → Open Data Folder
   - Copy full path
   - Check EXPORT_FILE_PATH in config.mqh matches

3. **Check terminal logs:**
   - Terminal → Experts tab
   - Look for error messages starting with "ERROR:"

### Data Not Updating

**Check:**

1. **EA is running:** Look for smiley face 😊 in chart
2. **File timestamp:** Right-click JSON file → Properties → check modified time
3. **Export interval:** Reduce to 1 second in config.mqh for testing
4. **Positions open:** EA needs at least 1 open position to export data

## Next Steps: Upgrade to HTTP

After verifying file-based export works:

1. **Uncomment HTTP code** in TradifyBridge.mq5
2. **Enable HTTP server** in config.mqh:
   ```mql5
   #define HTTP_ENABLED true
   #define HTTP_PORT 3005
   ```
3. **Implement WebSocket** for real-time updates
4. **Remove file dependency** - direct MT5 → Tradify connection

## Support

For issues:

1. Check the Experts tab in MT5 Terminal for error messages
2. Verify TRADIFY_bridge_data.json exists and updates
3. Check Tradify server logs for backend errors
4. Review contract.json schema for expected data format

## Security Notes

- ⚠️ **File-based bridge:** Works on local machine only
- ⚠️ **No encryption:** Data is plain text
- ⚠️ **Single machine:** Don't share files over network
- ✅ **Future:** HTTP/WebSocket with authentication

---

**Version:** 1.0.0  
**Last Updated:** 2026-01-16  
**Status:** MVP - File-based export (Production-ready for local use)
