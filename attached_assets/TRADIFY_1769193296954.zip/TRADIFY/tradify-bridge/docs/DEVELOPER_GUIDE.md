# MT5 Bridge - Quick Reference for Developers

## Installation (For Testing)

### 1. Copy EA Files to MT5
```bash
# EA file
cp tradify-bridge/ea/TradifyBridge.mq5 ~/AppData/Roaming/MetaQuotes/Terminal/[TERMINAL_ID]/MQL5/Experts/

# Config header
cp tradify-bridge/ea/config.mqh ~/AppData/Roaming/MetaQuotes/Terminal/[TERMINAL_ID]/MQL5/Experts/Include/
```

### 2. Compile & Attach
- MT5: Right-click EA → Modify
- Editor: F7 (Compile)
- Terminal: Attach to chart (right-click → Expert Advisors → Attach)

### 3. Verify
- Look for smiley 😊 in chart top-right
- Check Terminal → Experts tab for messages
- File → Open Data Folder → find `TRADIFY_bridge_data.json`

## Backend Integration

### Add MT5 Data Endpoint

**File:** `server/src/index.ts`

```typescript
import fs from 'fs';
import path from 'path';

// Get MT5 bridge data
function getMT5Data() {
  try {
    // This path depends on user's MT5 installation
    // For development, use relative path if EA exports to app folder
    const dataPath = path.join(process.cwd(), 'TRADIFY_bridge_data.json');
    
    if (!fs.existsSync(dataPath)) {
      return null;
    }
    
    const data = fs.readFileSync(dataPath, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error reading MT5 data:', error);
    return null;
  }
}

// Endpoint: Get current account snapshot from MT5
app.get('/api/mt5/snapshot', (req, res) => {
  const data = getMT5Data();
  
  if (!data) {
    return res.status(503).json({
      error: 'MT5 bridge data not available',
      message: 'Ensure EA is running and exporting data'
    });
  }
  
  res.json(data);
});

// Endpoint: Get only account info
app.get('/api/mt5/account', (req, res) => {
  const data = getMT5Data();
  
  if (!data) {
    return res.status(503).json({ error: 'MT5 data unavailable' });
  }
  
  res.json(data.account);
});

// Endpoint: Get only positions
app.get('/api/mt5/positions', (req, res) => {
  const data = getMT5Data();
  
  if (!data) {
    return res.status(503).json({ error: 'MT5 data unavailable' });
  }
  
  res.json(data.positions);
});
```

## Frontend Integration

### Update Dashboard Component

**File:** `client/src/components/AccountSnapshot.tsx`

```typescript
import { useEffect, useState } from 'react';

interface MT5Account {
  name: string;
  balance: number;
  equity: number;
  margin_used: number;
  margin_free: number;
  margin_level: number;
}

interface MT5Position {
  ticket: number;
  symbol: string;
  direction: 'LONG' | 'SHORT';
  volume: number;
  entry_price: number;
  current_price: number;
  profit: number;
  profit_pips: number;
}

export function AccountSnapshot() {
  const [account, setAccount] = useState<MT5Account | null>(null);
  const [positions, setPositions] = useState<MT5Position[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchMT5Data = async () => {
      try {
        const response = await fetch('http://localhost:3001/api/mt5/snapshot');
        
        if (!response.ok) {
          throw new Error('MT5 data unavailable');
        }
        
        const data = await response.json();
        setAccount(data.account);
        setPositions(data.positions);
        setError(null);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error');
      } finally {
        setLoading(false);
      }
    };

    // Fetch immediately
    fetchMT5Data();

    // Refresh every 2 seconds (matches EA export interval)
    const interval = setInterval(fetchMT5Data, 2000);

    return () => clearInterval(interval);
  }, []);

  if (loading) return <div>Loading MT5 data...</div>;
  if (error) return <div className="text-rose-500">Error: {error}</div>;
  if (!account) return <div>No MT5 data</div>;

  return (
    <div className="space-y-4">
      {/* Account Info */}
      <div className="bg-slate-900 p-4 rounded-lg">
        <h2 className="text-emerald-500 font-bold">{account.name}</h2>
        <div className="grid grid-cols-2 gap-4 mt-4 font-mono text-sm">
          <div>
            <span className="text-slate-400">Balance:</span>
            <span className="ml-2">${account.balance.toFixed(2)}</span>
          </div>
          <div>
            <span className="text-slate-400">Equity:</span>
            <span className="ml-2">${account.equity.toFixed(2)}</span>
          </div>
          <div>
            <span className="text-slate-400">Margin Used:</span>
            <span className="ml-2">${account.margin_used.toFixed(2)}</span>
          </div>
          <div>
            <span className="text-slate-400">Margin Level:</span>
            <span className="ml-2">{account.margin_level.toFixed(2)}%</span>
          </div>
        </div>
      </div>

      {/* Positions */}
      <div className="space-y-2">
        <h3 className="text-slate-300 font-bold">Open Positions ({positions.length})</h3>
        {positions.length === 0 ? (
          <p className="text-slate-500">No open positions</p>
        ) : (
          positions.map((pos) => (
            <div
              key={pos.ticket}
              className={`p-3 rounded border-l-4 ${
                pos.direction === 'LONG'
                  ? 'border-emerald-500 bg-emerald-950/20'
                  : 'border-rose-500 bg-rose-950/20'
              }`}
            >
              <div className="flex justify-between items-center font-mono text-sm">
                <span className="font-bold">{pos.symbol}</span>
                <span className={pos.profit >= 0 ? 'text-emerald-500' : 'text-rose-500'}>
                  {pos.profit >= 0 ? '+' : ''}{pos.profit.toFixed(2)}
                </span>
              </div>
              <div className="text-xs text-slate-400 mt-1">
                {pos.direction} {pos.volume} lot @ {pos.entry_price}
                {' '}→ {pos.current_price} ({pos.profit_pips.toFixed(1)} pips)
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
```

## Testing

### Manual Testing Checklist

```bash
# 1. Start MT5 with EA attached
# 2. Verify JSON file exists
ls ~/AppData/Roaming/MetaQuotes/Terminal/*/Files/TRADIFY_bridge_data.json

# 3. Watch file updates
watch -n 1 'cat TRADIFY_bridge_data.json | jq .timestamp'

# 4. Start backend
npm run dev -w server

# 5. Test API endpoint
curl http://localhost:3001/api/mt5/snapshot | jq .

# 6. Start frontend
npm run dev -w client

# 7. Check dashboard for live data
# Should see account info and positions updating
```

### Verify Data Flow

```
1. EA Running?
   → Look for smiley 😊 in MT5 chart

2. File Updating?
   → Check TRADIFY_bridge_data.json timestamp

3. Backend Reading?
   → curl localhost:3001/api/mt5/snapshot

4. Frontend Displaying?
   → Check AccountSnapshot component in dashboard
   → Data should update every 2 seconds
```

## Common Errors

### "Cannot find TRADIFY_bridge_data.json"
```
→ EA not running or no file permissions
→ Check Tools → Options → Expert Advisors
→ Enable "Allow automated trading" and "Allow file operations"
```

### "JSON is invalid"
```
→ EA might still be writing
→ Wait 2 seconds and retry
→ Check EA logs for errors
```

### "Data is stale"
```
→ EA stopped running
→ Check MT5 Terminal → Experts tab for errors
→ Reattach EA to chart
```

## File Locations (Windows)

```
MT5 Installation:
C:\Program Files\MetaTrader 5

Terminal Data:
C:\Users\[USERNAME]\AppData\Roaming\MetaQuotes\Terminal\[TERMINAL_ID]

EA Files Go Here:
...\Terminal\[TERMINAL_ID]\MQL5\Experts\

Config Header Goes Here:
...\Terminal\[TERMINAL_ID]\MQL5\Experts\Include\

JSON Output File:
...\Terminal\[TERMINAL_ID]\Files\TRADIFY_bridge_data.json
```

## Debugging

### Enable Debug Logging

**In config.mqh:**
```mql5
#define DEBUG_MODE true
#define LOG_FREQUENCY 1  // Log every export
```

### Check EA Logs
- MT5 Terminal → Experts tab
- Look for messages starting with "==="
- Check for "ERROR:" messages

### Monitor File Changes
```bash
# Linux/Mac
tail -f TRADIFY_bridge_data.json

# Windows
Get-Content TRADIFY_bridge_data.json -Tail 20 -Wait
```

### Validate JSON Schema
```bash
# Using ajv-cli
npm install -g ajv-cli
ajv validate -s tradify-bridge/api/contract.json -d TRADIFY_bridge_data.json
```

## Performance Notes

- **Export interval:** 2 seconds (adjustable in config.mqh)
- **File size:** ~1-2 KB per export
- **CPU usage:** <1% (minimal)
- **Latency:** <50ms (file I/O)
- **Polling frequency:** 2-5 seconds recommended

## Security Considerations

⚠️ **File-based bridge is local-only:**
- No authentication
- No encryption
- Works offline
- Single machine only

✅ **Acceptable for:**
- Development
- Testing
- Demo accounts
- Local trading

❌ **Not suitable for:**
- Cloud deployment
- Multiple machines
- Production with real accounts
- Public networks

---

**Ready to integrate? See [setup.md](tradify-bridge/docs/setup.md) for user-facing guide.**
