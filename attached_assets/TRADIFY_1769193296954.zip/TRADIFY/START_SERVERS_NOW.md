# 🚨 START SERVERS NOW - Step by Step

## The Problem
"Refused to connect" means **the servers are NOT running**. You need to start them first!

## Solution: Start Both Servers

### Option 1: Start Both Together (Recommended)

**Open PowerShell in the TRADIFY folder and run:**
```powershell
npm.cmd run dev
```

**OR double-click:** `start-dev.bat`

**Wait 15-20 seconds** for both servers to start.

### Option 2: Start Servers Separately (If Option 1 Doesn't Work)

**Terminal 1 - Backend:**
```powershell
cd server
npm.cmd run dev
```

**Terminal 2 - Frontend (open a NEW terminal):**
```powershell
cd client
npm.cmd run dev
```

## What You Should See

### Backend Terminal Should Show:
```
🚀 TRADIFY Server running on http://localhost:3002
📊 API docs available at http://localhost:3002/api
```

### Frontend Terminal Should Show:
```
  VITE v5.x.x  ready in xxx ms

  ➜  Local:   http://localhost:3000/
  ➜  Network: use --host to expose
```

## After Servers Start

1. **Wait 10-15 seconds** for full initialization
2. **Open browser:** http://localhost:3000
3. **If blank page:** Press `Ctrl + Shift + R` to hard refresh

## Verify Servers Are Running

### Check Backend:
Open: http://localhost:3002/api/health
- Should show: `{"status":"ok",...}`

### Check Frontend:
Open: http://localhost:3000
- Should show the TRADIFY dashboard

## Common Issues

### "Port already in use"
**Solution:** Kill the process using the port:
```powershell
# Find process
netstat -ano | findstr ":3000"
netstat -ano | findstr ":3002"

# Kill it (replace PID)
taskkill /PID <PID> /F
```

### "Cannot find module"
**Solution:** Install dependencies:
```powershell
npm install
```

### Servers start but browser shows "refused to connect"
**Solution:** 
1. Wait longer (20-30 seconds)
2. Check firewall isn't blocking ports
3. Try http://127.0.0.1:3000 instead of localhost:3000

### Only one server starts
**Solution:** Start them separately in two terminals (Option 2 above)

## Important Notes

- ✅ **Keep terminal windows OPEN** - Closing them stops the servers
- ✅ **Both servers must be running** - Frontend AND Backend
- ✅ **Wait for startup messages** - Don't open browser immediately
- ✅ **Use `npm.cmd` not `npm`** - Avoids PowerShell execution policy issues

## Still Not Working?

1. **Close ALL terminal windows**
2. **Restart your computer** (clears port conflicts)
3. **Open PowerShell as Administrator**
4. **Navigate to TRADIFY folder**
5. **Run:** `npm.cmd run dev`
6. **Wait 30 seconds**
7. **Open:** http://localhost:3000

---

**Remember:** The servers MUST be running before you can access the app!
