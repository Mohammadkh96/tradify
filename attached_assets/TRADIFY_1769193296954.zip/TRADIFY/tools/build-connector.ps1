param(
    [string]$Python = "python",
    [string]$OutputDir = "dist"
)

$ErrorActionPreference = "Stop"

# Ensure PyInstaller is available
$pyi = & $Python -m pip show pyinstaller -q
if (-not $pyi) {
    & $Python -m pip install pyinstaller
}

# Clean previous build artifacts
if (Test-Path .\.build\pyi) { Remove-Item .\.build\pyi -Recurse -Force }
if (Test-Path $OutputDir) { New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null }

# Build single-file Windows executable with GUI (no console)
& $Python -m PyInstaller `
    --noconsole `
    --onefile `
    --name tradify-connector `
    --clean `
    --distpath $OutputDir `
    --workpath .\.build\pyi `
    tradify_connector.py

Write-Host "Build complete. Output: $OutputDir\tradify-connector.exe" -ForegroundColor Green
