# TRADIFY - Customization Guide

This guide explains how to customize TRADIFY for your specific trading methodology.

---

## 🎨 Color & Theme Customization

### Change Primary Colors

**File**: `client/tailwind.config.js`

```javascript
// Current colors
colors: {
  emerald: { 500: "#10b981" },  // Bullish
  rose: { 500: "#f43f5e" },     // Bearish
  slate: { 950: "#020617" },    // Background
}

// Example: Change to Blue (Bullish) and Orange (Bearish)
colors: {
  blue: { 500: "#3b82f6" },     // Bullish
  orange: { 500: "#f97316" },   // Bearish
  slate: { 950: "#020617" },    // Background
}
```

Then update all emerald/rose references in components.

### Change Dark Theme Intensity

**File**: `client/tailwind.config.js`

```javascript
// Darker (current)
slate: {
  950: "#020617",  // Ultra dark
  900: "#0f172a",  // Dark surface
  800: "#1e293b",  // Borders
}

// Lighter
slate: {
  950: "#111827",  // Slightly lighter
  900: "#1f2937",  // Surface
  800: "#374151",  // Borders
}
```

### Change Font Family

**File**: `client/tailwind.config.js` and `client/src/index.css`

```javascript
// tailwind.config.js
fontFamily: {
  mono: ["Consolas", "Monaco", monospace],  // Change from JetBrains
  sans: ["Segoe UI", "Roboto", sans-serif], // Change from Inter
}

// index.css
@import url('https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@400;600&display=swap');
```

---

## 📏 Layout & Spacing

### Sidebar Width (Desktop)

**File**: `client/src/App.tsx`

```tsx
// Current: w-64 (256px)
<motion.div
  animate={{ x: sidebarOpen ? 0 : -256 }}
  className="fixed lg:static w-64 h-screen ..."
>

// Change to w-80 (320px) or w-56 (224px)
className="fixed lg:static w-80 h-screen ..."
```

### Main Content Padding

**File**: `client/src/App.tsx`

```tsx
// Current: p-10
<div className="p-10 max-w-7xl mx-auto">

// Change to p-6 (compact) or p-16 (spacious)
<div className="p-6 max-w-7xl mx-auto">
```

### Max Content Width

**File**: `client/src/App.tsx`

```tsx
// Current: max-w-7xl (80rem)
<div className="p-10 max-w-7xl mx-auto">

// Change to max-w-6xl or max-w-full
<div className="p-10 max-w-full mx-auto">
```

---

## 🔐 Customize Trading Rules

### Add a New Global Hard Rule (GR-09)

**File**: `shared/src/index.ts`

```typescript
// Step 1: Add to GlobalHardRules object
GlobalHardRules.GR09 = {
  id: "GR-09",
  name: "My Custom Rule",
  description: "My custom rule description",
  check: (field1: string, field2: boolean): boolean => {
    // Your custom logic
    if (field1 === "value" && !field2) return false;
    return true;
  },
};

// Step 2: Add to TradeEntry schema
export const TradeEntrySchema = z.object({
  // ... existing fields ...
  customRuleField: z.boolean().default(false),
});

// Step 3: Add to validation function
export const validateTradeCompliance = (trade: TradeEntry) => {
  const violations: string[] = [];
  
  // ... existing checks ...
  
  if (!GlobalHardRules.GR09.check(trade.customRuleField, trade.direction)) {
    violations.push(`${GlobalHardRules.GR09.id}: ${GlobalHardRules.GR09.description}`);
  }
  
  return { isValid: violations.length === 0, violations };
};
```

### Modify Existing Rule (e.g., GR-02)

**File**: `shared/src/index.ts`

```typescript
// Current: Only LONG in BULLISH, SHORT in BEARISH
GlobalHardRules.GR02 = {
  // ... 
  check: (direction: Direction, htfBias: MarketStructure): boolean => {
    // NEW: Also allow NEUTRAL bias with 1:2 R:R minimum
    if (htfBias === MarketStructure.NEUTRAL) {
      // Check R:R validation elsewhere
      return true;
    }
    if (direction === Direction.LONG && htfBias !== MarketStructure.BULLISH) return false;
    if (direction === Direction.SHORT && htfBias !== MarketStructure.BEARISH) return false;
    return true;
  },
};
```

---

## 📊 Add New Tab

### Step 1: Create Component

**File**: `client/src/components/CustomTab.tsx`

```tsx
import React from "react";

export const CustomTab = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-slate-100 mb-2">My Custom Tab</h1>
        <p className="text-slate-400">Description goes here</p>
      </div>
      
      {/* Your content */}
    </div>
  );
};
```

### Step 2: Add to App.tsx

**File**: `client/src/App.tsx`

```tsx
// Import
import { CustomTab } from "./components/CustomTab";

// Add to tabs array
const tabs: Tab[] = [
  // ... existing tabs ...
  { id: "custom", label: "My Tab", icon: <Custom className="w-5 h-5" /> },
];

// Add case to renderTab switch
const renderTab = () => {
  switch (activeTab) {
    // ... existing cases ...
    case "custom":
      return <CustomTab />;
  }
};
```

### Step 3: Import Icon

```tsx
import { Icon } from "lucide-react"; // Choose icon from Lucide

// Use in tabs array
{ id: "custom", label: "My Tab", icon: <Icon className="w-5 h-5" /> }
```

---

## 🗄 Modify Database Schema

### Add New Field to Trades

**File**: `server/src/schema.ts`

```typescript
export const tradeJournal = pgTable("trade_journal", {
  // ... existing fields ...
  
  // NEW: Add custom field
  myCustomField: varchar("my_custom_field", { length: 100 }),
  riskRewardRatio: numeric("risk_reward_ratio", { precision: 5, scale: 2 }),
  
  // ... rest of fields ...
});
```

**File**: `shared/src/index.ts`

```typescript
export const TradeEntrySchema = z.object({
  // ... existing fields ...
  myCustomField: z.string().optional(),
  riskRewardRatio: z.number().optional(),
});

export interface TradeEntry {
  // ... existing fields ...
  myCustomField?: string;
  riskRewardRatio?: number;
}
```

---

## 📡 Add Custom API Endpoint

**File**: `server/src/index.ts`

```typescript
// Add new endpoint
app.post("/api/custom/my-endpoint", async (req: Request, res: Response) => {
  try {
    const { param1, param2 } = req.body;
    
    // Your custom logic
    const result = await db
      .select()
      .from(tradeJournal)
      .where(eq(tradeJournal.asset, param1));
    
    res.json({
      success: true,
      data: result,
    });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ error: "Failed to process" });
  }
});
```

**File**: `client/src/api/hooks.ts`

```typescript
export const useMyCustomEndpoint = () => {
  return async (param1: string, param2: string) => {
    const response = await fetch("/api/custom/my-endpoint", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ param1, param2 }),
    });
    if (!response.ok) throw new Error("Failed");
    return response.json();
  };
};
```

---

## 🎯 Change Default Settings

### Default Risk Per Trade

**File**: `shared/src/index.ts`

```typescript
// Change default from 2% to 1.5%
const DEFAULT_RISK_PERCENT = 1.5;
```

### Default Entry Type

**File**: `client/src/components/NewEntryForm.tsx`

```typescript
const { register, watch, handleSubmit, setValue, reset, formState: { errors } } = useForm<TradeEntry>({
  defaultValues: {
    asset: "",
    direction: "LONG",
    htfBias: "BULLISH",
    entryType: "BREAKOUT",  // Change from RETEST
    // ... rest
  },
});
```

### Chart Upload File Size Limit

**File**: `client/src/components/NewEntryForm.tsx`

```typescript
const handleChartUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
  const file = e.target.files?.[0];
  const MAX_SIZE = 5 * 1024 * 1024; // 5MB
  
  if (file && file.size > MAX_SIZE) {
    alert("File too large (max 5MB)");
    return;
  }
  
  setChartFile(file);
};
```

---

## 🔄 Change Update Frequency

### Dashboard Metrics Refresh Rate

**File**: `client/src/api/hooks.ts`

```typescript
export const usePerformanceMetrics = () => {
  return useQuery<PerformanceMetrics>({
    queryKey: ["performanceMetrics"],
    queryFn: async () => { /* ... */ },
    refetchInterval: 60000, // 60 seconds (was 30s)
  });
};
```

### Trades List Refresh Rate

```typescript
export const useTrades = () => {
  return useQuery<TradeEntry[]>({
    queryKey: ["trades"],
    queryFn: async () => { /* ... */ },
    refetchInterval: 20000, // 20 seconds (was 10s)
  });
};
```

---

## 🎓 Customize Knowledge Base

**File**: `client/src/components/KnowledgeBaseTab.tsx`

```typescript
const modules = [
  {
    title: "My New Module",
    content: "Module content goes here. Use\\n for line breaks.",
  },
  {
    title: "Another Module",
    content: "More content...",
  },
];
```

---

## 🎨 Customize Risk Calculator

**File**: `client/src/components/RiskCalculatorTab.tsx`

```typescript
// Add more inputs
const [equity, setEquity] = React.useState(10000);
const [winRate, setWinRate] = React.useState(0.50);

// Add custom calculations
const profitTarget = (capital * winRate * riskPercent) / 100;
```

---

## 📝 Change Trade Card Display

**File**: `client/src/components/TradeCard.tsx`

```typescript
<div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-4 text-sm">
  {/* Add custom fields */}
  <div>
    <p className="text-xs text-slate-400">Custom Field</p>
    <p className="font-mono font-semibold text-slate-100">
      {trade.myCustomField}
    </p>
  </div>
</div>
```

---

## 🧪 Testing Custom Changes

### Test New Rule

**Steps**:
1. Add rule to `shared/src/index.ts`
2. Create test trade in New Entry form
3. Watch HUD update with new rule violation
4. Verify server validation matches frontend

### Test New Endpoint

```bash
curl -X POST http://localhost:3001/api/custom/my-endpoint \
  -H "Content-Type: application/json" \
  -d '{"param1":"value1"}'
```

### Test Database Changes

1. Update schema in `server/src/schema.ts`
2. Run: `npm run db:migrate`
3. Verify in PostgreSQL

---

## 🚀 Best Practices

✅ **DO:**
- Keep rule logic in `shared/` for reuse
- Use Zod for all schema validation
- Test API changes with curl first
- Update both frontend and backend schemas together
- Document custom rules in Knowledge Base

❌ **DON'T:**
- Hardcode values in components
- Skip server-side validation
- Remove existing Global Hard Rules (modify them instead)
- Change database fields without migration
- Forget to update TypeScript interfaces

---

## 🔗 Common Customization Patterns

### Add Optional Trade Status

```typescript
// 1. Update schema
status: z.enum(["PENDING", "ACTIVE", "CLOSED", "CANCELLED", "PAUSED"]),

// 2. Update enum
enum TradeStatus {
  PENDING = "PENDING",
  ACTIVE = "ACTIVE",
  CLOSED = "CLOSED",
  CANCELLED = "CANCELLED",
  PAUSED = "PAUSED",
}

// 3. Update UI to show new status
{trade.status === "PAUSED" && <span>⏸ Paused</span>}
```

### Add Performance Filter

```typescript
// New API endpoint
app.get("/api/trades/filter", async (req: Request, res: Response) => {
  const { status, direction } = req.query;
  
  let query = db.select().from(tradeJournal);
  
  if (status) query = query.where(eq(tradeJournal.status, status));
  if (direction) query = query.where(eq(tradeJournal.direction, direction));
  
  const result = await query;
  res.json(result);
});
```

### Add Email Alerts

```typescript
// New API endpoint
app.post("/api/alerts/email", async (req: Request, res: Response) => {
  const { email, ruleViolation } = req.body;
  
  // Send email using nodemailer or SendGrid
  // await sendEmail(email, `Rule violation: ${ruleViolation}`);
  
  res.json({ success: true });
});
```

---

## 📚 Useful Resources

- **Tailwind CSS**: https://tailwindcss.com/docs
- **Lucide Icons**: https://lucide.dev
- **React Query**: https://tanstack.com/query/latest
- **React Hook Form**: https://react-hook-form.com
- **Drizzle ORM**: https://orm.drizzle.team
- **Framer Motion**: https://www.framer.com/motion/

---

**Start customizing! Make TRADIFY truly yours.** 🚀
