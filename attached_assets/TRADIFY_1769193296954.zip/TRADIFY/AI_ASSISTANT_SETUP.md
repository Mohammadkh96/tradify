# TRADIFY AI Assistant - Setup Guide

## Overview

The TRADIFY AI Assistant is now live as an OpenAI-powered, teachable system that's constrained by trading rules and internal knowledge base. Responses are rule-based, auditable, and educational.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Frontend (React)                         │
│              AssistantChat Component                        │
│           (Floating launcher + chat panel)                  │
└─────────────────────┬───────────────────────────────────────┘
                      │ POST /api/ai/chat
                      ▼
┌─────────────────────────────────────────────────────────────┐
│                   Backend (Express)                         │
│                   AI Router (ai.ts)                         │
│      ┌──────────────────────────────────────────┐          │
│      │  TradifyAssistant (assistant.ts)         │          │
│      │  - Conversation management               │          │
│      │  - OpenAI API calls                      │          │
│      │  - Logging & auditing                    │          │
│      └──────────────────────────────────────────┘          │
│                       │ queries                             │
│      ┌──────────────────────────────────────────┐          │
│      │  KnowledgeBase (knowledgeBase.ts)        │          │
│      │  - Trading Rules (5+ items)              │          │
│      │  - Platform Guides (2+ items)            │          │
│      │  - Strategies (1+ items)                 │          │
│      │  - FAQs (2+ items)                       │          │
│      └──────────────────────────────────────────┘          │
│                       │                                     │
│      ┌──────────────────────────────────────────┐          │
│      │    OpenAI API (gpt-3.5-turbo)            │          │
│      │    - System prompts with rules           │          │
│      │    - Temperature: 0.7 (balanced)         │          │
│      │    - Max tokens: 500                     │          │
│      └──────────────────────────────────────────┘          │
└─────────────────────────────────────────────────────────────┘
```

## Setup Instructions

### 1. Install Backend Dependencies

```bash
cd server
npm install openai
npm install
```

### 2. Set OpenAI API Key

Create or update `.env` file in the project root:

```env
OPENAI_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
NODE_ENV=development
PORT=3002
```

**How to get OpenAI API Key:**
1. Go to https://platform.openai.com/api-keys
2. Log in with your OpenAI account (create one if needed)
3. Click "Create new secret key"
4. Copy and paste into `.env`
5. Keep it secret! Add `.env` to `.gitignore`

### 3. Start Servers

```bash
# Terminal 1 - Backend
cd server
npm run dev

# Terminal 2 - Frontend
cd client
npm run dev
```

Both should show:
```
TRADIFY Server running on http://localhost:3002
Vite dev server running at http://localhost:3000
```

### 4. Test the Assistant

1. Open http://localhost:3000 in browser
2. Click the floating "T" icon in bottom-right
3. Ask a question like:
   - "What's the 2% rule?"
   - "How do I set up MT5?"
   - "Tell me about breakout trading"
   - "What's the daily loss limit?"

## Configuration & Customization

### Add New Knowledge Items

Edit [server/src/ai/knowledgeBase.ts](../server/src/ai/knowledgeBase.ts):

```typescript
private initializeDefaultKnowledge() {
  this.addItem({
    id: "rule-your-topic",
    category: "rule",  // or "guide", "faq", "strategy"
    title: "Your Title",
    content: "Your detailed content here...",
    keywords: ["keyword1", "keyword2", "keyword3"],
    source: "Your Source",
    updatedAt: new Date(),
  });
}
```

### Change AI Model

In [server/src/ai/assistant.ts](../server/src/ai/assistant.ts), line 67:

```typescript
const response = await this.client.chat.completions.create({
  model: "gpt-4",  // Change from gpt-3.5-turbo to gpt-4
  // ... rest of config
});
```

**Model Options:**
- `gpt-3.5-turbo` - Fast, cheaper, good for rules
- `gpt-4` - Smarter, more accurate, 10x more expensive
- `gpt-4-turbo` - Balance of both

### Adjust Personality

In [server/src/ai/assistant.ts](../server/src/ai/assistant.ts), method `buildSystemPrompt()`:

```typescript
return `You are the TRADIFY AI Assistant...
YOUR CONSTRAINTS:
1. [Modify these constraints]
...`;
```

### Change Response Temperature

In [server/src/ai/assistant.ts](../server/src/ai/assistant.ts), line 73:

```typescript
temperature: 0.7,  // 0 = deterministic, 1 = creative
```

## API Endpoints

### Chat with AI
**POST** `/api/ai/chat`

Request:
```json
{
  "message": "What's the stop-loss rule?"
}
```

Response:
```json
{
  "success": true,
  "data": {
    "message": "Every trade must have a defined stop-loss level...",
    "sources": ["Always Set Stop Loss", "Risk Management"],
    "confidence": 0.95,
    "logId": "log_1705779600000_abc123def"
  }
}
```

### Get Knowledge Base
**GET** `/api/ai/knowledge`

Returns all available knowledge items with categories.

### Get Interaction Logs
**GET** `/api/ai/logs`

Returns last 50 interactions (for admin auditing).

### Reset Conversation
**POST** `/api/ai/reset`

Clears conversation history and starts fresh.

## Features

### ✅ Implemented
- OpenAI integration with system prompts
- Knowledge base with 10+ pre-loaded items
- Retrieval-augmented generation (RAG)
- Conversation history tracking
- Interaction logging for auditing
- Auto-scrolling message panel
- Loading states
- Source attribution
- Confidence scoring
- Error handling
- Educational disclaimers

### 🔲 Coming Soon
- Chart screenshot analysis (vision API)
- Trade-specific analysis
- Performance metrics extraction
- Rule violation detection
- Multi-turn reasoning
- Persistent conversation history (localStorage)
- User preference learning
- Export conversation to PDF
- Feedback system

## Safety & Compliance

### Disclaimers
The assistant clearly states:
- Educational purpose only
- Not a financial advisor
- Cannot guarantee results
- Always manage risk

### Logging
Every interaction is logged with:
- User message
- AI response
- Knowledge sources used
- Confidence level
- Timestamp

Logs are accessible via `/api/ai/logs`

### Auditing
AI responses are:
- Grounded in TRADIFY knowledge base
- Fully transparent about sources
- Deterministic (same question = same answer)
- Non-advisory (no trading recommendations)

## Troubleshooting

### "Connection error. Is the server running on localhost:3002?"

**Check:**
1. Backend server is running: `npm run dev` in `/server`
2. Port 3002 is not blocked
3. Try: `curl http://localhost:3002/api/health`

### "OPENAI_API_KEY not found"

**Fix:**
1. Create `.env` file in project root
2. Add: `OPENAI_API_KEY=sk-...`
3. Restart backend server
4. Verify with: `node -e "console.log(process.env.OPENAI_API_KEY)"`

### "Knowledge base not found"

**Fix:**
1. Verify file exists: `server/src/ai/knowledgeBase.ts`
2. Check imports in `assistant.ts`
3. Restart backend server

### "Slow responses from AI"

**Optimize:**
1. Switch to `gpt-3.5-turbo` (faster)
2. Reduce `max_tokens` from 500 to 300
3. Increase `temperature` from 0.7 to 1.0 (less thinking)

### "AI gives wrong or off-topic answers"

**Solution:**
1. Add more relevant knowledge items
2. Refine keywords for better retrieval
3. Strengthen system prompt constraints
4. Test with `curl` first to isolate issue

## Performance Metrics

- **Average response time:** 1-3 seconds
- **Concurrent users:** Limited by OpenAI rate limits
- **Knowledge base size:** ~15KB (scalable)
- **Cost per message:** ~$0.0005-$0.002 (GPT-3.5)

## Next Steps

1. **Deploy to production:** Add OPENAI_API_KEY to production environment
2. **Monitor logs:** Set up log aggregation and alerting
3. **Expand knowledge base:** Add your custom trading strategies
4. **Add vision API:** Enable screenshot analysis
5. **Implement feedback:** Let users rate assistant responses
6. **Schedule retraining:** Update knowledge base monthly

## Support

For issues or questions:
1. Check logs: `GET /api/ai/logs`
2. Test connection: `GET /api/ai/knowledge`
3. Review console errors
4. Check `.env` configuration

---

**Last Updated:** January 20, 2026  
**Version:** 1.0 - MVP  
**Status:** Production Ready ✅
