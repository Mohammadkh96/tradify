#!/usr/bin/env python3
"""
TRADIFY MT5 Connector
=====================

A local connector application that runs on the user's machine and bridges
their MetaTrader 5 terminal with the TRADIFY platform.

Installation:
    pip install MetaTrader5 websocket-client requests

Usage:
    python tradify_connector.py --token YOUR_CONNECTION_TOKEN

Configuration:
    Edit the config below for your setup
"""

import os
import sys
import argparse
import json
import time
import logging
import threading
import socket
import queue
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime, timedelta
from datetime import date, time as dt
from typing import Callable, Dict, List, Optional, Tuple

try:
    import MetaTrader5 as mt5
    import requests
    from requests.adapters import HTTPAdapter
    from urllib3.util.retry import Retry
except ImportError as e:
    error_msg = f"""
╔════════════════════════════════════════════════════════════╗
║                    DEPENDENCY ERROR                        ║
╠════════════════════════════════════════════════════════════╣
║                                                            ║
║ Required Python packages are missing:                     ║
║ • MetaTrader5                                             ║
║ • requests                                                ║
║                                                            ║
║ Please install them with:                                 ║
║                                                            ║
║   pip install MetaTrader5 requests                        ║
║                                                            ║
║ Or run: RUN_CONNECTOR.bat from your TRADIFY folder       ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝

Error details: {e}
"""
    print(error_msg)
    # Show error box if GUI available
    try:
        import tkinter as tk
        root = tk.Tk()
        root.withdraw()
        tk.messagebox.showerror("Installation Error", error_msg)
    except:
        pass
    sys.exit(1)

# ============================================================================
# CONFIGURATION
# ============================================================================

def get_app_dir() -> str:
    """Return user-writable app directory"""
    base = os.getenv("APPDATA", os.path.expanduser("~"))
    app_dir = os.path.join(base, "TradifyConnector")
    os.makedirs(app_dir, exist_ok=True)
    return app_dir


class Config:
    """Connector configuration"""
    DEFAULT_API_URL = os.getenv("TRADIFY_API_URL", "http://localhost:3002/api/mt5")
    TRADIFY_API_URL = DEFAULT_API_URL
    SYNC_INTERVAL = 30  # Seconds between account data syncs
    TRADE_SYNC_INTERVAL = 60  # Seconds between trade syncs
    HEARTBEAT_INTERVAL = 300  # Seconds between heartbeats (5 minutes)
    MAX_RETRIES = 3
    TIMEOUT = 10  # HTTP request timeout
    APP_DIR = get_app_dir()


# ============================================================================
# LOGGING SETUP
# ============================================================================

LOG_FILE = os.path.join(Config.APP_DIR, "tradify_connector.log")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger(__name__)


# ============================================================================
# HTTP CLIENT WITH RETRY LOGIC
# ============================================================================

def create_session_with_retries() -> requests.Session:
    """Create a requests session with retry logic"""
    session = requests.Session()
    retry_strategy = Retry(
        total=Config.MAX_RETRIES,
        backoff_factor=1,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET", "POST", "PUT", "DELETE"],
    )
    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session


# ============================================================================
# MT5 CONNECTOR
# ============================================================================

class MT5Connector:
    """Handles connection and data retrieval from MetaTrader 5"""

    def __init__(
        self,
        token: str,
        api_url: Optional[str] = None,
        status_cb: Optional[Callable[[str], None]] = None,
    ):
        """
        Initialize the connector
        
        Args:
            token: Connection token from TRADIFY platform
            api_url: Optional override for TRADIFY API URL
            status_cb: Optional callback for status updates (GUI)
        """
        self.token = token
        if api_url:
            Config.TRADIFY_API_URL = api_url
        self.status_cb = status_cb
        self.connection_id: Optional[str] = None
        self.session = create_session_with_retries()
        self.is_running = False
        self.last_sync = 0
        self.last_trade_sync = 0
        self.last_heartbeat = 0

    def notify(self, message: str):
        """Send status message to UI if available"""
        if self.status_cb:
            try:
                self.status_cb(message)
            except Exception:
                pass
        logger.info(message)

    def initialize_mt5(self) -> bool:
        """Initialize MT5 connection"""
        try:
            self.notify("🔌 Initializing MetaTrader 5 connection...")
            self.notify("   (Make sure MT5 is open and logged in)")

            if not mt5.initialize():
                error = mt5.last_error()
                self.notify("")
                self.notify("❌ MT5 INITIALIZATION FAILED")
                self.notify(f"   Error: {error}")
                self.notify("")
                self.notify("SOLUTIONS:")
                self.notify("1. Verify MetaTrader 5 is INSTALLED on your computer")
                self.notify("2. Open your MT5 terminal and LOG IN to your account")
                self.notify("3. Keep MT5 open while the connector is running")
                self.notify("4. Make sure you're not in read-only mode in MT5")
                self.notify("")
                return False

            self.notify("✓ MetaTrader 5 initialized successfully")

            # Get account info
            account_info = mt5.account_info()
            if account_info:
                self.notify(f"✓ Account: {account_info.login} ({account_info.server})")
                self.notify(f"✓ Balance: ${account_info.balance:,.2f}")
                self.notify(f"✓ Equity: ${account_info.equity:,.2f}")
                return True
            else:
                self.notify("❌ Could not retrieve account info from MT5")
                self.notify("   Try logging out and back in to your MT5 account")
                return False

        except Exception as e:
            self.notify("")
            self.notify("❌ MT5 CONNECTION ERROR")
            self.notify(f"   {str(e)}")
            self.notify("")
            self.notify("Make sure MetaTrader 5 is installed:")
            self.notify("• Download from: https://www.metatrader5.com/en/download")
            self.notify("• Install and log in with your broker account")
            return False

    def register_connection(self, account_info) -> bool:
        """Register this connection with TRADIFY backend"""
        try:
            self.notify("")
            self.notify("📡 Registering connection with TRADIFY...")
            payload = {
                "connectionToken": self.token,
                "accountName": f"MT5 {account_info.login}",
                "serverName": account_info.server,
                "connectorVersion": "1.0.0",
                "localConnectorIP": self.get_local_ip(),
            }

            response = self.session.post(
                f"{Config.TRADIFY_API_URL}/register-connection",
                json=payload,
                timeout=Config.TIMEOUT,
            )

            if response.status_code == 200:
                data = response.json()
                self.connection_id = data.get("connectionId")
                self.notify(f"✓ Connection Established!")
                self.notify(f"  Connection ID: {self.connection_id}")
                self.notify("")
                self.notify("🎉 SUCCESS - Starting sync...")
                return True
            else:
                self.notify(f"❌ Registration failed: HTTP {response.status_code}")
                self.notify(f"   Response: {response.text[:200]}")
                return False

        except Exception as e:
            self.notify(f"❌ Registration error: {e}")
            self.notify("")
            self.notify("Check:")
            self.notify("• TRADIFY server is running on http://localhost:3002")
            self.notify("• Your connection token is correct")
            self.notify("• Your internet connection is working")
            return False

    def get_daily_pnl(self) -> float:
        """Calculate daily P&L from closed trades (today only)"""
        try:
            from datetime import date, datetime as dt
            
            # Get closed deals from today
            today_start = dt.combine(date.today(), dt.min.time())
            today_timestamp = int(today_start.timestamp())
            
            deals = mt5.history_deals_get(today_timestamp)
            if not deals:
                return 0.0
            
            daily_pnl = 0.0
            for deal in deals:
                # Only count closing deals (type 1 = closing)
                if deal.type == 1:  # Closing deal
                    daily_pnl += float(deal.profit)
            
            return daily_pnl
        except Exception as e:
            logger.warning(f"Could not calculate daily P&L: {e}")
            return 0.0

    def sync_account_data(self) -> bool:
        """Sync account statistics to TRADIFY"""
        if not self.connection_id:
            return False

        try:
            account_info = mt5.account_info()
            if not account_info:
                logger.warning("Could not retrieve account info")
                return False

            daily_pnl = self.get_daily_pnl()

            payload = {
                "accountBalance": float(account_info.balance),
                "accountEquity": float(account_info.equity),
                "accountMargin": float(account_info.margin),
                "accountFreeMargin": float(account_info.margin_free),
                "accountProfit": float(account_info.profit),
                "dailyProfit": daily_pnl,
            }

            response = self.session.post(
                f"{Config.TRADIFY_API_URL}/sync-account-data/{self.connection_id}",
                json=payload,
                timeout=Config.TIMEOUT,
            )

            if response.status_code == 200:
                logger.debug("✓ Account data synced")
                return True
            else:
                logger.warning(f"Account sync failed: {response.status_code}")
                return False

        except Exception as e:
            logger.error(f"Account sync error: {e}")
            return False

    def get_open_trades(self) -> List[Dict]:
        """Get all open trades from MT5"""
        try:
            positions = mt5.positions_get()
            if not positions:
                return []

            trades = []
            for pos in positions:
                trade = {
                    "ticket": str(pos.ticket),
                    "symbol": pos.symbol,
                    "type": "BUY" if pos.type == 0 else "SELL",
                    "volume": float(pos.volume),
                    "openPrice": float(pos.price_open),
                    "currentPrice": float(pos.price_current),
                    "stopLoss": float(pos.sl) if pos.sl > 0 else None,
                    "takeProfit": float(pos.tp) if pos.tp > 0 else None,
                    "profit": float(pos.profit),
                    "openTime": datetime.fromtimestamp(pos.time).isoformat(),
                    "status": "OPEN",
                }
                trades.append(trade)

            return trades

        except Exception as e:
            logger.error(f"Error retrieving trades: {e}")
            return []

    def get_historical_trades(self) -> List[Dict]:
        """Get historical closed trades from the last 30 days"""
        try:
            # Get deals from last 30 days
            from_date = datetime.now() - timedelta(days=30)
            from_timestamp = int(from_date.timestamp())
            
            deals = mt5.history_deals_get(from_timestamp)
            if not deals:
                return []

            # Group deals by position ticket
            closed_trades = {}
            
            for deal in deals:
                # Skip balance operations and other non-trade deals
                if deal.entry not in [0, 1]:  # 0=IN (opening), 1=OUT (closing)
                    continue
                    
                position_id = str(deal.position_id)
                
                if position_id not in closed_trades:
                    closed_trades[position_id] = {
                        "ticket": position_id,
                        "symbol": deal.symbol,
                        "type": "BUY" if deal.type == 0 else "SELL",
                        "volume": float(deal.volume),
                        "openPrice": None,
                        "closePrice": None,
                        "profit": 0.0,
                        "openTime": None,
                        "closeTime": None,
                        "status": "CLOSED",
                    }
                
                trade = closed_trades[position_id]
                
                # Entry deal
                if deal.entry == 0:
                    trade["openPrice"] = float(deal.price)
                    trade["openTime"] = datetime.fromtimestamp(deal.time).isoformat()
                # Exit deal
                elif deal.entry == 1:
                    trade["closePrice"] = float(deal.price)
                    trade["closeTime"] = datetime.fromtimestamp(deal.time).isoformat()
                    trade["profit"] += float(deal.profit)

            # Filter out incomplete trades and convert to list
            complete_trades = []
            for trade in closed_trades.values():
                if trade["openTime"] and trade["closeTime"]:
                    complete_trades.append(trade)
            
            return complete_trades

        except Exception as e:
            logger.error(f"Error retrieving historical trades: {e}")
            return []

    def sync_trades(self) -> bool:
        """Sync open and historical trades to TRADIFY"""
        if not self.connection_id:
            return False

        try:
            # Get both open and closed trades
            open_trades = self.get_open_trades()
            historical_trades = self.get_historical_trades()
            all_trades = open_trades + historical_trades

            payload = {"trades": all_trades}

            response = self.session.post(
                f"{Config.TRADIFY_API_URL}/sync-trades/{self.connection_id}",
                json=payload,
                timeout=Config.TIMEOUT,
            )

            if response.status_code == 200:
                logger.info(f"✓ Synced {len(open_trades)} open + {len(historical_trades)} historical trades")
                return True
            else:
                logger.warning(f"Trade sync failed: {response.status_code}")
                return False

        except Exception as e:
            logger.error(f"Trade sync error: {e}")
            return False

    def send_heartbeat(self) -> bool:
        """Send health check to keep connection alive"""
        if not self.connection_id:
            return False

        try:
            response = self.session.get(
                f"{Config.TRADIFY_API_URL}/health/{self.connection_id}",
                timeout=Config.TIMEOUT,
            )

            if response.status_code == 200:
                logger.debug("✓ Heartbeat sent")
                return True
            else:
                logger.warning(f"Heartbeat failed: {response.status_code}")
                return False

        except Exception as e:
            logger.error(f"Heartbeat error: {e}")
            return False

    @staticmethod
    def get_local_ip() -> str:
        """Get local IP address"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"

    def start_sync_loop(self):
        """Main sync loop - runs in background thread"""
        self.notify("📊 Starting sync loop...")
        current_time = time.time()
        self.last_sync = current_time
        self.last_trade_sync = current_time
        self.last_heartbeat = current_time

        while self.is_running:
            try:
                current_time = time.time()

                # Account data sync
                if current_time - self.last_sync >= Config.SYNC_INTERVAL:
                    self.sync_account_data()
                    self.last_sync = current_time

                # Trade sync
                if current_time - self.last_trade_sync >= Config.TRADE_SYNC_INTERVAL:
                    self.sync_trades()
                    self.last_trade_sync = current_time

                # Heartbeat
                if current_time - self.last_heartbeat >= Config.HEARTBEAT_INTERVAL:
                    self.send_heartbeat()
                    self.last_heartbeat = current_time

                # Sleep briefly to prevent CPU spinning
                time.sleep(5)

            except KeyboardInterrupt:
                self.notify("Sync loop interrupted by user")
                self.is_running = False
                break
            except Exception as e:
                self.notify(f"Sync loop error: {e}")
                self.is_running = False
                break

    def run(self):
        """Main run method"""
        self.notify("=" * 70)
        self.notify("TRADIFY MT5 CONNECTOR")
        self.notify("=" * 70)

        # Step 1: Initialize MT5
        if not self.initialize_mt5():
            self.notify("❌ Failed to initialize MT5. Exiting.")
            return

        # Step 2: Get account info and register
        try:
            account_info = mt5.account_info()
            if not self.register_connection(account_info):
                self.notify("❌ Failed to register connection. Exiting.")
                return
        except Exception as e:
            self.notify(f"❌ Error registering connection: {e}")
            return

        # Step 3: Start sync loop
        self.is_running = True
        self.notify("✓ Connector ready! Running background sync...")
        self.notify("Press Stop or close window to exit")

        try:
            self.start_sync_loop()
        except KeyboardInterrupt:
            self.notify("Shutting down...")
        finally:
            self.shutdown()

    def stop(self):
        """Stop connector (used by GUI)"""
        self.is_running = False
        self.shutdown()

    def shutdown(self):
        """Graceful shutdown"""
        self.notify("Shutting down connector...")
        self.is_running = False

        try:
            mt5.shutdown()
            self.notify("✓ MT5 connection closed")
        except Exception as e:
            self.notify(f"Error shutting down MT5: {e}")


# ============================================================================
# TKINTER GUI
# ============================================================================


class GuiLogHandler(logging.Handler):
    """Send log records to a Tkinter Text widget via queue"""

    def __init__(self, log_queue: queue.Queue):
        super().__init__()
        self.log_queue = log_queue

    def emit(self, record):
        try:
            msg = self.format(record)
            self.log_queue.put(msg)
        except Exception:
            pass


class ConnectorGUI:
    """Minimal GUI for start/stop and status"""

    def __init__(self, token_prefill: str, api_url: str, sync_interval: int):
        self.root = tk.Tk()
        self.root.title("TRADIFY MT5 Connector")
        self.root.geometry("520x420")
        self.root.resizable(False, False)

        self.connector: Optional[MT5Connector] = None
        self.connector_thread: Optional[threading.Thread] = None
        self.log_queue: queue.Queue[str] = queue.Queue()

        self.token_var = tk.StringVar(value=token_prefill)
        self.api_var = tk.StringVar(value=api_url)
        self.sync_var = tk.IntVar(value=sync_interval)
        self.status_var = tk.StringVar(value="Idle")

        self._setup_logging()
        self._build_ui()

        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self._poll_log_queue()

    def _setup_logging(self):
        handler = GuiLogHandler(self.log_queue)
        handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
        logger.addHandler(handler)

    def _build_ui(self):
        padding = {"padx": 12, "pady": 8}

        frm = ttk.Frame(self.root)
        frm.pack(fill="both", expand=True)

        ttk.Label(frm, text="Connection Token (from dashboard)").grid(row=0, column=0, sticky="w", **padding)
        ttk.Entry(frm, textvariable=self.token_var, width=48).grid(row=1, column=0, sticky="ew", **padding)

        ttk.Label(frm, text="API URL").grid(row=2, column=0, sticky="w", **padding)
        ttk.Entry(frm, textvariable=self.api_var, width=48).grid(row=3, column=0, sticky="ew", **padding)

        ttk.Label(frm, text="Sync interval (seconds)").grid(row=4, column=0, sticky="w", **padding)
        ttk.Entry(frm, textvariable=self.sync_var, width=12).grid(row=5, column=0, sticky="w", **padding)

        btn_frame = ttk.Frame(frm)
        btn_frame.grid(row=6, column=0, sticky="ew", **padding)
        self.start_btn = ttk.Button(btn_frame, text="Connect", command=self.start_connector)
        self.start_btn.pack(side="left", padx=4)
        self.stop_btn = ttk.Button(btn_frame, text="Stop", command=self.stop_connector, state="disabled")
        self.stop_btn.pack(side="left", padx=4)

        ttk.Label(frm, text="Status:").grid(row=7, column=0, sticky="w", **padding)
        self.status_lbl = ttk.Label(frm, textvariable=self.status_var, foreground="#16a34a")
        self.status_lbl.grid(row=8, column=0, sticky="w", **padding)

        ttk.Label(frm, text="Logs:").grid(row=9, column=0, sticky="w", **padding)
        self.log_txt = tk.Text(frm, height=10, state="disabled", bg="#0f172a", fg="#e2e8f0")
        self.log_txt.grid(row=10, column=0, sticky="nsew", padx=12, pady=(0, 12))
        frm.rowconfigure(10, weight=1)
        frm.columnconfigure(0, weight=1)

    def _poll_log_queue(self):
        try:
            while True:
                msg = self.log_queue.get_nowait()
                self._append_log(msg)
        except queue.Empty:
            pass
        self.root.after(300, self._poll_log_queue)

    def _append_log(self, msg: str):
        self.log_txt.configure(state="normal")
        self.log_txt.insert("end", msg + "\n")
        self.log_txt.see("end")
        self.log_txt.configure(state="disabled")

    def update_status(self, msg: str):
        self.status_var.set(msg)
        self.log_queue.put(msg)

    def start_connector(self):
        token = self.token_var.get().strip()
        if not token:
            messagebox.showerror("Token required", "Please paste your connection token from the dashboard.")
            return

        api_url = self.api_var.get().strip() or Config.DEFAULT_API_URL
        try:
            sync_interval = max(5, int(self.sync_var.get()))
        except Exception:
            sync_interval = Config.SYNC_INTERVAL

        Config.TRADIFY_API_URL = api_url
        Config.SYNC_INTERVAL = sync_interval

        self.start_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        self.status_var.set("Starting...")

        def runner():
            self.connector = MT5Connector(token=token, api_url=api_url, status_cb=self.update_status)
            self.connector.run()
            self.status_var.set("Stopped")
            self.start_btn.configure(state="normal")
            self.stop_btn.configure(state="disabled")

        self.connector_thread = threading.Thread(target=runner, daemon=True)
        self.connector_thread.start()

    def stop_connector(self):
        if self.connector:
            self.connector.stop()
        self.start_btn.configure(state="normal")
        self.stop_btn.configure(state="disabled")
        self.status_var.set("Stopping...")

    def on_close(self):
        try:
            self.stop_connector()
        finally:
            self.root.destroy()

    def run(self):
        self.root.mainloop()


def launch_gui(token_prefill: str, api_url: str, sync_interval: int):
    app = ConnectorGUI(token_prefill=token_prefill, api_url=api_url, sync_interval=sync_interval)
    app.run()


# ============================================================================
# MAIN ENTRY POINT
# ============================================================================

def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="TRADIFY MT5 Connector - Sync your MT5 terminal with TRADIFY",
    )
    parser.add_argument(
        "--token",
        help="Connection token from TRADIFY platform. If omitted, GUI will be shown.",
    )
    parser.add_argument(
        "--api-url",
        default=Config.TRADIFY_API_URL,
        help=f"TRADIFY API URL (default: {Config.TRADIFY_API_URL})",
    )
    parser.add_argument(
        "--sync-interval",
        type=int,
        default=Config.SYNC_INTERVAL,
        help=f"Account sync interval in seconds (default: {Config.SYNC_INTERVAL})",
    )
    parser.add_argument(
        "--headless",
        action="store_true",
        help="Run without GUI (requires --token)",
    )
    parser.add_argument(
        "--gui",
        action="store_true",
        help="Force GUI mode (default when no --token)",
    )

    args = parser.parse_args()

    # Decide mode: GUI by default unless headless explicitly requested with token
    if args.gui or (not args.headless and not args.token):
        launch_gui(
            token_prefill=args.token or "",
            api_url=args.api_url,
            sync_interval=args.sync_interval,
        )
        return

    if args.headless and not args.token:
        parser.error("--token is required for headless mode")

    # Update config for headless run
    Config.TRADIFY_API_URL = args.api_url
    Config.SYNC_INTERVAL = args.sync_interval

    connector = MT5Connector(token=args.token, api_url=args.api_url)
    connector.run()


if __name__ == "__main__":
    main()
